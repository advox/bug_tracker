<?php

/**
 * Product Title:		Group Name Indicator
 * Product Version:		1.1.0
 * Author:				Michael McCune
 * Website:				Invision focus
 * Website URL:			http://invisionfocus.com/
 * Email:				michael.mccune@gmail.com
 */

$DEFAULT_SECTION = 'groupNameIndicator';