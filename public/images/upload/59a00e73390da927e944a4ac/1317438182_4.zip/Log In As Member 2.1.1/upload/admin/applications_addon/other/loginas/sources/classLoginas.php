<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit;
}

class classLoginas
{	
	public function __construct( ipsRegistry $registry )
	{
		$this->registry   = $registry;
		$this->DB         = $this->registry->DB();
		$this->settings   =& $this->registry->fetchSettings();
		$this->request    = $this->registry->request();
		$this->lang       = $this->registry->getClass('class_localization');
		$this->member     = $this->registry->member();
		$this->memberData =& $this->registry->member()->fetchMemberData();
		$this->cache      = $this->registry->cache();
		$this->caches     =& $this->registry->cache()->fetchCaches();
		$this->registry->getClass( 'class_localization' )->loadLanguageFile( array( 'public_login' ), 'loginas' );
		$this->initHanLogin();
	}
    
	/* Initalize login class */
	public function initHanLogin()
	{
    	require_once( IPS_ROOT_PATH . 'sources/handlers/han_login.php' );
    	$this->han_login =  new han_login( $this->registry );
    	$this->han_login->init();
	}
	
	/*============================================== */
	/* Log in as a member (Be careful if modifying) */
    /*==============================================*/
	public function logInAs($mem=0)
    {
		if (!$mem) $mem = $this->request['member_id'];
		/* Set return URL */
		$http_referrer = my_getenv('HTTP_REFERER');
		if (strpos($http_referrer, 'index.php?adsess=')) $http_referrer = 'index.php';
        /* Permissions and error checking */
        if ( $this->memberData['_cache']['loginas_banned'] )
        {
            $this->registry->output->showError( 'banned' );
        }
	    if ( !IPSMember::load( intval( $mem ), '' ) )
        {
            $this->registry->output->showError( 'bad_account' );
        }
		$member = IPSMember::load( intval( $mem ), '' );
		if ( $this->memberData['member_id'] == $member['member_id'] or !$this->settings['loginas_enabled'] )
        {
            $this->registry->output->showError( 'no_access' );
        }
        if ( !in_array( $this->memberData['member_group_id'], explode( ",", $this->settings['loginas_groups'] ) ) or in_array( $member['member_group_id'], explode( ",", $this->settings['loginas_protected'] ) ) )
        {
            $this->registry->output->showError( 'no_access' );
        }
        /* FINALLY do the actual login, if you've made it through all the checks :P */
		IPSCookie::set('adminuserid', IPSCookie::get('member_id') );
		IPSCookie::set('adminuserhash', IPSCookie::get('pass_hash') );
        IPSCookie::set('userstate', $member['login_anonymous'] );
		IPSCookie::set('adminstate', $this->memberData['login_anonymous'] );
		IPSCookie::set('lastact', $member['last_activity'] );
		$this->log( $this->memberData['member_id'], 1, $member['member_id'], $this->settings['loginas_anon'] );
		$this->han_login->loginWithoutCheckingCredentials($member['member_id'], TRUE);
		$core['login_anonymous'] = $this->settings['loginas_anon'].'&1';
        IPSMember::save( $member['member_id'], array( 'core' => $core ) );
		$privacy = ( $this->settings['loginas_anon'] == 1 ) ? $this->lang->words['enabled'] : $this->lang->words['disabled'];
		$this->registry->getClass('output')->redirectScreen( sprintf ( $this->lang->words['loggedInAs'], $member['members_display_name'], $privacy ), $http_referrer, true );
	}
	
    /*===================================== */
	/* Switch back to admin account        */
    /*=====================================*/
	public function adminLogOut()
	{
		$http_referrer = my_getenv('HTTP_REFERER');
		$memberAdmin = IPSMember::load( IPSCookie::get('adminuserid'), 'member_login_key,members_display_name' );
		if ( $memberAdmin['member_login_key'] != IPSCookie::get('adminuserhash' ) ) $this->han_login->doLogout;
		    $this->log( $memberAdmin['member_id'], 0, $this->memberData['member_id'], 2 );
            $core['login_anonymous'] = IPSCookie::get('userstate');
			$core['last_activity'] = IPSCookie::get('lastact');
            IPSMember::save( $this->memberData['member_id'], array( 'core' => $core ) );
			$this->han_login->loginWithoutCheckingCredentials(IPSCookie::get('adminuserid'), TRUE);
			$core['login_anonymous'] = IPSCookie::get('adminstate');
			$core['last_activity'] = IPSCookie::get('lastact');
			IPSMember::save( $memberAdmin['member_id'], array( 'core' => $core ) );
			IPSCookie::set('adminuserid', "", -1 );
			IPSCookie::set('adminuserhash', "", -1 );
            IPSCookie::set('userstate', "", -1 );
			IPSCookie::set('adminstate', "", -1 );
			IPSCookie::set('lastact', "", -1 );
			$this->registry->getClass('output')->redirectScreen( sprintf( $this->lang->words['logBackAdmin'], $memberAdmin['members_display_name'] ), $http_referrer, true );
	}
	
    /*===================================== */
	/* Insert a log entry                  */
    /*=====================================*/
	public function log( $admin, $action, $user, $anonymous )
	{
		$log = array( 'admin'    => $admin,
				      'action' => $action,
				      'user' => $user,
					  'time' => time(),
					  'ip'    => $this->member->ip_address,
					  'anonymous' => $anonymous,
					 );
	    $this->DB->insert( 'loginas_logs', $log );
	}
}
?>