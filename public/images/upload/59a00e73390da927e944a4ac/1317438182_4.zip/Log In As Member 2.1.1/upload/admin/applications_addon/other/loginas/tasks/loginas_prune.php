<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if ( !defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

class task_item
{
	protected $class;
	protected $task			= array();
	protected $restrict_log	= false;
	protected $registry;
	protected $DB;
	protected $settings;
	protected $lang;
	
	public function __construct( ipsRegistry $registry, $class, $task )
	{
		/* Make registry objects */
		$this->registry	=  $registry;
		$this->DB		=  $this->registry->DB();
		$this->settings =& $this->registry->fetchSettings();
		$this->lang		= $this->registry->getClass('class_localization');
		$this->class	=  $class;
		$this->task		=  $task;
	}
	
	public function runTask()
	{
		/* Load language file */
		$this->registry->getClass('class_localization')->loadLanguageFile( array( 'admin_logs' ), 'loginas' );
		
		/* Has a days number been set? */
		if ( $this->settings['loginas_prune'] > 0 )
		{
			/* Set time, count logs to be deleted, then delete 'em! */
			$time = time() - ( $this->settings['loginas_prune'] * 60 * 60 * 24 );
			$count = $this->DB->buildAndFetch(array('select' => 'count(*) as count', 'from' => 'loginas_logs', 'where' => "time < '{$time}'" ));
			$this->DB->delete( 'loginas_logs', "time < {$time}"  );
			/* Log task */
			$this->class->appendTaskLog( $this->task, sprintf( $this->lang->words['pruned'], $count['count'], $this->settings['loginas_prune'] ) );
		}
		
		/* Unlock Task: DO NOT MODIFY! */
		$this->class->unlockTask( $this->task );
	}
}