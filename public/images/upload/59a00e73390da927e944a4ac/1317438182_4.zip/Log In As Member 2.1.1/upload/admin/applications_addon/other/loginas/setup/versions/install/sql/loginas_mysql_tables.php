<?php

$TABLE[] = "CREATE TABLE loginas_logs (
  id int(11) NOT NULL AUTO_INCREMENT,
  admin text NOT NULL,
  action text NOT NULL,
  user text NOT NULL,
  time text NOT NULL,
  ip text NOT NULL,
  anonymous text NOT NULL,
  PRIMARY KEY (id)
);";