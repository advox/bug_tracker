<?php

class app_class_loginas
{
	/*
	 * Registry Object Shortcuts
	 *
	 * @access	protected
	 * @var		object
	 */
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $cache;
	/**#@-*/

	public function __construct( ipsRegistry $registry )
	{
		/* Make object */
		$this->registry = $registry;
		$this->DB       = $this->registry->DB();
		$this->settings =& $this->registry->fetchSettings();
		$this->request  =& $this->registry->fetchRequest();
		$this->cache    = $this->registry->cache();
		$this->caches   =& $this->registry->cache()->fetchCaches();
		$this->lang     = $this->registry->getClass('class_localization');
		$this->member   = $this->registry->member();
		$this->memberData =& $this->registry->member()->fetchMemberData();
		
		$this->registry->getClass('class_localization')->loadLanguageFile(array('admin_logs', 'admin_bans', 'admin_login', 'public_login'), 'loginas');
		
		require_once( IPSLib::getAppDir( 'loginas' ) . '/sources/classLoginas.php' );
		$this->registry->setClass( 'classLoginas', new classLoginas( $this->registry ) );
	}
}