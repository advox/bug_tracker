<?php

$DEFAULT_SECTION = 'logs';

?>