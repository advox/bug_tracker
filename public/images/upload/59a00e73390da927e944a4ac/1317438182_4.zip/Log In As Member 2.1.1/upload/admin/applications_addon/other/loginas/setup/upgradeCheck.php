<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
class loginas_upgradeCheck
{
	/**
	 * Check we can upgrade
	 *
	 * @return	mixed	Boolean true or error message
	 */
	public function checkForProblems()
	{
		$this->DB = ipsRegistry::instance()->DB();
		$info  = array( 'notexist' => array(), 'notwrite' => array(), 'other' => array() );
		if ( $this->DB->buildAndFetch( array( 'select' => '*', 'from' => 'core_hooks', 'where' => "hook_key='LogInAsMemberHook'" ) ) )
		{
			$hook = $this->DB->buildAndFetch( array( 'select' => '*', 'from' => 'core_hooks', 'where' => "hook_key='LogInAsMemberHook'" ) );
			if ( intval( $hook['hook_version_long'] ) < intval ( 20000 ) )
			{
				return 'We have detected that v'.$hook['hook_version_human'].' of the hook is installed. v1.x of the hook should not be installed with the 2.x series application.<br />Please remove the 1.x hook and re-import the 2.x hook before proceeding';
			}
		}
		return TRUE;
	}
}