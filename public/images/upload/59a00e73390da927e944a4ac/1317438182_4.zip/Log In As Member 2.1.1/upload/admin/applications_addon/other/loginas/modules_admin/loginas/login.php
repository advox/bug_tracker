<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit;
}

class admin_loginas_loginas_login extends ipsCommand
{
    public $html;
	
	public function doExecute ( ipsRegistry $registry )
	{
	$this->html	= $this->registry->output->loadTemplate('cp_skin_loginas');
	switch( $this->request['do'] )
    	{	
			case 'loginForm':
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_login' );
                $this->showLoginForm();
            break;
			
			case 'doLogin':
			$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_login' );
                $this->performTheLogin();
            break;
			
			default:
			    $this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_login' );
			    $this->registry->output->html .= $this->html->loginasForm();
			break;
    	}
        $this->registry->output->html .= $this->html->copyright();
		$this->registry->getClass('output')->html_main .= $this->registry->getClass('output')->global_template->global_frame_wrapper();
		$this->registry->getClass('output')->sendOutput();
	}
	
	/*===================================== */
	/* Call login URL with member ID       */
    /*=====================================*/
	public function performTheLogin()
	{
		if ( IPSMember::load( $this->request['member_name'], '' ) )
		{
			$mem = IPSMember::load( $this->request['member_name'], '' );
			header( "Location: ../index.php?app=core&module=global&section=login&do=loginas&member_id={$mem['member_id']}" );
		}
		$this->registry->output->showError( 'invalid_member');
	}
	
}
?>