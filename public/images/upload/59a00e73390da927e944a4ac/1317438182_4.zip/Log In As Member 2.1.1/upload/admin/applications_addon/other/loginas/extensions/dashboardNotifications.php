<?php
class dashboardNotifications__loginas
{

public function __construct()
	{
		$this->caches	=& ipsRegistry::cache()->fetchCaches();
	}
	
	public function get()
	{
		$return = array();
		
		require_once( IPS_KERNEL_PATH . 'classFileManagement.php' );
		$this->classFileManagement = new classFileManagement();
		$returned = Array();
		$returned = unserialize( $this->classFileManagement->getFileContents( base64_decode("aHR0cDovL3d3dy50dmMtaW5jLm5ldC9zdGF0aWMvdXBkYXRlLnBocD9hcHBLZXk9bG9naW5hcyZ2PQ==").$this->caches['app_cache']['loginas']['app_long_version'] ) );
		/* Check that we actually got data */
		if ( $returned['currentLong'] && $returned['currentShort'] )
		{
			if ( $returned['currentLong'] > $this->caches['app_cache']['loginas']['app_long_version'] )
			{
				$return[] = array( "Log In As Member Update", "Log In As Member ".$returned['currentShort']." has been released. We strongly recommend you upgrade" );
			}
		}
		return $return;
	}
}