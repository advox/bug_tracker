<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/

class cp_skin_loginas extends output
{

    public function __destruct()
    {
    }
    
    //===============================================
    // LOGS VEW SCREEN
    //===============================================
    public function logsView ( $logs, $pagination, $currentSearch )
    {
		$status = count($logs) > 0 ? "closed" : "disabled";
        $search['option'] = $this->registry->output->formDropdown( 'option', array( array( 'user', "{$this->lang->words['display_name']}" ), array( 'ip', "{$this->lang->words['ip_address']}" ) ), $currentSearch['option'] ? $currentSearch['option'] : 'user' );
        if ( $currentSearch['option'] == 'user' )
        {
            $member = IPSMember::load( $currentSearch['value'], '' );
            $currentSearch['value'] = $member['members_display_name'];
        }
        $search['value'] = $this->registry->output->formInput( 'value', $currentSearch['value'] );
        $IPBHTML = "";
        $IPBHTML .= <<<HTML
        <div class='section_title'>
			<h2>{$this->lang->words['logs']}</h2>
            <ul class='context_menu'>
				<li class='{$status}'><a href='#' onclick='acp.confirmDelete("{$this->settings['base_url']}&amp;{$this->form_code}&amp;do=deleteAllLogs");'><img src='{$this->settings['skin_acp_url']}/images/icons/delete.png' alt='' /> {$this->lang->words['delete_logs']}</a></li>
            </ul>
		</div>
        <script type='text/javascript' src='{$this->settings['js_main_url']}acp.forms.js'></script>
        <script type='text/javascript' src='{$this->settings['js_app_url']}acp.loginas.js'></script>
		
    <form action='{$this->settings['base_url']}{$this->form_code}' method='post' id='theAdminForm'>
		<input type='hidden' name='do' value='deleteSelectedLogs' />
		<div class='acp-box'>
			<h3>{$this->lang->words['logs']}</h3>
			<table class='ipsTable'>
HTML;
            if ( count( $logs ) )
				{
                $IPBHTML .= <<<HTML
				<tr>
					<th>{$this->lang->words['time']}</th>
					<th>{$this->lang->words['action']}</th>
					<th>{$this->lang->words['ip_address']}</th>
					<th>{$this->lang->words['anonymous']}</th>
					<th style="text-align: center;"><input type='checkbox' title="{$this->lang->words['check_all']}" id='checkAll' /></th>
				</tr>
HTML;
					foreach ( $logs as $log )
					{
						$IPBHTML .= <<<HTML
				        <tr>
					        <td><span class='larger_text'>{$this->registry->class_localization->getDate( $log['time'], 'LONG' )}</td>
					        <td>{$log['admin']} {$log['action']} {$log['user']}</td>
							<td><a href="{$this->settings['base_url']}&app=members&amp;module=members&amp;section=tools&amp;do=learn_ip&amp;ip={$log['ip']}">{$log['ip']}</a></td>
					        <td>{$log['anonymous']}</td>
                            <td style="text-align: center;"><input type='checkbox' name='log_ids[]' value='{$log['id']}' class='checkAll' /></td>
				        </tr>
HTML;
					}
                    $IPBHTML .= <<<HTML
            </table>
			<div class='acp-actionbar'>
				<div style='float: right;'><input type='submit' value='{$this->lang->words['delete_selected']}' class='button primary' /></div>
				{$pagination}
			</div>
	    </div>
	</form>
		
	<br />
	<div style='width: 600px;'>
		<div class='acp-box'>
			<h3>{$this->lang->words['search_logs']}</h3>
			<form action='{$this->settings['base_url']}&amp;do=viewLogs' method='post'>
				<input type='hidden' name='search' value='1' />
				<table class='ipsTable double_pad'>
					<tr>
						<th colspan='2'>{$this->lang->words['search_logs']}</th>
					</tr>
					<tr>
						<td class='field_title'><strong class='title'>{$this->lang->words['search_what']}</strong></td>
						<td class='field_field'>{$search['option']}</td>
					</tr>
					<tr>
						<td class='field_title'><strong class='title'>{$this->lang->words['value']}</strong></td>
						<td class='field_field'>{$search['value']}</td>
					</tr>
				</table>
				<div class='acp-actionbar'>
					<input type='submit' value='{$this->lang->words['search']}' class='button' />
				</div>
			</form>
		</div>
	</div>
HTML;
				}
				else
				{
					$IPBHTML .= <<<HTML
					<tr>
				<td colspan='2' class='no_messages'>{$this->lang->words['no_logs']}</a></td>
			</tr>
		</table>
HTML;
				}
				$IPBHTML .= <<<HTML
		</div>
HTML;
		//--endhtml--//
		return $IPBHTML;
    }
    
	//===============================================
    // MANUAL LOGIN FORM
    //===============================================
	public function loginasForm()
{
		$userInput = $this->registry->output->formInput( 'member_name', '', 'member_name', 50 );
		$IPBHTML = "";
		//--starthtml--//
		$IPBHTML .= <<<HTML
		<div class='section_title'>
			<h2>{$this->lang->words['manual_login']}</h2>
		</div>
        <script type='text/javascript' src='{$this->settings['js_app_url']}acp.loginas.js'></script>
		<div class='acp-box'>
			<h3>{$this->lang->words['log_into_account']}</h3>
			<form action='{$this->settings['base_url']}&module=loginas&amp;section=login&amp;do=doLogin' method='post'>
				<table class='ipsTable double_pad'>
					<tr>
						<th colspan='2'><font color='red'>{$this->lang->words['warning']}</font></th>
					</tr>
					<tr>
						<td class='field_title'><strong class='title'>{$this->lang->words['display_name']}</strong></td>
						<td class='field_field'>{$userInput}</td>
					</tr>
				</table>
				<div class='acp-actionbar'>
					<input type='submit' class='button' value='{$this->lang->words['log_in']}' />
				</div>
			</form>
		</div>
HTML;
		//--endhtml--//
		return $IPBHTML;
}

    //===============================================
    // BANS VEW SCREEN
    //===============================================
    public function bansView ( $rows, $pages )
    {
        $IPBHTML = "";
		$status = count($rows) > 0 ? "closed" : "disabled";
        //--starthtml--//
        $IPBHTML .= <<<HTML
        <div class='section_title'>
			<h2>{$this->lang->words['banned_users']}</h2>
			<ul class='context_menu'>
				<li class='{$status}'><a href='#' onclick='acp.confirmDelete("{$this->settings['base_url']}&amp;{$this->form_code}&amp;do=removeall");'><img src='{$this->settings['skin_acp_url']}/images/icons/delete.png' alt='' /> {$this->lang->words['remove_all_button']}</a></li>
				<li class='ipsActionButton'><a href='#' id='showBanForm'><img src='{$this->settings['skin_acp_url']}/images/icons/add.png' alt='' /> {$this->lang->words['ban_member']}</a></li>
			</ul>
        </div>
        <div class="acp-box">
	       <h3>{$this->lang->words['banned_users_list']}</h3>
	       <table class='ipsTable'>
HTML;
        if( count($rows) AND is_array($rows) )
        {
		$IPBHTML .= <<<HTML
		<tr>
			<th>{$this->lang->words['display_name']}</th>
			<th class='col_buttons'>&nbsp;</th>
		</tr>
HTML;
	       foreach( $rows as $row )
	       {
		      $IPBHTML .= <<<HTML
		      <tr class='ipsControlRow'>
			     <td><span class='larger_text'>{$row['members_display_name']}</td>
			     <td>
				 <ul class='ipsControlStrip'><li class='i_delete'><a href='#' onclick='acp.confirmDelete("{$this->settings['base_url']}&amp;{$this->form_code}&amp;do=unban&amp;mid={$row['member_id']}");'>{$this->lang->words['remove_ban']}</a></li></ul>
			     </td>
		      </tr>
HTML;
	       }
		   $IPBHTML .= <<<HTML
		   </table>
		   <div class='acp-actionbar'>
			{$pages}
		   </div>
		</div>
HTML;
        }
        else
        {
	       $IPBHTML .= <<<HTML
		      <tr>
				 <td colspan='2' class='no_messages'>{$this->lang->words['no_bans']} <a href='#' id='showBanForm2' class='mini_button'>{$this->lang->words['ban_member']}</a></td>
		      </tr>
			  </table>
			</div>
HTML;
        }
        $IPBHTML .= <<<HTML
        <script type="text/javascript">
		showPopup = function(e) {
		Event.stop(e);
		popup = new ipb.Popup( 'banForm', { type: 'pane', modal: false, w: '700px', h: '500px', initial: $('banForm').innerHTML, hideAtStart: false, close: 'a[rel="close"]' } );
		return false;
		}
		
		if( $('showBanForm') )
		{
			$('showBanForm').observe('click', showPopup);
		}
		if( $('showBanForm2') )
		{
			$('showBanForm2').observe('click', showPopup);
		}
		</script>
HTML;

$name = $this->registry->output->formInput( 'member_name', '', 'member_name', 50 );
$IPBHTML .= <<<HTML
<div id='banForm' style='display:none;'>
<div class='acp-box'>
<script type='text/javascript' src='{$this->settings['js_app_url']}acp.loginas.js'></script>
	<h3>{$this->lang->words['ban_member']}</h3>
	<form action="{$this->settings['base_url']}{$this->form_code}" method="post">
	<input type='hidden' name='do' value='ban' />
		<table class='ipsTable double_pad'>
			<tr>
				<td class='field_title'><strong class='title'>{$this->lang->words['display_name']}</strong></td>
				<td class='field_field'>{$name}</td>
			</tr>
		</table>
		<div class='acp-actionbar'><input type='submit' class='button' value='{$this->lang->words['ban_member']}' /></div>
	</form>
	</div>
</div>
HTML;
//--endhtml--//
return $IPBHTML;
    }
    
    //===============================================
    // COPYRIGHT
    // Removing or modifying this copyright is not 
    // allowed and violates your license agreement
    //===============================================
    public function copyright() {
    $IPBHTML = "";
    //--starthtml--//
    $yr = date("Y");
    $IPBHTML .= <<<HTML
        <br style='clear: both' /><div style='text-align:center; font-weight:bold;'>Powered By: <a href='http://www.tvc-inc.net'>Log In As Member {$this->caches['app_cache']['loginas']['app_version']}</a> &copy; {$yr} <a href='http://www.tvc-inc.net'>TVC Inc</a></div>
HTML;
//--endhtml--//
return $IPBHTML;
}

	//===============================================
    // UPDATES PAGE
    //===============================================
	public function updatePage( $return, $error = '' )
	{
		$IPBHTML = "";
		//--starthtml--//
		$IPBHTML .= <<<HTML
		<div class='section_title'>
			<h2>{$this->lang->words['updates']}</h2>
		</div>
HTML;
	if ( $error != '' )
	{
	$IPBHTML .= <<<HTML
		<div class='warning'>
		<h4>{$this->lang->words['error']}</h4>
		{$error}
		</div>
		<br />
HTML;
}
$IPBHTML .= <<<HTML
			<div class='acp-box'>
				<h3>{$this->lang->words['updates']}</h3>
				<table class='ipsTable'>
HTML;
	if ( $return['updateAvailable'] == 1 )
	{
	$IPBHTML .= <<<HTML
					<tr>
						<th>{$this->lang->words['installed_version']}</th>
						<th>{$this->lang->words['latest_version']}</th>
						<th>{$this->lang->words['release_date']}</th>
						<th>{$this->lang->words['download']}</th>
					</tr>
					<tr>
							<td><span class='larger_text'><font color='red'>{$return['installedVersion']}</font></td>
							<td><font color='green'>{$return['currentShort']}</font></td>
							<td>{$this->registry->class_localization->getDate( $return['releaseDate'], 'LONG' )}</td>
							<td><a href='{$return['downloadLink']}' class='realbutton'>{$this->lang->words['download_update']}</a></td>
					</tr>
				</table>
				</div>
			<br />
			<div class='acp-box'>
			<h3>{$this->lang->words['information']}</h3>
			<div style='padding:5px;'>
				{$return['information']}
				</div>
			</div>
HTML;
	}
	else
	{
		$message = sprintf($this->lang->words['no_updates'], $return['installedVersion']);
		if ( $error != '' )
		{
			$message = $this->lang->words['cannot_get'];
		}
		$IPBHTML .= <<<HTML
			<tr>
				<td colspan='2' class='no_messages'>{$message}</td>
		    </tr>
			</table>
			</div>
HTML;
	}
		//--endhtml--//
		return $IPBHTML;
	}
}
?>