<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

/**
* Plug in name (Default tab name)
*/
$CONFIG['plugin_name']        = 'Log In As Logs';

/**
* Language string for the tab
*/
$CONFIG['plugin_lang_bit']    = '';

/**
* Plug in key (must be the same as the main {file}.php name
*/
$CONFIG['plugin_key']         = 'loginasTab';

/**
* Show tab?
*/
$CONFIG['plugin_enabled']     = 0;
    
    if ( $this->settings['loginas_protected'] == "" ) $this->settings['loginas_protected'] = "0";
    if ( $this->settings['loginas_groups'] == "" ) $this->settings['loginas_groups'] = "0";
    if (!$this->memberData['_cache']['loginas_banned'] AND $this->settings['loginas_tab'] AND $this->settings['loginas_enabled'] AND IPSMember::isInGroup( $this->memberData, explode( ',', $this->settings['loginas_groups'] ) ) AND !IPSMember::isInGroup( $this->request['showuser'], explode( ',', $this->settings['loginas_protected'] ) ) )
    {
		$CONFIG['plugin_enabled']     = 1;
    }

/**
* Order
*/
$CONFIG['plugin_order'] = 8;