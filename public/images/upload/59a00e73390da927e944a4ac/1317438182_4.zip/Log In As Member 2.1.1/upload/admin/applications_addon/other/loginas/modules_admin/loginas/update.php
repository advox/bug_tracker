<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit;
}

class admin_loginas_loginas_update extends ipsCommand
{
    public $html;
	
	public function doExecute ( ipsRegistry $registry )
	{
	$this->html	= $this->registry->output->loadTemplate('cp_skin_loginas');
	switch( $this->request['do'] )
    	{	
			case 'showUpdates':
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_updates' );
                $this->showUpdates();
            break;
			
			default:
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_updates' );
			    $this->showUpdates();
			break;
    	}
        $this->registry->output->html .= $this->html->copyright();
		$this->registry->getClass('output')->html_main .= $this->registry->getClass('output')->global_template->global_frame_wrapper();
		$this->registry->getClass('output')->sendOutput();
	}
	
	/*============================== */
	/* Show the update page          */
    /*===============================*/
	public function showUpdates()
	{
		$error = '';
		/* Load file management class */
		require_once( IPS_KERNEL_PATH . 'classFileManagement.php' );
		$this->classFileManagement = new classFileManagement();
		$return = Array();
		$return = unserialize( $this->classFileManagement->getFileContents( base64_decode("aHR0cDovL3d3dy50dmMtaW5jLm5ldC9zdGF0aWMvdXBkYXRlLnBocD9hcHBLZXk9bG9naW5hcyZ2PQ==").$this->caches['app_cache']['loginas']['app_long_version'] ) );
		/* Check that we actually got data */
		if ( !$return['currentLong'] or !$return['currentShort'] )
		{
			$error = $this->lang->words['comm_error'];
		}
		$return['installedVersion'] = $this->caches['app_cache']['loginas']['app_version'];
		$return['updateAvailable'] = 0;
		/* Determine if there is a newer version available  */
		if ( $return['currentLong'] > $this->caches['app_cache']['loginas']['app_long_version'] )
		{
			$return['updateAvailable'] = 1;
			$return['currentShort'] = $return['currentShort'];
			$return['installedVersion'] = $this->caches['app_cache']['loginas']['app_version'];
		}
		$this->registry->output->html .= $this->html->updatePage( $return, $error );
	}
}
?>