<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/               #
#####################################################
*/
class admin_member_form__loginas implements admin_member_form
{

	/**
	 * Returns content for the page.
	 *
	 * @param    array 				Member data
	 * @return   array 				Array of tabs, content
	*/
	public function getDisplayContent( $member=array(), $tabsUsed=5 )
	{
		return array();
	}
	
	/**
	 * Returns sidebar links for this tab
	 * @param    array 			Member data
	 * @return   array 			Array of links
	 */
	public function getSidebarLinks( $member=array() )
	{
		ipsRegistry::getClass('class_localization')->loadLanguageFile( array( 'admin_logs' ), 'loginas' );
		
		return array(
			array(
				'img'	=> 'applications_addon/other/loginas/skin_cp/appIcon.png',
				'url'	=> 'module=logs&amp;section=logs&do=viewLogs&search=1',
				'title'	=> ipsRegistry::getClass('class_localization')->words['member_form_logs'],
			),
		);
	}
	
	/**
	 * Process the entries for saving and return
	 *
	 * @return   array 				Multi-dimensional array (core, extendedProfile) for saving
	*/
	public function getForSave()
	{
		return array( 'core' => array(), 'extendedProfile' => array() );
	}
}