<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if ( !defined( 'IN_ACP' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

class admin_loginas_bans_bans extends ipsCommand 
{
	public $html;
	
	public function doExecute( ipsRegistry $registry )
	{
		$this->html               = $this->registry->output->loadTemplate( 'cp_skin_loginas' );
		$this->html->form_code    = 'module=bans&amp;section=bans';
		$this->html->form_code_js = 'module=bans&section=bans';
		
		switch( $this->request['do'] )
		{
			case 'ban':
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_addbans' );
				$this->addBan();
				break;
            case 'removeall':
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_removebans' );
				$this->removeAllBans();
				break;
			case 'unban':
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_removebans' );
				$this->removeBan();
				break;
			default:
				$this->registry->getClass('class_permissions')->checkPermissionAutoMsg( 'loginas_viewbans' );
				$this->listBans();
				break;
		}
        $this->registry->output->html .= $this->html->copyright();
		$this->registry->output->html_main .= $this->registry->output->global_template->global_frame_wrapper();
		$this->registry->output->sendOutput();
	}
	
	/*===================================== */
	/* List all current bans               */
    /*=====================================*/
	private function listBans()
	{	
		$start   = intval($this->request['st']);
		$members = array();
		$count = $this->DB->buildAndFetch( array( 'select' => 'count(member_id) as total',
												  'from'   => 'members',
												  'where'  => "members_cache LIKE '%loginas_banned\";i:1%'"
										  )		 );
		$pages = $this->registry->output->generatePagination( array( 'totalItems'        => $count['total'],
																	 'itemsPerPage'      => 20,
																	 'currentStartValue' => $start,
																	 'baseUrl'           => $this->settings['base_url'].$this->html->form_code
															 )		);
		if ( $count['total'] )
		{
			$this->DB->build( array( 'select' => 'member_id, members_display_name, member_group_id',
									 'from'   => 'members',
									 'where'  => "members_cache LIKE '%loginas_banned\";i:1%'",
									 'order'  => 'members_display_name ASC',
									 'limit'  => array( $start, 20 )
							 )		);
			$this->DB->execute();
			while ( $row = $this->DB->fetch() )
			{
				$row['members_display_name'] = IPSMember::makeNameFormatted( $row['members_display_name'], $row['member_group_id'] );
				$row['members_display_name'] = IPSMember::makeProfileLink( $row['members_display_name'], $row['member_id'] );
				$members[] = $row;
			}
		}
		$this->registry->output->html .= $this->html->bansView( $members, $pages );
	}
	
	/*===================================== */
	/* Add a ban                           */
    /*=====================================*/
	private function addBan()
	{
		$member = IPSMember::load( $this->request['member_name'], 'all', 'displayname' );
		if ( !$member['member_id'] )
		{
			$this->registry->output->showError( $this->lang->words['invalid_member'] );
		}
		if ( $member['member_id'] == $this->memberData['member_id'] )
		{
			$this->registry->output->showError( $this->lang->words['cannot_ban_self'] );
		}
		if( $member['g_access_cp'] AND !$this->registry->getClass('class_permissions')->checkPermission( 'loginas_ban_admins') )
		{
			$this->registry->output->showError( $this->lang->words['cannot_ban_admin'] );
		}
		$member['_cache'] = IPSMember::unpackMemberCache( $member['members_cache'] );
		if ( $member['_cache']['loginas_banned'] )
		{
			$this->registry->output->showError( $this->lang->words['already_banned'] );
		}
		IPSMember::packMemberCache( $member['member_id'], array( 'loginas_banned' => 1 ), $member['_cache'] );
		$this->registry->getClass('adminFunctions')->saveAdminLog( $this->lang->words['app_title'].": ".sprintf ($this->lang->words['user_banned'], $member['members_display_name'], $this->memberData['members_display_name'] ) );
		$this->registry->output->global_message = $this->lang->words['user_banned_message'];
		$this->listBans();
	}
	
	/*===================================== */
	/* Remove a ban                        */
    /*=====================================*/
	private function removeBan()
	{
		$member = IPSMember::load( intval($this->request['mid']), 'all' );
		if ( !$member['member_id'] )
		{
			$this->registry->output->showError( $this->lang->words['invalid_member'] );
		}
		if ( $member['member_id'] == $this->memberData['member_id'] )
		{
			$this->registry->output->showError( $this->lang->words['cannot_unban_self'] );
		}
		if( $member['g_access_cp'] AND !$this->registry->getClass('class_permissions')->checkPermission( 'loginas_unban_admins') )
		{
			$this->registry->output->showError( $this->lang->words['cannot_unban_admin'] );
		}
		$member['_cache'] = IPSMember::unpackMemberCache( $member['members_cache'] );
		if ( !$member['_cache']['loginas_banned'] )
		{
			$this->registry->output->showError( $this->lang->words['not_banned'] );
		}
		unset($member['_cache']['loginas_banned']);
		$this->DB->update( 'members', array( 'members_cache' => serialize($member['_cache']) ), 'member_id='.$member['member_id'] );
		$this->registry->getClass('adminFunctions')->saveAdminLog( $this->lang->words['app_title'].": ".sprintf ($this->lang->words['user_unbanned'], $member['members_display_name'], $this->memberData['members_display_name'] ) );
		$this->registry->output->global_message = $this->lang->words['user_unbanned_message'];
		$this->listBans();
	}
    
	/*=====================================*/
	/* Remove all bans                     */
    /*=====================================*/
    private function removeAllBans()
	{
		$member = array();
		$this->DB->build( array( 'select' => 'member_id, members_cache',
                                 'from'   => 'members',
                                 'where'  => "members_cache LIKE '%loginas_banned\";i:1%'",
	                    )	   );
		$e = $this->DB->execute();
        while ( $member = $this->DB->fetch($e) )
        {
            $member['_cache'] = IPSMember::unpackMemberCache( $member['members_cache'] );
            unset($member['_cache']['loginas_banned']);
            $this->DB->update( 'members', array( 'members_cache' => serialize($member['_cache']) ), 'member_id='.$member['member_id'] );
        }
        $this->registry->getClass('adminFunctions')->saveAdminLog( $this->lang->words['app_title'].": ".sprintf( $this->lang->words['all_bans_removed'], $this->memberData['members_display_name'] ) );
		$this->registry->output->global_message = $this->lang->words['all_bans_removed_message'];
		$this->listBans();
	}
}
?>