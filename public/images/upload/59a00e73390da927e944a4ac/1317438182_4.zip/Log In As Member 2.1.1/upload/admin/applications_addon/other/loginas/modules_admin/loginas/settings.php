<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit;
}

class admin_loginas_loginas_settings extends ipsCommand
{
    private $html;
	private $form_code;
	private $form_code_js;
	
	public function doExecute ( ipsRegistry $registry )
	{
		$this->registry->class_permissions->checkPermissionAutoMsg( 'shoutbox_settings_' . $this->request['do'] );

		$classToLoad = IPSLib::loadActionOverloader( IPSLib::getAppDir('core').'/modules_admin/settings/settings.php', 'admin_core_settings_settings' );
		$settings    = new $classToLoad();
		$settings->makeRegistryShortcuts( $this->registry );

		$settings->html         = $this->registry->output->loadTemplate( 'cp_skin_settings', 'core' );
		$settings->form_code	= $settings->html->form_code    = 'module=settings&amp;section=settings';
		$settings->form_code_js	= $settings->html->form_code_js = 'module=settings&section=settings';
		$this->lang->loadLanguageFile( array( 'admin_tools' ), 'core' );
		$this->request['conf_title_keyword'] = 'loginasmember';
		$settings->return_after_save = $this->settings['base_url'] . 'module=loginas&amp;section=settings';
		$settings->_viewSettings();
		$this->registry->output->html_main .= $this->registry->output->global_template->global_frame_wrapper();
		$this->registry->output->sendOutput();
	}
}
?>