<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
class loginas_installCheck
{
	/**
	 * Check for any problems and report errors if any exist
	 *
	 * @return	array
	 */
	public function checkForProblems()
	{
		$this->DB = ipsRegistry::instance()->DB();
		$info  = array( 'notexist' => array(), 'notwrite' => array(), 'other' => array() );
		if ( $this->DB->buildAndFetch( array( 'select' => '*', 'from' => 'core_hooks', 'where' => "hook_key='LogInAsMemberHook'" ) ) )
		{
			$hook = $this->DB->buildAndFetch( array( 'select' => '*', 'from' => 'core_hooks', 'where' => "hook_key='LogInAsMemberHook'" ) );
			if ( intval( $hook['hook_version_long'] ) < intval ( 20000 ) )
			{
				$info['other'][]	= 'You must uninstall version '.$hook['hook_version_human'].' of the hook before installing';
			}
		}
		return $info;
	}
}