<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/                #
#####################################################
*/
if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded 'admin.php'.";
	exit();
}

class profile_loginasTab extends profile_plugin_parent
{
	/**
	 * return HTML block
	 *
	 * @access	public
	 * @param	array		Member information
	 * @return	string		HTML block
	 */
	public function return_html_block( $member=array() ) 
	{
		$this->registry->getClass('class_localization')->loadLanguageFile(array('admin_logs', 'public_login'), 'loginas');
		$mb = IPSMember::load( intval( $this->request['member_id'] ), '' );
		$logs = array();
        $this->DB->build(array('select' => '*', 'from' => 'loginas_logs', 'where' => "admin = '{$member['member_id']}' OR user = '{$member['member_id']}'", 'order' => 'time DESC', 'limit' => 10, ));
        $e = $this->DB->execute();
        while ($log = $this->DB->fetch($e))
        {
            /* Create member formatting and links */
            $adminUser = IPSMember::load( $log['admin'], '' );
			$memberUser = IPSMember::load( $log['user'], '' );
			if ( $adminUser['member_id'] != $member['member_id'] )
			{
				$adminUser['members_display_name'] = IPSMember::makeNameFormatted( $adminUser['members_display_name'], $adminUser['member_group_id'] );
                $adminUser['members_display_name'] = IPSMember::makeProfileLink( $adminUser['members_display_name'], $adminUser['member_id'] );
			}
			if ( $memberUser['member_id'] != $member['member_id'] )
			{
				$memberUser['members_display_name'] = IPSMember::makeNameFormatted( $memberUser['members_display_name'], $memberUser['member_group_id'] );
                $memberUser['members_display_name'] = IPSMember::makeProfileLink( $memberUser['members_display_name'], $memberUser['member_id'] );
			}
			$log['admin'] = $adminUser['members_display_name'];
            $log['user'] = $memberUser['members_display_name'];
            /* Set action string */
            $log['action'] = ($log['action'] == '0') ? $this->lang->words['logged_out_of'] : $this->lang->words['logged_into'];
            /* Set anonymous string */
			$anonymous = ($log['anonymous'] == 1) ? $this->lang->words['yes'] : $this->lang->words['no'];
            if ( $log['anonymous'] == 2 ) $anonymous = $this->lang->words['not_available'];
            $log['anonymous'] = $anonymous;
            /* Add log to array */
            $logs[] = $log;
        }
        if ( count( $logs ) ) return $this->registry->getClass('output')->getTemplate('loginas')->logInAsMemberTab( $logs, '' );
        return $this->registry->getClass('output')->getTemplate('loginas')->logInAsMemberTab( '', $this->lang->words['no_logs'] );
	}
}