<?php
/*
#####################################################
#        (TVC32) Log In As Member v2.1.1            #
#===================================================#
#                Author: Roc13x                     #
#            Copyright (C) 2011 TVC Inc             #
#             http://www.tvc-inc.net/               #
#####################################################
*/
if (!defined('IN_IPB'))
{
    print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
    exit;
}

class admin_loginas_logs_logs extends ipsCommand
{
    public function doExecute(ipsRegistry $registry)
    {
        $this->html = $this->registry->output->loadTemplate('cp_skin_loginas');
        $this->html->form_code    = 'module=logs';
		$this->html->form_code_js = 'module=logs';
        
        switch ($this->request['do'])
        {
            case 'deleteAllLogs':
                $this->registry->getClass('class_permissions')->checkPermissionAutoMsg('loginas_deletelogs');
                $this->deleteAllLogs();
                break;

            case 'deleteSelectedLogs':
                $this->registry->getClass('class_permissions')->checkPermissionAutoMsg('loginas_deletelogs');
                $this->deleteSelectedLogs();
                break;

            default:
                $this->registry->getClass('class_permissions')->checkPermissionAutoMsg('loginas_viewlogs');
                $this->logsView();
                break;
        }
        $this->registry->output->html .= $this->html->copyright();
        $this->registry->getClass('output')->html_main .= $this->registry->getClass('output')->global_template->global_frame_wrapper();
        $this->registry->getClass('output')->sendOutput();
    }

	/*===================================== */
	/* Log Overview/Search Results Screen  */
    /*=====================================*/
    public function logsView()
    {
        $logs = array();
        $st = $this->request['st'] ? $this->request['st'] : 0;
		$this->request['option'] = urldecode( $this->request['option'] );
        $this->request['value'] = $this->DB->addSlashes(urldecode( $this->request['value'] ) );
        if ( $this->request['option'] == 'user' && !is_numeric( $this->request['value'] ) )
        {
            $member = IPSMember::load($this->request['value'], 'member_id', 'displayname');
            $this->request['value'] = $member['member_id'];
        }
        if ($this->request['search'])
        {
			if ( $this->request['member_id'] )
			{
				$this->request['option'] = 'user';
				$this->request['value'] = $this->request['member_id'];
			}
            if ($this->request['option'] == 'user')
            {
                $where = "admin = '{$this->request['value']}' OR user = '{$this->request['value']}'";
            }
            else
            {
                $where = "{$this->request['option']} = '{$this->request['value']}'";
            }
			$count = $this->DB->buildAndFetch(array('select' => 'count(*) as count', 'from' => 'loginas_logs', 'where' => $where));
            $this->DB->build(array('select' => '*', 'from' => 'loginas_logs', 'where' => $where, 'order' => 'time DESC', 'limit' => array($st, 5), ));
            $e = $this->DB->execute();
        }
        else
        {
			$count = $this->DB->buildAndFetch(array('select' => "COUNT(*) as count", 'from' => "loginas_logs"));
			$this->DB->build(array('select' => '*', 'from' => 'loginas_logs', 'limit' => array($st, 5), 'order' => 'time DESC'));
			$e = $this->DB->execute();
        }
        while ($log = $this->DB->fetch($e))
            {
                /* Create member formatting/links */
                $adminUser = IPSMember::load( $log['admin'], 'member_id, members_display_name, member_group_id' );
                $adminUser['members_display_name'] = IPSMember::makeNameFormatted( $adminUser['members_display_name'], $adminUser['member_group_id'] );
                $adminUser['members_display_name'] = IPSMember::makeProfileLink( $adminUser['members_display_name'], $adminUser['member_id'] );
                $log['admin'] = $adminUser['members_display_name'];
                $memberUser = IPSMember::load( $log['user'], 'member_id, members_display_name, member_group_id' );
                $memberUser['members_display_name'] = IPSMember::makeNameFormatted( $memberUser['members_display_name'], $memberUser['member_group_id'] );
                $memberUser['members_display_name'] = IPSMember::makeProfileLink( $memberUser['members_display_name'], $memberUser['member_id'] );
                $log['user'] = $memberUser['members_display_name'];
                /* Set action string */
                $log['action'] = ($log['action'] == '0') ? $this->lang->words['logged_out_of'] : $this->lang->words['logged_into'];
                /* Set anonymous string */
                $anonymous = ($log['anonymous'] == 1) ? $this->lang->words['yes'] : $this->lang->words['no'];
				if ( $log['anonymous'] == 2 ) $anonymous = $this->lang->words['not_available'];
				$log['anonymous'] = $anonymous;
                /* Add log to array */
                $logs[] = $log;
            }
        $encoded = array('option' => urlencode($this->request['option']),
                         'value' => urlencode($this->request['value']),
                         );
        $pagination = $this->registry->output->generatePagination(array('totalItems' => $count['count'],
                                                                        'itemsPerPage' => 5,
                                                                        'currentStartValue' => $st,
                                                                        'baseUrl' => $this->settings['base_url']."module=logs&amp;section=logs&do=viewLogs&amp;searching=1&amp;option={$encoded['option']}&amp;value={$encoded['value']}",
                                                                        ));
        $currentSearch = array('option' => $this->request['option'], 'value' => $this->request['value'], );
        $this->registry->output->html .= $this->html->logsView($logs, $pagination, $currentSearch);
    }

	/*===================================== */
	/* Delete all login logs               */
    /*=====================================*/
    public function deleteAllLogs()
    {
        $this->DB->delete('loginas_logs');
        $this->registry->getClass('adminFunctions')->saveAdminLog( $this->lang->words['app_title'].": ".$this->lang->words['all_removed'] );
		$this->registry->output->global_message = $this->lang->words['all_removed'];
		$this->logsView();
    }

	/*===================================== */
	/* Delete Selected Logs                */
    /*=====================================*/
    public function deleteSelectedLogs()
    {
		$ids = array();
		if ( is_array( $this->request['log_ids'] ) && count( $this->request['log_ids'] ) )
		{
			foreach ( $this->request['log_ids'] as $log_id )
			{
				$ids[] = intval( $log_id );
			}
		}
		if ( !count( $ids ) )
		{
			$this->registry->output->global_message = $this->lang->words['no_ids'];
			$this->logsView();
			return;
		}
		$this->DB->delete( 'loginas_logs', "id IN (".implode( ",", $ids ).")" );
        $this->registry->getClass('adminFunctions')->saveAdminLog( $this->lang->words['app_title'].": ".sprintf( $this->lang->words['deleted_logs'], count( $ids ) ) );
        $this->registry->output->global_message = sprintf( $this->lang->words['deleted_logs'], count( $ids ) );
        $this->logsView();
    }
}

?>