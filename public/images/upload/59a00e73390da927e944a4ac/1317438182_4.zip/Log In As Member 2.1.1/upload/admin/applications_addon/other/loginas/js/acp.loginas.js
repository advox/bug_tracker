ACPLogInAs = {
	init: function()
	{
		Debug.write("Initializing acp.loginas.js");
		
		document.observe("dom:loaded", function(){
			if( $('member_name') )
			{
				ACPLogInAs.autoComplete = new ipb.Autocomplete( $('member_name'), { multibox: false, url: acp.autocompleteUrl, templates: { wrap: acp.autocompleteWrap, item: acp.autocompleteItem } } );
			}
			else if( $('value') )
			{
				ACPLogInAs.autoComplete = new ipb.Autocomplete( $('value'), { multibox: false, url: acp.autocompleteUrl, templates: { wrap: acp.autocompleteWrap, item: acp.autocompleteItem } } );
			}
		});
	}
};

ACPLogInAs.init();