<?php

/**
 *	Profile Statistics Tab
 *
 * @author 		Martin Aronsen
 * @copyright	(c) 2008 - 2011 Invision Modding
 * @web: 		http://www.invisionmodding.com
 * @IPB ver.:	IP.Board 3.2
 * @version:	1.1.0 (11000)
 *
 */

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

class profile_stats extends profile_plugin_parent
{	
	private $offset = 0;
	private $offset_set = 0;
	private $thisMember = array();
	
	public function return_html_block( $member=array() )
	{
		if ( ! is_array( $member ) OR ! count( $member ) )
		{
			return $this->registry->getClass('output')->getTemplate('profile')->tabNoContent( 'err_no_posts_to_show' );
		}

		if( $member['posts'] > 0 )
		{
			// Build a list of readable forums
			$this->readableForums();
			$this->thisMember 	= $member;
			$stats 				= array();
			$content 			= '';
			$postsByHour 		= array();

			/* I only work with GMT */
			$this->DB->query( "SET time_zone='+00:00';" );
			
			$stats['postsByHour'] = array();

			for ( $i=0; $i <= 23; $i++ )
			{
				$hour = ($i < 10) ? (string)'0'.$i.':00' : (string) $i . ':00';

				$postsByHour[ $hour ] = array(
												'hour' => $hour,
												'postCount' => 0,
												'topicCount' => 0,
					);
			}
			
			$this->DB->build( array(
										'select' 	=> "HOUR( FROM_UNIXTIME( post_date ) ) as hour, COUNT(*) AS postCount",
										'from' 		=> 'posts',
										'where' 	=> "new_topic=0 AND author_id=" . $member['member_id'],
										'group' 	=> 'HOUR( FROM_UNIXTIME( post_date ) )',
							) 		);
			$this->DB->execute();

			if ( $this->DB->getTotalRows() )
			{
				while ( $row = $this->DB->fetch() )
				{
					$row['hour'] = $this->dealWithCrappyTimezones( $row['hour'] );
					
					$postsByHour[ $row['hour'] ] = array(
															'hour' 			=> $row['hour'],
															'postCount' 	=> $row['postCount'],
															'topicCount' 	=> 0
					);
				}
			}
			
			
			$this->DB->build( array(
										'select' 	=> "HOUR(FROM_UNIXTIME( start_date ) ) as hour, COUNT(*) AS topicCount",
										'from' 		=> 'topics',
										'where' 	=> "starter_id=" . $member['member_id'],
										'group' 	=> 'HOUR( FROM_UNIXTIME( start_date ) )',
							) 		);
			$this->DB->execute();
			
			if ( $this->DB->getTotalRows() )
			{
				while ( $row = $this->DB->fetch() )
				{
					$row['hour'] = $this->dealWithCrappyTimezones( $row['hour'] );

					$postsByHour[ $row['hour'] ] = array(
															'hour' 			=> $row['hour'],
															'postCount' 	=> intval( $postsByHour[ $row['hour'] ]['postCount'] ) ? $postsByHour[ $row['hour'] ]['postCount'] : 0,
															'topicCount' 	=> $row['topicCount'],
					);
				}
			}
			
			foreach( $postsByHour as $data )
			{
				$data['totalCount'] = $data['postCount'] + $data['topicCount'];

				$stats['postsByHour']['hours'][] = $data;
			}


			/**
			 * Popular boards
			 */

			/* Post count */
			$stats['popularBoards'] = array();

			$this->DB->build( array(	'select' => "t.forum_id, COUNT(p.author_id) AS postCount",
										'from' 	=> array( 'posts' => 'p' ),
										'where' => "p.new_topic=0 AND p.author_id=" . $member['member_id'],
										'group' => 't.forum_id',
										'order'	=> 'postCount DESC',
										'limit'  => array( 0, 10 ),
										'add_join' => array(
															array(
																		'from'	=> array( 'topics' => 't' ),
																		'where'	=> 't.tid=p.topic_id',
																		'type'	=> 'left',
																)
															)
							) 		);

			$this->DB->execute();

			while ( $row = $this->DB->fetch() )
			{
				$stats['popularBoards']['boards'][ $row['forum_id'] ] = array(
																		'postCount' 	=> $row['postCount'],
																		'topicCount' 	=> 0,
				);
			}
			
			/* Topic count */
			$this->DB->build( array(	'select' => "t.forum_id, COUNT(t.starter_id) AS topicCount",
										'from' 	=> array( 'topics' => 't' ),
										'where' => "t.starter_id=" . $member['member_id'],
										'group' => 't.forum_id',
										'order'	=> 'topicCount DESC',
										'limit'  => array( 0, 10 )
							) 		);
			$this->DB->execute();

			while ( $row = $this->DB->fetch() )
			{
				$stats['popularBoards']['boards'][ $row['forum_id'] ] = array(
																		'postCount' 	=> intval( $stats['popularBoards']['boards'][ $row['forum_id'] ]['postCount'] ) ? $stats['popularBoards']['boards'][ $row['forum_id'] ]['postCount'] : 0,
																		'topicCount' 	=> $row['topicCount'],
				);
			}
			
						
			/* Since we do it like this, we may end up with "top forums" without topic/post count */
			$missingTopicCount = array();
			$missingPostCount = array();
			
			foreach ( $stats['popularBoards']['boards'] as $id => &$data )
			{
				if ( $data['postCount'] == 0 )
				{
					$missingPostCount[] = $id;
				}
				
				if ( $data['topicCount'] == 0 )
				{
					$missingTopicCount[] = $id;
				}
				
				/* Populate with forum data */
				$forumData = $this->registry->getClass( 'class_forums' )->forum_by_id[ $id ];
				$url = $this->settings['board_url'] . '/index.php?showforum=' . $forumData['id'];
				$url = ipsRegistry::getClass('output')->buildSEOUrl( $url, 'none', $forumData['name_seo'], 'showforum' );
				
				if ( strtolower( IPS_DOC_CHAR_SET ) != 'utf-8' )
				{
					$forumData['name'] = utf8_encode( $forumData['name'] );
				}
				
				$data['name'] 	= $forumData['name'];
				$data['url']	= $url;
			}
			
			/**
			 *  Get missing topic/post counts 
			 */
			
			if ( count( $missingPostCount ) )
			{
				$this->DB->build( array(	'select' => "t.forum_id, COUNT(p.author_id) AS postCount",
											'from' 	=> array( 'posts' => 'p' ),
											'where' => "p.new_topic=0 AND p.author_id={$member['member_id']} AND t.forum_id IN(" . implode( ',', $missingPostCount ) . ")",
											'group' => 't.forum_id',
											'add_join' => array(
																array(
																			'from'	=> array( 'topics' => 't' ),
																			'where'	=> 't.tid=p.topic_id',
																			'type'	=> 'left',
																	)
																)
								) 		);
				$this->DB->execute();

				while ( $row = $this->DB->fetch() )
				{
					$stats['popularBoards']['boards'][ $row['forum_id'] ]['postCount'] = $row['postCount'];
				}
			}

			if ( count( $missingTopicCount ) )
			{
				$this->DB->build( array(	'select' => "t.forum_id, COUNT(t.starter_id) AS topicCount",
											'from' 	=> array( 'topics' => 't' ),
											'where' => "t.starter_id={$member['member_id']} AND t.forum_id IN(" . implode( ',', $missingTopicCount ) . ")",
											'group'	=> 't.forum_id'
							) 		);

				$this->DB->execute();

				while ( $row = $this->DB->fetch() )
				{
					$stats['popularBoards']['boards'][ $row['forum_id'] ]['topicCount'] = $row['topicCount'];
				}
			}

			/**
			 *  Get the number of topics and polls started 
			 */
			$this->DB->build( array( 'select' => 'tid, poll_state', 'from' => 'topics', 'where' => 'starter_id=' . $member['member_id'] ) );
			$this->DB->execute();

			$topicCount = 0;
			$pollCount = 0;

			while( $row = $this->DB->fetch() )
			{	
				$topicCount++;

				if( $row['poll_state'] == 1 )
				{
					$pollCount++;
				}
			}

			$stats['numTopics'] = ipsRegistry::getClass( 'class_localization' )->formatNumber( $topicCount );
			$stats['numPolls'] = ipsRegistry::getClass( 'class_localization' )->formatNumber( $pollCount );


			/**
			 * Get the number of vote casts 
			 */
			$this->DB->build( array( 'select' => 'COUNT(*) as numVotes', 'from' => 'voters', 'where' => 'member_id='.$member['member_id'] ) );
			$this->DB->execute();
			$row = $this->DB->fetch();

			$stats['numVotes'] = ipsRegistry::getClass( 'class_localization' )->formatNumber( $row['numVotes'] );

			/* Get reputation stats */
			if ( $this->settings['reputation_enabled'] )
			{
				$stats['repPos'] = 0;
				$stats['repNeg'] = 0;
	
				$this->DB->build( array( 'select' => 'COUNT(*) as numRep, rep_rating', 'from' => 'reputation_index', 'group' => 'rep_rating', 'where' => 'member_id='.$member['member_id'] ) );
				$this->DB->execute();
	
				while( $row = $this->DB->fetch() )
				{
					if ( $row['rep_rating'] == 1 )
					{
						$stats['repPos'] += $row['numRep'];
					}
					else if ( $row['rep_rating'] == -1 )
					{
						$stats['repNeg'] += $row['numRep'];
					}
				}
			}

			$stats['repPos'] = ipsRegistry::getClass( 'class_localization' )->formatNumber( $stats['repPos'] );
			$stats['repNeg'] = ipsRegistry::getClass( 'class_localization' )->formatNumber( $stats['repNeg'] );


			/* Hide the forums that the member don't have permission to see */
			foreach( $stats['popularBoards']['boards'] as $id => &$value )
			{
				if( ! in_array( $id, explode( ',', $this->readableForums ) ) )
				{
					unset( $stats['popularBoards']['boards'][ $id ] );
					continue;
				}

				$value['totalCount'] = $value['postCount'] + $value['topicCount'];
			}

			usort( $stats['popularBoards']['boards'], array( $this, '_popularBoardsOrder' ) );

			$_tmp = $stats['popularBoards'];
			$stats['popularBoards'] = array();

			$i = 1;
			foreach( $_tmp['boards'] as $boards )
			{	
				if ( $i > 10 )
				{
					break;
				}

				$stats['popularBoards']['boards'][] = $boards;
				$i++;
			}


			/**
			 *  JSON encode data. Highcharts prefer that
			 *  And PEAR::JSON is the only one that don't break char encoding
			 */
			require_once( IPS_KERNEL_PATH . 'PEAR/JSON/JSON.php' );
			$json = new Services_JSON();

			$stats['postsByHour'] = $json->encode( $stats['postsByHour'] );
			$stats['popularBoards'] = $json->encode( $stats['popularBoards'] );

			$content .= $this->registry->getClass('output')->getTemplate( 'profile' )->tabStatistics( $stats, $member );
		}

		return $content ? $content : $this->registry->getClass('output')->getTemplate('profile')->tabNoContent( 'err_no_posts_to_show' );
	}

	/**
	 * Get the forums we are allowed to read.
	 * 
	 * @access	private
	 * @return	array		Array of forum IDs
	 */
	private function readableForums()
	{
		$forumids = $this->registry->getClass( 'class_forums' )->fetchSearchableForumIds();

		$this->readableForums =  implode( "," , $forumids );
	}

	/**
	 * I don't like timezones. Can you tell?
	 * This method adds the offset to the current hour
	 * 
	 * @access	private
	 * @param	int			1 or 2 digit hour (ex: 1, 2, 10, 17 or 23)
	 * @return	datetime	Formatted hour (ex: 00:00, 16:00 or 23:00)
	 */
	private function dealWithCrappyTimezones( $hour )
	{
		$hour = ($hour < 10) ? (string)'0'.$hour.':00' : (string) $hour . ':00';

		if ( ! $this->offset_set )
		{
			$this->offset = $this->getMyTimeOffset();
			$this->offset_set = 1;
		}

		$date = strtotime( $hour );

		return strftime( '%H:%M', ( $date + $this->offset ) );
	}
	
	/**
	 * The method for getting offset time in class_localization
	 * only works on the visiting member, not for the profile we're viewing
	 * 
	 * @access	private
	 * @return	int		Offset time in seconds
	 */
	private function getMyTimeOffset()
	{
		$r = 0;

    	$this->settings['time_offset']   = ( ! empty( $this->settings['time_offset'] ) ) ? $this->settings['time_offset'] : 0;
    	$this->thisMember['time_offset'] = ( isset( $this->thisMember['time_offset'] ) ) ? $this->thisMember['time_offset'] : null;

    	$r = ( ( $this->thisMember['time_offset'] !== null ) ? $this->thisMember['time_offset'] : $this->settings['time_offset'] ) * 3600;

		if ( $this->settings['time_adjust'] )
		{
			$r += ($this->settings['time_adjust'] * 60);
		}

		if ( isset($this->thisMember['dst_in_use']) AND $this->thisMember['dst_in_use'] )
		{
			$r += 3600;
		}

    	return $r;
	}

	/**
	 * Sorting boards. We want the one with most posts on top
	 *
	 * @access private
	 */
	private function _popularBoardsOrder(array $a, array $b) 
	{
		if ($a['totalCount'] == $b['totalCount'] ) 
		{
   	 		return 0;
		}

		return ($a['totalCount'] > $b['totalCount']) ? -1 : 1;
	}
}