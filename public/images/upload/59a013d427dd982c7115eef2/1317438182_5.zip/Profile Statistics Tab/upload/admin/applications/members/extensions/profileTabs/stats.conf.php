<?php

/**
 *	Profile Statistics Tab
 *
 * @author 		Martin Aronsen
 * @copyright	(c) 2008 - 2011 Invision Modding
 * @web: 		http://www.invisionmodding.com
 * @IPB ver.:	IP.Board 3.2
 * @version:	1.1.0 (11000)
 *
 */

/**
* Plug in name (Default tab name)
*/
$CONFIG['plugin_name']        = 'Stats';

/**
* Language string for the tab
*/
$CONFIG['plugin_lang_bit']    = 'pp_tab_statsTab';

/**
* Plug in key (must be the same as the main {file}.php name
*/
$CONFIG['plugin_key']         = 'stats';

/**
* Show tab?
*/
$CONFIG['plugin_enabled']     = 0;

ipsRegistry::$settings['im_statsTab_group_access'] = IPSText::cleanPermString( ipsRegistry::$settings['im_statsTab_group_access'] );

if ( strstr( ',' . ipsRegistry::$settings['im_statsTab_group_access'] . ',', ",{$this->memberData['member_group_id']}," ) )
{
	$CONFIG['plugin_enabled']     = 1;
}

/**
* Order
*/
$CONFIG['plugin_order'] = 10;