/**
 * IPB3.2 Javascript				
 * --------------------------------------------
 * ips.statisticsTabjs - Statistics Tab JS
 * (c) Invision Modding, 2011				
 * --------------------------------------------- 
 * Author: Invision Modding (Martin Aronsen)		
 **/

var _statisticsTab = window.IPBoard;

_statisticsTab.prototype.statisticsTab = 
{
	init: function()
	{
		Debug.write("Initializing ips.statisticsTab.js");
	},
	
	initCharts: function()
	{
		if ( $( 'chart_popularBoards' ) )
		{
			ipb.statisticsTab.initPopularBoardsChart();
		}
		
		if ( $( 'chart_poststats' ) )
		{
			ipb.statisticsTab.initPostByHourChart();
		}
	},
	
	initPostByHourChart: function()
	{
		json = $( 'chart_poststats_data' ).innerHTML.evalJSON(true);
		ipb.statisticsTab.drawPostsByHourChart( json );
	},
	
	initPopularBoardsChart: function()
	{
		json = $( 'chart_popularBoards_data' ).innerHTML.evalJSON(true);
		ipb.statisticsTab.drawPopularBoardsChart( json );
	},
	
	drawPostsByHourChart: function( json )
	{	
		var options = {
			chart: {
				renderTo: 'chart_poststats',
				zoomType: 'xy',
				margin: [50, 50, 90, 30]
			},
			xAxis: {
				categories: [],
				labels:{
					rotation: 300,
					y: 30
				}
			},
			yAxis: {
         		showFirstLabel: false
			},
			
            legend: {
                style: {
					left: 'auto',
					bottom: 'auto',
					right: '70px',
					top: '10px'
                }
            },
			labels: {
				style: {
					color: '#CCC'
				}
			},
			series: [{
				name: ipb.lang['postByTime-topics'],
				type: 'spline',
				data: []
			},{
				name: ipb.lang['postByTime-posts'],
				type: 'spline',
				data: []
			},{
				name: ipb.lang['postByTime-total'],
				type: 'spline',
				data: []
			}]
		};		
		
		json['hours'].each( function( data )
		{
			options.xAxis.categories.push( data['hour'] );
			options.series[0].data.push( parseInt( data['topicCount'] ) );
			options.series[1].data.push( parseInt( data['postCount'] ) );
			options.series[2].data.push( parseInt( data['totalCount'] ) );
		});
		
		ipb.statisticsTab.buildTheme();
		
		chart = new Highcharts.Chart(options);
	},
	
	drawPopularBoardsChart: function( json )
	{
		var options = {
			chart: {
				renderTo: 'chart_popularBoards',
				type: 'bar',
				zoomType: 'xy'
			},
			credits: {
				enabled: false
			},
			xAxis: {
				categories: [],
				allowDecimals: false,
				labels: {
					style: {
					}
				}
			},
			yAxis: {
				title: {
					align: 'high'
				}
			},
			legend: {
				style: {
					left: 'auto',
					bottom: '20px',
					right: '70px',
					top: 'auto'
				}
			},
			series: [{
				name: ipb.lang['popularBoards-topics'],
				data: []
			},{
				name: ipb.lang['popularBoards-posts'],
				data: []
			},{
				name: ipb.lang['popularBoards-total'],
				data: []
			}]
		};
		
		// Safari go nuts if we set the width of the xAxis labels :( 
		if ( Prototype.Browser.WebKit && !Prototype.Browser.Chrome )
		{
			//alert( 'damn you Safari' );
		}
		else
		{
			options.xAxis.labels.style.width = '80px';
		}
		
		json['boards'].each( function( data )
		{
			data['name'] = data['name'].replace( '&amp;', '&' );

			options.xAxis.categories.push( '<a href="' + data['url'] + '">' + data['name'] + '</a>' );

			options.series[0].data.push( parseInt( data['topicCount'] ) );
			options.series[1].data.push( parseInt( data['postCount'] ) );
			options.series[2].data.push( parseInt( data['totalCount'] ) );
		});

		ipb.statisticsTab.buildTheme();
		chart2 = new Highcharts.Chart(options);
	},
	
	buildTheme: function()
	{
		defaultOptions = {
			chart: {
				backgroundColor: $$( '#statstab .general_box' )[0].getStyle( 'background-color' ),
				width: $( 'profile_content_main' ).getWidth()-30
			},
			title: {
				text: ''
			},
			xAxis: {
				title: {
					text: ''
				},
				labels: {
					style: {
						color: $$( '#statstab .general_box' )[0].getStyle( 'color' ),
						fontFamily: 'Trebuchet MS, Verdana, sans-serif',
                        fontSize: '11px'
					}
				}
			},
			yAxis: {
				min:0,
				title: {
					text: ''
				},
				labels: {
					formatter: function() {
						return Highcharts.numberFormat(this.value, 0);
					}
				}
			},
			legend: {
				backgroundColor: '#FFFFFF',
				borderColor: '#CCC',
				borderWidth: 2,
				shadow: true,
				floating: true
			},
			tooltip: {
				formatter: function() {
					return '<strong>' + this.series.name + '</strong><br/>' + this.x +' : '+ this.y;
				}
			},
			plotOptions: {
				spline: {
					marker: {
						lineColor: '#333',
						enabled: true
					}
				},
				bar: {
					dataLabels: {
						enabled: false,
						color: 'auto'
					}
				}
			}
		};
		
		highChartOptions = Highcharts.setOptions( defaultOptions );
	}
}
ipb.statisticsTab.init();