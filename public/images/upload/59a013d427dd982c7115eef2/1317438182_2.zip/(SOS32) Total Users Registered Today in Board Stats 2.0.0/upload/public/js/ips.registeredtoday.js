var _idx = window.IPBoard;

_idx.prototype.registeredtoday = {
	totalChecked:		0,
	lastFileId:			0,
	lastScreenshotId:	0,
	downloaderPopups:	new Hash,
	popup: {},
	
	/*------------------------------*/
	/* Constructor 					*/
	init: function()
	{
		Debug.write("Initializing ips.registeredtoday.js");
		
		document.observe("dom:loaded", function(){
			ipb.registeredtoday.initEvents();
		});
	},

	initEvents: function()
	{
		ipb.delegate.register('.registered-today' , ipb.registeredtoday.showDownloaderPopup );
	},

	showDownloaderPopup: function(e)
	{
		Event.stop(e);
		
		var elem	= Event.findElement(e, 'a');
		var thisId = parseInt( $(elem).id.replace( /^registered\-today\-/g, '' ) );

		if( ipb.registeredtoday.downloaderPopups.get(thisId) )
		{
			ipb.registeredtoday.downloaderPopups.get(thisId).show();
		}
		else
		{
			ipb.registeredtoday.downloaderPopups.set( thisId, new ipb.Popup( 'view_downloads_' + thisId, {
		 												type: 'balloon',
		 												ajaxURL: ipb.vars['base_url'] + '&app=forums&module=ajax&secure_key=' + ipb.vars['secure_hash'] + '&section=stats&do=regtoday&id=' + thisId,	 												
		 												stem: true,
														hideAtStart: false,
		 												attach: { target: elem, position: 'auto' },
		 												w: '400px'
													}) );
		}
		
		return false;
	}
};

ipb.registeredtoday.init();