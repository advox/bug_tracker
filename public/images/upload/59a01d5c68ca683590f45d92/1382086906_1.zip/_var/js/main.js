function okno(adres,nazwa,szer,wys) {
	var left = (screen.width-szer)/2;
	left = Math.round(left);
	var top = (screen.height-wys-100)/2;
	top = Math.round(top);
	nazwa = window.open(adres,nazwa,'resizable=0,height='+wys+',width='+szer+',top='+top+',left='+left);
	nazwa.moveTo(left,top);
	nazwa.focus();
}
	
function openfull(parametr){
w = window.open(parametr, "", "scrollbars=yes,resizable=yes,menubar=no", true);
w.focus ();
}	

function PoliczRate(koszyk) { 
	var price = document.getElementById('productPrice').value;
	window.open('http://www.zagiel.com.pl/kalkulator/index_smart.php?action=getklientdet_si_rata&shopNo=28011111&goodsValue='+price, 'Policz_rate', 'width=630,height=500,directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,toolbar=no');
}

function hours(obj) {
for(var i = 0; i < obj.length; i++) {
if(obj.substring(i, i + 1) == ":") break;
}
return(obj.substring(i + 1, obj.length));
}

 
function minutes(obj) {
for(var i = 0; i < obj.length; i++) {
if(obj.substring(i, i + 1) == ":") break;
}
return(obj.substring(i + 1, obj.length));
}
 
function seconds(obj) {
for(var i = 0; i < obj.length; i++) {
if(obj.substring(i, i + 1) == ":") break;
}
return(obj.substring(i + 1, obj.length));
}
 
function dis(dni,godzin,minut,sekund) {
var disp;
godzin += dni * 24;
if(godzin > 0) {
if(godzin <= 9) { disp = " "; } else { disp = " "; }
disp += godzin + " hours </b>and<b> ";
}
if(minut > 0) {
if(disp != undefined)
{ if(minut <= 9) { disp += minut + " min."; } else { disp += minut + " min."; } }
else
{ if(minut <= 9) { disp = minut + " min."; } else { disp = minut + " min."; } }
}
//if(sekund <= 9) { disp += "0" + sekund; } else { disp += sekund; }
return('<b>'+disp+'</b>');
}
 
function zmniejsz() {
sekund--;
if(sekund == -1) { sekund = 59; minut--; }
if(minut == -1) { minut = 59; godzin--; }
if(godzin == -1) { godzin = 23; dni--; }
 
document.getElementById('clock2').innerHTML = dis(dni,godzin,minut,sekund);
if((godzin == 0) && (minut == 0) && (sekund == 0) && (dni == 0)) {
} else {
setTimeout("zmniejsz()",1000);
}
}

function fillstars(stars)
{
    if(stars > 0)
    {    
    document.getElementById('stars').innerHTML = '<img src="_images/stars/stars_'+stars+'_0.gif">';
    }
    else
    {
    document.getElementById('stars').innerHTML = 'On a scale of 1 to 5, with 5 being the best.';
    }
}

function disableSelection(target){
if (typeof target.onselectstart!="undefined") //IE route
target.onselectstart=function(){return false}
else if (typeof target.style.MozUserSelect!="undefined") //Firefox route
target.style.MozUserSelect="none"
else //All other route (ie: Opera)
target.onmousedown=function(){return false}
target.style.cursor = "default"
}

function Set_Cookie( name, value, expires, path, domain, secure )
{
// set time, it's in milliseconds
var today = new Date();
today.setTime( today.getTime() );

/*
if the expires variable is set, make the correct
expires time, the current script below will set
it for x number of days, to make it for hours,
delete * 24, for minutes, delete * 60 * 24
*/
if ( expires )
{
expires = expires * 1000 * 60 * 60 * 24;
}
var expires_date = new Date( today.getTime() + (expires) );

document.cookie = name + "=" +escape( value ) +
( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
( ( path ) ? ";path=" + path : "" ) +
( ( domain ) ? ";domain=" + domain : "" ) +
( ( secure ) ? ";secure" : "" );
}

// this fixes an issue with the old method, ambiguous values
// with this test document.cookie.indexOf( name + "=" );
function Get_Cookie( check_name ) {
	// first we'll split this cookie up into name/value pairs
	// note: document.cookie only returns name=value, not the other components
	var a_all_cookies = document.cookie.split( ';' );
	var a_temp_cookie = '';
	var cookie_name = '';
	var cookie_value = '';
	var b_cookie_found = false; // set boolean t/f default f

	for ( i = 0; i < a_all_cookies.length; i++ )
	{
		// now we'll split apart each name=value pair
		a_temp_cookie = a_all_cookies[i].split( '=' );


		// and trim left/right whitespace while we're at it
		cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');

		// if the extracted name matches passed check_name
		if ( cookie_name == check_name )
		{
			b_cookie_found = true;
			// we need to handle case where cookie has no value but exists (no = sign, that is):
			if ( a_temp_cookie.length > 1 )
			{
				cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
			}
			// note that in cases where cookie is initialized but no value, null is returned
			return cookie_value;
			break;
		}
		a_temp_cookie = null;
		cookie_name = '';
	}
	if ( !b_cookie_found )
	{
		return null;
	}
}

function boxCookie(box)
{
    if(Get_Cookie(box) == 1)
    {
    Set_Cookie(box, "0", "90", "/", ".powerbodyshop.co.uk", "0");
    }
    else
    {
    Set_Cookie(box, "1", "90", "/", ".powerbodyshop.co.uk", "0");
    }
}
