$(document).ready(function(){
    currentTime = new Date();
    var lastAction = parseInt(currentTime.getTime()/1000);
    var idleTime = 0;
    var ceepCounting = true;
    var triggerTime = 60;
    var allowClose = true;
    
    $(window).mousemove(function(){
	currentTime = new Date();
	lastAction = parseInt(currentTime.getTime()/1000);
    })
    
    function closePopup(){
	$(".popupContent").stop(true,true).fadeOut('slow',function(){
	    $(".popupLock").stop(true,true).fadeOut('slow',function(){
		$(this).remove();
	    })
	})
    }
    
    function putContent(target,callback){
	$.post("/",{ajax:true,getPopupContent:true},function(data){
	    target.html(data);
	    bindForm(target);
	    bindClose(target);
	    callback(target);
	})
    }
    
    function bindForm(target){
	target.find("form").find('input[type="text"]').focus();
	target.find("form").find('input[type="submit"]').click(function(e){
	    e.preventDefault();
	    $.post("/",{ajax:true,setconversion:true,data:target.find("form").find('input[type="text"]').val()},function(response){
		target.html(response);
		bindClose(target);
		bindForm(target);
	    })
	})
    }
    
    function bindClose(target){
	target.find(".close").click(function(e){
	    e.preventDefault();
	    closePopup();
	})
    }
    
    function placeInMiddle(elem){
	elemHeight = elem.height();
	elemPadding = (parseInt(elem.css('paddingTop').replace('px',''))+parseInt(elem.css('paddingBottom').replace('px','')))/2;
	parentHeight = elem.parent().height();
	elem.css('marginTop',((parseInt(parentHeight)/2)-(parseInt(elemHeight)/2)-elemPadding)+'px');
    }
    
    function addPopupContent(target){
	elem = $("<div>")
	    .addClass('popupContent')
	    .click(function(){
		allowClose = false;
	    });
	putContent(elem,function(){
	    elem.show(0,function(){
		$(this).find("form").find('input[type="text"]').focus();
	    });
	});
	target.append(elem);
	placeInMiddle(elem);
    }
    
    function lockBackground(){
	lock = $("<div>")
	    .addClass('popupLock')
	    .fadeIn('slow',function(){
		addPopupContent(lock);
	    })
	    .click(function(){
		if (allowClose == true){
		    closePopup();
		}
		allowClose = true;
	    })
	$("body").append(lock);
    }
    
    function addPopupCSS(){
	$("head").append("<link>");
	css = $("head").children(":last");
	css.attr({
	  rel:  "stylesheet",
	  type: "text/css",
	  href: "/js/popup/css/popup.css"
	});
	$("head").append("<link>");
	css = $("head").children(":last");
	css.attr({
	  rel:  "stylesheet",
	  type: "text/css",
	  href: "http://fonts.googleapis.com/css?family=Coda"
	});
    }
    
    function checkIdleTime(){
	currentTime = new Date();
	idleTime = parseInt(currentTime.getTime()/1000) - lastAction;
    }
    
    function runTrigger(){
	if ($.cookie('mailpp')==null){
	    addPopupCSS();
	    lockBackground();
	    $.cookie('mailpp',true, {expires: 91});
	}
    }
    
    function checkTrigger(){
	if (idleTime > triggerTime){
	    ceepCounting = false;
	    runTrigger();
	}
    }
    
    function runCheckIdleTime(){
	if (ceepCounting == true){
	    checkIdleTime();
	    checkTrigger();
	    setTimeout(function(){
		runCheckIdleTime();
	    }, 1000);
	}
    }
    
    setTimeout(function(){
	runCheckIdleTime();
    }, 1000);
})