<?php

$DEFAULT_SECTION = 'pages';