<?php

$SQL[] = "ALTER TABLE dp23_cuspg ADD cp_position TINYINT(3) NOT NULL DEFAULT '1';";

?>