<?php

$DEFAULT_SECTION = 'display';