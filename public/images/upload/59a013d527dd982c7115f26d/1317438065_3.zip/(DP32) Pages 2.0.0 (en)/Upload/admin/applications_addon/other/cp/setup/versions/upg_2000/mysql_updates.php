<?php

$TABLE[] = "ALTER TABLE dp23_cuspg ADD cp_is_js tinyint(1) NOT NULL DEFAULT '0'";
$TABLE[] = "ALTER TABLE dp23_cuspg ADD cp_show_in_top tinyint(1) NOT NULL DEFAULT '0'";