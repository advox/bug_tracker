<?php

$DEFAULT_SECTION = 'manage';