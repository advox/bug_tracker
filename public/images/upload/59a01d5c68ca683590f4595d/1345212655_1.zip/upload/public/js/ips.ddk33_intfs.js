
var _getNotificationsCnt = window.IPBoard;

_getNotificationsCnt.prototype.getNotificationsCnt = {
	ajaxHandler: '',
	updateInterval: '',
	
	init: function()
	{
		document.observe( 'dom:loaded', function()
		{	
			if( $('notify_link') )
			{
				$( 'notify_link' ).observe( 'click', function() {
					intfs_cur_notifications_cnt = 0;
					ipb.getNotificationsCnt.refreshCounters();
				});
			}
			
			if( $('inbox_link') )
			{
				$( 'inbox_link' ).observe( 'click', function() {
					intfs_cur_pms_cnt = 0;
					ipb.getNotificationsCnt.refreshCounters();
				});
			}
			
			ipb.getNotificationsCnt.ajaxHandler = new Ajax.PassivePeriodicalUpdater( ipb.vars['base_url'] + '&app=core&module=ajax&section=getNotificationsCnt',
			{
				method: 'post',
				frequency: ipb.getNotificationsCnt.updateInterval,
				decay: 1,
				evalJSON: 'force',
				parameters: {
					secure_key: 	ipb.vars['secure_hash']
				},
				hideLoader: true,
				onSuccess: function(t)
				{					
					if ( t.responseJSON['ntfs_cnt'] != null && t.responseJSON['pms_cnt'] != null )
					{
						intfs_cur_notifications_cnt = parseInt(t.responseJSON['ntfs_cnt']);
						intfs_cur_pms_cnt = parseInt(t.responseJSON['pms_cnt']);
						
						ipb.getNotificationsCnt.refreshCounters();
					}
					return;
				}
			});
		});
	},
	refreshCounters: function()
	{
		var ttl_ntfs = intfs_cur_notifications_cnt + intfs_cur_pms_cnt;
		
		if( ttl_ntfs > 0 ) 
			document.title = '(' + ttl_ntfs + ') ' + intfs_orig_title;
		else
			document.title = intfs_orig_title;
		
		if( $('notify_link') )
		{
			if( intfs_cur_notifications_cnt > 0 )
			{
				if( !$('notify_link').down('.ipsHasNotifications') )
					$('notify_link').insert('<span class="ipsHasNotifications"></span>');
					
				$('notify_link').down('.ipsHasNotifications').update( intfs_cur_notifications_cnt );
			}
			else
			{
				if( $('notify_link').down('.ipsHasNotifications') )
					$('notify_link').down('.ipsHasNotifications').remove();
			}
		}
		
		if( $('inbox_link') )
		{
			if( intfs_cur_pms_cnt > 0 )
			{
				if( !$('inbox_link').down('.ipsHasNotifications') )
					$('inbox_link').insert('<span class="ipsHasNotifications"></span>');
					
				$('inbox_link').down('.ipsHasNotifications').update( intfs_cur_pms_cnt );
			}
			else
			{
				if( $('inbox_link').down('.ipsHasNotifications') )
					$('inbox_link').down('.ipsHasNotifications').remove();
			}
		}
	}
};

//------------------------------
// @author: adrianscott
// http://www.fluther.com/disc/9117/ajaxperiodicalupdater-only-update-if-the-content-has-changed/#quip58902
//------------------------------
Ajax.PassivePeriodicalUpdater = Class.create(Ajax.Base, 
{
	initialize: function($super, url, options) 
	{
		$super(options);
		this.onComplete = this.options.onComplete;
		this.frequency = this.options.frequency;
		this.decay = this.options.decay;
		this.updater = { };
		this.url = url;
		this.firstRun = 1;

		this.start();
	},
		
	start: function() 
	{
		this.options.onComplete = this.updateComplete.bind(this);
		this.onTimerEvent();
	},
		
	stop: function() 
	{
		if ( this.updater == undefined )
		{
			this.updater.options.onComplete = Prototype.emptyFunction;
		}
		
		clearTimeout(this.timer);
		this.decay = this.options.decay;
		
		(this.onComplete || Prototype.emptyFunction).apply(this, arguments);

	},
	
	updateComplete: function(t) 
	{
		this.timer = this.onTimerEvent.bind(this).delay( this.decay * this.frequency );
	
		return true;
	},
		
	onTimerEvent: function() {
	 	
		this.updater = new Ajax.Request( this.url, this.options );
	}
});

ipb.getNotificationsCnt.init();