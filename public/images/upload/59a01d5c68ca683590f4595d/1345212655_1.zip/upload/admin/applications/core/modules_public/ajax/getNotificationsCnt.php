<?php

/**
 * Part of hook:		(DDK33) Notifications count in page title
 * Hook version:		>= 2.0.0
 * Author:				Ibragim Pupkevich
 * Email:				ibragim.pupkevich@gmail.com
 */

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

class public_core_ajax_getNotificationsCnt extends ipsAjaxCommand 
{
	public function doExecute( ipsRegistry $registry )
	{
		switch( $this->request['do'] )
		{
			default:
				return $this->getNotificationsCnt();
			break;
		}
	}
	
	public function getNotificationsCnt()
	{
		
		$ntfs_cnt = ($this->memberData['member_id']) ? $this->memberData['notification_cnt'] : 0;
		$pms_cnt = ($this->memberData['member_id']) ? $this->memberData['msg_count_new'] : 0;		

		$this->returnJsonArray( array( 'ntfs_cnt' => $ntfs_cnt, 'pms_cnt' => $pms_cnt ) );
	}
}