<?php

class realstats_upgradeScript
{
        /**
         * Constructor
         *
         * @param       object          Registry object
         * @return      @e void
         */
         public function __construct( ipsRegistry $registry )
         {
                /* Make object */
                $this->registry =  $registry;
                $this->DB          =  $this->registry->DB();
                $this->settings =& $this->registry->fetchSettings();
                $this->request  =& $this->registry->fetchRequest();
                $this->cache    =  $this->registry->cache();
                $this->caches   =& $this->registry->cache()->fetchCaches();
         }
        
        /**
         * Execute selected method
         *
         * @return      @e void
         */
        public function run()
        {
//drop that cache!
$this->cache->setCache( 'realstats_cache', array(), array( 'array' => 1, 'deletefirst' => 1, 'donow' => 1 ) );
//and drop the last time.
$this->DB->update('cache_store', array('cs_updated' => 0), "cs_key='realstats_cache'");
         //-----------------------------------------
                // Return
                //-----------------------------------------
                
                $this->registry->output->addMessage( "Statistics Cache Dropped." );                 
                return true;
        }
}
