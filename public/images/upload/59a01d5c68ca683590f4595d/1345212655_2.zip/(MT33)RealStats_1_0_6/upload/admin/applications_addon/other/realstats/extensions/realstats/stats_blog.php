<?php
/**
* Real Stats Module for BLOGS
*
*/
/**
 * @ Application : 		RealStats
 * @ File : 			stats_blog.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class stats_blog implements iRealStats
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	/**
	 * CONSTRUCTOR
	 *
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		if ( ! $this->registry )
		{
			/* Make registry objects */
			$this->registry		=  $registry;
			$this->DB			=  $this->registry->DB();
			$this->settings		=& $this->registry->fetchSettings();
			$this->request		=& $this->registry->fetchRequest();
			$this->lang			=  $this->registry->getClass('class_localization');
			$this->member		=  $this->registry->member();
			$this->memberData	=& $this->registry->member()->fetchMemberData();
			$this->cache		=  $this->registry->cache();
			$this->caches		=& $this->registry->cache()->fetchCaches();
		}
	}
	

	
	/**
	 * Returns the data for the app landing items
	 * Data should be an array of stats to show
	 *
	 * @return	array(stats)
	 */
	public function fetchGeneralStats()
	{
		/* INIT */
		$stats_output = array();
		if( !$this->caches['blog_stats'] )
		{
			$this->caches['blog_stats'] = $this->cache->getCache('blog_stats');
		}
		$stats = $this->caches['blog_stats'];
		

$stats_output['num_blogs'] =  intval($stats['stats_num_blogs'] );
$stats_output['num_entries'] = intval( $stats['stats_num_entries'] );
$stats_output['num_comments'] = intval( $stats['stats_num_comments'] );
$stats_output['avg_blogs'] = round($stats_output['num_blogs']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['avg_entries'] = round($stats_output['num_entries']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['avg_comments'] = round($stats_output['num_comments']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['last_blogger']	= intval($stats['stats_last_blog_mid']);
$stats_output['last_blog'] = array('blog_id' => intval( $stats['stats_last_blog_id'] ), 'blog_name' => $stats['stats_last_blog_name'], 'blog_seo_name' => $stats['seo_stats_last_blog_name']);
		return $stats_output;
	}
public function formatGeneralStats($data)
	{
foreach($data as $key => $val)
{
switch($key)
{
case 'num_blogs':
case 'num_entries':
case 'num_comments':
$data[$key] = $this->lang->formatNumber($val);
break;
case 'avg_blogs':
case 'avg_entries':
case 'avg_comments':
$data[$key] = $this->lang->formatNumber($val, 2);
break;
case 'last_blogger':
$data[$key] = $this->registry->output->getTemplate( 'global')->userHoverCard(IPSMember::load($val));
break;
case 'last_blog':
$data[$key] = "<a href='".$this->registry->output->buildSEOUrl( 'app=blog&amp;module=display&amp;section=blog&amp;blogid=' .$val['blog_id'], 'public', $val['blog_seo_name'], 'showblog' )."' title='{$val['blog_name']}'>{$val['blog_name']}</a>";
break;
}
}
return $data;
}
public function fetchDetailedStats($limit)
	{
$this->registry->getAppClass('blog');
$_topBlogsbyViews = array();
$_topBlogsbyReply = array();
$_topBlogsbyRate = array();
$_topEntriesbyRate = array();
$_topSubmitters = array();
$_topEntriesbyViews = array();
$_topEntriesbyReply = array();
		/* Load parsing lib */
		$classToLoad = IPSLib::loadLibrary( IPSLib::getAppDir('blog') . '/sources/parsing.php', 'blogParsing', 'blog' );
		$this->registry->setClass( 'blogParsing', new $classToLoad( $this->registry, null ) );
		
		/* INIT */
		$query    = array();
$Query    = array();
	
		$max      = $limit;
		$st       = 0;
		

	
		
		if ( !$this->member->getProperty('g_is_supmod') and !$this->memberData['_blogmod']['moderate_can_disable'])
		{
			$query[] = "b.blog_disabled = 0";
		}

		if ( ! $this->member->getProperty('member_id') )
		{
			$query[] = "b.blog_allowguests = 1";
		}
		
		/* Perm blogs */
		$query[] = "( ( b.blog_owner_only=1 AND b.member_id="  . intval( $this->memberData['member_id'] ) . " ) OR b.blog_owner_only=0 ) AND ( FIND_IN_SET("  . $this->memberData['member_id'] .  ", b.blog_authorized_users) OR b.blog_authorized_users IS NULL )";
$Query['select'] = 'b.*, b.blog_id as blog_id_id, CASE when b.blog_rating_count > ' . intval( $this->settings[ 'blog_rating_treshhold' ] ) . ' THEN (b.blog_rating_total/b.blog_rating_count) else 0 end as blog_rating, CASE when e.entry_rating_count > ' . intval( $this->settings[ 'blog_rating_treshhold' ] ) . ' THEN (e.entry_rating_total/e.entry_rating_count) else 0 end as entry_rating';
$Query['from'] = array( 'blog_blogs' => 'b' );
		/* Got a query */
		if ( count( $query ) )
		{
			$Query['where'] = implode( ' AND ', $query );
		}
$Query['order'] = 'blog_rating desc, blog_rating_count desc';
$Query['limit'] = array( $st, $max );
		$Query['add_join'] = array(array( 'select'	=> 'bl.*',
															 'from'	    => array( 'blog_lastinfo' =>'bl' ),
															 'where'    => 'b.blog_id=bl.blog_id',
															 'type'	    => 'left' ), 
								 					 array( 'select'	=> 'e.*',
															 'from'	    => array( 'blog_entries' =>'e' ),
															 'where'    => 'e.entry_id=bl.blog_last_entry',
															 'type'	    => 'left' ),
					);
		$this->DB->build( $Query );
		$o = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $o ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topBlogsbyRate[ ]    = $blog;
		}
 $this->DB->freeResult( $o );
$Query['order'] = 'b.blog_num_views DESC';
	$this->DB->build( $Query );
		$ob = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $ob ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topBlogsbyViews[ ]    = $blog;
		}
 $this->DB->freeResult( $ob );
$Query['order'] = 'bl.blog_num_comments DESC';
	$this->DB->build( $Query );
		$og = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $og ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topBlogsbyReply[ ]    = $blog;
		}
 $this->DB->freeResult( $og );
$Query['order'] = 'bl.blog_num_entries DESC';
	$this->DB->build( $Query );
		$ogman = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $ogman ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topSubmitters[ ]    = $blog;
		}
 $this->DB->freeResult( $ogman );
		$Query['add_join'] = array(array( 'select'	=> 'bl.*',
															 'from'	    => array( 'blog_lastinfo' =>'bl' ),
															 'where'    => 'b.blog_id=bl.blog_id',
															 'type'	    => 'left' ), 
								 					 array( 'select'	=> 'e.*',
															 'from'	    => array( 'blog_entries' =>'e' ),
															 'where'    => 'e.blog_id=b.blog_id',
															 'type'	    => 'left' ),
					);
$Query['order'] = 'entry_rating DESC, entry_rating_count DESC';
	$this->DB->build( $Query );
		$ogcaveman = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $ogcaveman ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topEntriesbyRate[ ]    = $blog;
		}
 $this->DB->freeResult( $ogcaveman );
$Query['order'] = 'e.entry_views DESC';
	$this->DB->build( $Query );
		$ogcavemanzabada = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $ogcavemanzabada ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topEntriesbyViews[ ]    = $blog;
		}
 $this->DB->freeResult( $ogcavemanzabada );
$Query['order'] = 'e.entry_num_comments DESC';
	$this->DB->build( $Query );
		$ogfinally = $this->DB->execute();
		
		while( $blog = $this->DB->fetch( $ogfinally ) )
		{
			/* MySQL thing */
			$blog['blog_id'] = ( $blog['blog_id_id'] ) ? $blog['blog_id_id'] : $blog['blog_id'];
			
			/* Skin External blog with no url */
			if( $blog['blog_type'] == 'external' && ! $blog['blog_exturl'] )
			{
				continue;
			}
			
			/* Format Blog Data */
			$blog = $this->registry->getClass('blogFunctions')->buildBlogData( $blog );

			
			

			$_topEntriesbyReply[ ]    = $blog;
		}
 $this->DB->freeResult( $ogfinally );
if ( is_array( $_topBlogsbyRate ) AND count( $_topBlogsbyRate ) )
		{
foreach($_topBlogsbyRate as &$blog)
{
$blog['rating'] = intval((intval($blog['blog_rating_count'] )>0)?round($blog['blog_rating_total']/$blog['blog_rating_count']):$blog['blog_rating_total']);
$blog['blog_seo_name'] = IPSText::makeSeoTitle($blog['blog_name']);
foreach($blog as $key => $val)
{
if(!in_array($key, array('blog_id', 'blog_name', 'member_id', 'blog_type', 'blog_seo_name', 'blog_exturl', 'rating', 'blog_last_edate')))
{
unset($blog[$key]);
}
}
}
}
if ( is_array( $_topBlogsbyViews ) AND count( $_topBlogsbyViews ) )
		{
foreach($_topBlogsbyViews as &$blog)
{
$blog['blog_seo_name'] = IPSText::makeSeoTitle($blog['blog_name']);
$blog['views'] = intval($blog['blog_num_views']+$blog['blog_num_exthits']);
foreach($blog as $key => $val)
{
if(!in_array($key, array('blog_id', 'blog_name', 'views', 'member_id', 'blog_type', 'blog_seo_name', 'blog_exturl', 'blog_last_edate')))
{
unset($blog[$key]);
}
}
}
}
if ( is_array( $_topBlogsbyReply ) AND count( $_topBlogsbyReply ) )
		{
foreach($_topBlogsbyReply as &$blog)
{
$blog['blog_seo_name'] = IPSText::makeSeoTitle($blog['blog_name']);
$blog['comments'] = intval($blog['blog_num_comments']);
foreach($blog as $key => $val)
{
if(!in_array($key, array('blog_id', 'blog_name', 'comments', 'member_id', 'blog_type', 'blog_seo_name', 'blog_exturl', 'blog_last_edate')))
{
unset($blog[$key]);
}
}
}
}
if ( is_array($_topSubmitters ) AND count( $_topSubmitters ) )
		{
foreach($_topSubmitters as &$blog)
{
$blog['member_id'] = intval($blog['member_id']);
$blog['entries'] = intval($blog['blog_num_entries']);
foreach($blog as $key => $val)
{
if(!in_array($key, array('entries', 'member_id')))
{
unset($blog[$key]);
}
}
}
}
if ( is_array($_topEntriesbyRate ) AND count( $_topEntriesbyRate ) )
		{
foreach($_topEntriesbyRate as &$entry)
{
$entry['member_id'] = intval($entry['entry_author_id']);
$entry['rating'] = intval((intval($entry['entry_rating_count'] )>0)?round($entry['entry_rating_total']/$entry['entry_rating_count']):$entry['entry_rating_total']);
foreach($entry as $key => $val)
{
if(!in_array($key, array('blog_id', 'entry_name', 'rating', 'member_id', 'entry_date', 'entry_id', 'entry_name_seo')))
{
unset($entry[$key]);
}
}
}
}
if ( is_array($_topEntriesbyViews ) AND count( $_topEntriesbyViews ) )
		{
foreach($_topEntriesbyViews as &$entry)
{
$entry['member_id'] = intval($entry['entry_author_id']);
$entry['views'] = intval($entry['entry_views']);
foreach($entry as $key => $val)
{
if(!in_array($key, array('blog_id', 'entry_name', 'views', 'member_id', 'entry_date', 'entry_id', 'entry_name_seo')))
{
unset($entry[$key]);
}
}
}
}
if ( is_array($_topEntriesbyReply ) AND count( $_topEntriesbyReply ) )
		{
foreach($_topEntriesbyReply as &$entry)
{
$entry['member_id'] = intval($entry['entry_author_id']);
$entry['comments'] = intval($entry['entry_num_comments']);
foreach($entry as $key => $val)
{
if(!in_array($key, array('blog_id', 'entry_name', 'comments', 'member_id', 'entry_date', 'entry_id', 'entry_name_seo')))
{
unset($entry[$key]);
}
}
}
}
return array('topBlogsByView' => $_topBlogsbyViews, 'topBlogsByReply' => $_topBlogsbyReply, 'topBlogsbyRate' => $_topBlogsbyRate, 'topEntriesByViews' => $_topEntriesbyViews, 'topEntriesByReply' => $_topEntriesbyReply, 'topEntriesByRate' => $_topEntriesbyRate, 'topBloggers' => $_topSubmitters);
}
public function returnDetailedStats($data)
{
//preproccess members
static $proccessedMembers = array();
if ( is_array(  $data['topBloggers'] ) AND count(  $data['topBloggers'] ) )
		{
foreach( $data['topBloggers'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topEntriesByReply'] ) AND count(  $data['topEntriesByReply'] ) )
		{
foreach( $data['topEntriesByReply'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topEntriesByViews'] ) AND count(  $data['topEntriesByViews'] ) )
		{
foreach( $data['topEntriesByViews'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topEntriesByRate'] ) AND count(  $data['topEntriesByRate'] ) )
		{
foreach( $data['topEntriesByRate'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topBlogsByView'] ) AND count(  $data['topBlogsByView'] ) )
		{
foreach( $data['topBlogsByView'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topBlogsByReply'] ) AND count(  $data['topBlogsByReply'] ) )
		{
foreach( $data['topBlogsByReply'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topBlogsbyRate'] ) AND count(  $data['topBlogsbyRate'] ) )
		{
foreach( $data['topBlogsbyRate'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
return $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsApp_blog($data['topBlogsByView'], $data['topBlogsByReply'], $data['topBlogsbyRate'], $data['topEntriesByViews'], $data['topEntriesByReply'], $data['topEntriesByRate'], $data['topBloggers'], $data['truncate']);
}

}
