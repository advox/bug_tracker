<?php
/**
 * @ Application : 		RealStats
 * @ File : 			coreVariables.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
$CACHE['realstats_cache'] = array(
                'array' => 1,
                'default_load'   => 0,
                'recache_file'   => IPSLib::getAppDir( 'realstats' ) . '/sources/classes/cache/cache.php',
                'recache_class' => 'realstats_cache',
                'recache_function' => 'rebuild'
                );
