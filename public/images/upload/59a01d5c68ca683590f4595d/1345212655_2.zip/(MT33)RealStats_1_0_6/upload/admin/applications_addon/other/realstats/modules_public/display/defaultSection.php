<?php
/**
 * @ Application : 		RealStats
 * @ File : 			defaultSection.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
$DEFAULT_SECTION = 'display';
