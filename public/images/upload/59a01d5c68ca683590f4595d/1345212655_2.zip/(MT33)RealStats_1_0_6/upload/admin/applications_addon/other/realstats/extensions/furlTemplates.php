<?php
/**
 * @ Application : 		RealStats
 * @ File : 			furlTemplates.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

/**
 * SEO templates
 *
 * 'allowRedirect' is a flag to tell IP.Board whether to check the incoming link and if not formatted correctly, redirect the correct one
 *
 * OUT FORMAT REGEX:
 * First array element is a regex to run to see if we've a match for the URL
 * The second array element is the template to use the results of the parenthesis capture
 *
 * Special variable #{__title__} is replaced with the $title data passed to output->formatUrl( $url, $title)
 *
 * IMPORTANT: Remember that when these regex are used, the output has not been fully parsed so you will get:
 * showuser={$data['member_id']} NOT showuser=1 so do not try and match numerics only!
 *
 * IN FORMAT REGEX
 *
 * This allows the registry to piece back together a URL based on the template regex
 * So, for example: "/user/(\d+?)/", 'matches' => array(  array( 'showuser' => '$1' ) )tells IP.Board to populate 'showuser' with the result
 * of the parenthesis capture #1
 */
$_SEOTEMPLATES = array(
	
'realstats_app'	=> array( 'app'		      => 'realstats',
						  'allowRedirect' => 1,

						  'out'           => array( '#app=realstats(?:&|&amp;)stats_app=(.+)#i', 'stats/$1/' ),
						  'in'            => array( 'regex'   => "#/stats/(.+)/#i",
'matches' => array(array( 'app', 'realstats' ),array( 'section', 'display' ),
array( 'module' , 'display' ), array( 'stats_app', '$1' ) ) ) ),
							
	'app=realstats'       => array( 'app'		      => 'realstats',
							  'allowRedirect' => 1,
							  'out'           => array( '#app=realstats(&|$)#i', 'stats/' ),
							  'in'            => array( 'regex'   => "#/stats/#i",
'matches' => array(array( 'app', 'realstats' ),array( 'section', 'display' ),
array( 'module' , 'display' )
)))

);
	
