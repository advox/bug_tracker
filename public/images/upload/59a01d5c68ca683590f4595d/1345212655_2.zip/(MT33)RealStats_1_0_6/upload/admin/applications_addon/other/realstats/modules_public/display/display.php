<?php 
/**
 * @ Application : 		RealStats
 * @ File : 			display.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}
class public_realstats_display_display extends ipsCommand
{
public $output ='';
public $title = '';
public $seotitle = '';
static public $_appsLoaded = array();
private $classes_loaded = FALSE;
public $_active  = array('skipParsing' => true, );

public function doExecute( ipsRegistry $registry ) 
	{
if($this->settings['realstats_groups_allowed'])
{
$groups = strstr($this->settings['realstats_groups_allowed'], ',')?explode(',', IPSText::cleanPermString($this->settings['realstats_groups_allowed'])):intval($this->settings['realstats_groups_allowed']);
if(!IPSMember::isInGroup($this->memberData, $groups))
{
$this->registry->output->showError($this->lang->words['err_no_stats_allowed'], '10STATS002', false, '', 403 );
}
}
$this->title = IPSLib::getAppTitle('realstats');
$this->seotitle = IPSText::makeSeoTitle($this->title);
$_NOWMEM = IPSDebug::getMemoryDebugFlag();
$_NOW = IPSDebug::startTimerInstance();
$this->loadStats();
$_ENDMEM = IPSDebug::setMemoryDebugFlag('Loaded Statistics', $_NOWMEM);
$_END = IPSDebug::endTimerInstance($_NOW);
IPSDebug::addMessage('Stats Loaded in '.$this->lang->formatNumber(($_END/1000), 8).' seconds using '.IPSLib::sizeFormat($_ENDMEM));
	$this->_active['addWhere'][]	= "s.in_error=0";

$this->registry->output->setTitle( $this->registry->output->getTitle() . ' - ' . $this->settings['board_name'] );
$this->doFooter();
$this->registry->getClass('output')->addContent( $this->output );
        $this->registry->getClass('output')->sendOutput();
}
public function loadStats()
{
$stats = array();
$tabs = array();
$_tabs = array();
$_app = trim($this->request['stats_app']);
$resultsLimit = (intval($this->settings['realstats_num_results'])>0 && intval($this->settings['realstats_num_results'])<=25)?intval($this->settings['realstats_num_results']):10;
$resultsTruncate = (intval($this->settings['realstats_num_truncate'])>0)?intval($this->settings['realstats_num_truncate']):FALSE;
$usecache = $this->settings['realstats_cache_results']?TRUE:FALSE;
$disabledApps = $this->settings['realstats_apps_allowed']?explode(',', IPSText::cleanPermString($this->settings['realstats_apps_allowed'])):array();
$__NOCACHE = $this->settings['realstats_apps_nocache']?explode(',', IPSText::cleanPermString($this->settings['realstats_apps_nocache'])):array();
$_backup = $usecache;
if($usecache)
{
//needs to be right freaking HERE! This single query IS worth it.
$lastCache = $this->DB->buildAndFetch(array('select' => 'cs_updated', 'from' => 'cache_store', 'where' => "cs_key='realstats_cache'"));
$_TTL = (intval($this->settings['realstats_cache_results'])>0)?intval($this->settings['realstats_cache_results']):30;
//less than or never pops dummy, ready to go?
if(!intval($lastCache['cs_updated']) || $lastCache['cs_updated'] <=(time()-($_TTL*60)))
{
$this->cache->rebuildCache('realstats_cache', 'realstats');
}
if(!is_array($this->caches['realstats_cache']) || !count($this->caches['realstats_cache']))
{
$this->caches['realstats_cache'] = $this->cache->getCache('realstats_cache');
}
}
if(!$this->classes_loaded)
{
$className = IPSLib::loadLibrary( IPSLib::getAppDir( 'realstats' ) . '/sources/classes/realstats/realstats.php', 'realstats', 'realstats' );/*LibHook*/
foreach(ipsRegistry::$applications as $app => $data)
{
if($_appsLoaded[$app] || !IPSLib::appIsInstalled( $app ) || in_array($app, $disabledApps))
{
continue;
}
if($_backup)
{
if(in_array($app, $__NOCACHE))
{
$usecache = FALSE;
}
else
{
$usecache = $_backup;
}
}
/* Got a realstats extension file for it? */
		
			$file = '';
			
			if ( is_file( IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			elseif ( is_file( IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			
			if ( $file )
			{

				$className = IPSLib::loadLibrary( $file, 'stats_' . $app, $app );
				$class = new $className( ipsRegistry::instance(), $app );
if(!$_app && method_exists( $class, 'fetchGeneralStats' ))
{
if($usecache && @unserialize($this->caches['realstats_cache']['default'][$app]))
{
$stats[$app] = @unserialize($this->caches['realstats_cache']['default'][$app]);
}
else
{
$stats[$app] = $class->fetchGeneralStats();
}
if( method_exists( $class, 'formatGeneralStats' ))
{
$stats[$app] = $class->formatGeneralStats($stats[$app]);
}
}
if ( method_exists( $class, 'fetchDetailedStats' ) )
{
$tabs[$app] = IPSLib::getAppTitle($app);
if($_app==$app && $_app)
{
if($usecache && @unserialize($this->caches['realstats_cache'][$app]))
{
$stats[$app] =  @unserialize($this->caches['realstats_cache'][$app]);
if ( method_exists( $class, 'returnDetailedStats' ) )
{
$stats[$app]['truncate'] = $resultsTruncate;
$stats[$app] = $class->returnDetailedStats($stats[$app]);
}
}
else
{
if ( method_exists( $class, 'returnDetailedStats' ) )
{
$stats[$app] = $class->fetchDetailedStats($resultsLimit);
$stats[$app]['truncate'] = $resultsTruncate;
$stats[$app] = $class->returnDetailedStats($stats[$app]);
}
else
{
$stats[$app] = $class->fetchDetailedStats();
}
}
}
}
				


				}
			
		}

$_appsLoaded = $stats;
$this->classes_loaded = TRUE;
}
//make sure it isnt invalid selection and triggers this
if(!array_keys($_appsLoaded) && !$_app)
{
$this->registry->output->showError($this->lang->words['err_no_stats_admindoneit'], '30STATS003', false, '', 404 );
}
if(!$_app)
{
$this->registry->output->addNavigation($this->title, 'app=realstats', $this->seotitle);
$this->registry->output->addNavigation($this->lang->words['realstats_tab_default'], '');
$_stats = $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsApp_core($_appsLoaded);
$this->registry->output->addCanonicalTag( "app=realstats", 'public', $this->seotitle );
	$this->registry->getClass('output')->setTitle($this->title .' - '. $this->lang->words['realstats_tab_default']);
}
else if($_appsLoaded[$_app])
{
$_stats = $_appsLoaded[$_app];
$this->registry->output->addNavigation($this->title, 'app=realstats', $this->seotitle);
$this->registry->output->addCanonicalTag( "app=realstats&amp;stats_app={$_app}", 'public', $_app );
$this->registry->getClass('output')->setTitle($this->title .' - ' .$tabs[$_app] );
$this->registry->output->addNavigation($tabs[$_app], '');
}
else
{
$this->registry->output->showError($this->lang->words['err_no_stats'], '10STATS001', false, '', 404 );
}
if($this->request['ajax'])
{
require_once( IPS_KERNEL_PATH . 'classAjax.php' );
		$ajax			= new classAjax();
if($this->request['md5check']!==$this->member->form_hash)
{
$ajax->returnString('nopermission');
exit();
}
$ajax->returnHTML($_stats);
exit();
}
$this->output .= $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsWrapper( $tabs, ($this->request['stats_app']?$this->request['stats_app']:'default'), $_stats );

}
private function doFooter()
{
	/*active users*/
$classToLoad = IPSLib::loadLibrary( IPS_ROOT_PATH . 'sources/classes/session/api.php', 'session_api' );
		$sessions    = new $classToLoad( $this->registry );

	$this->output .= $this->registry->getClass('output')->getTemplate('realstats_global')->currentlyViewing( $sessions->getUsersIn('realstats' , $this->_active) );
/* Append Copyright */
		/* How about we just leave this line where it's at, OK?  It's really not that much to ask, given how much of my life has gone into producing this */
		/* If you work out the income I have gotten from this app, divided by the number of hours devoted to it, I'm getting less than minimum wage as it is */
		/* So how about you not be a dick, and just leave this here?  Otherwise, think about what your mother would think if she knew you went around removing things like this */
		/* Original Copyright Rant Line @Copyright Michael McCune http://www.invisionfocus.com... and 100% agreed and true here... leave it ALONE dickweed.*/
		$year = IPSTime::unixstamp_to_human(IPSTime::getTimestamp());
$this->output .= '<div class="clear clearfix"><p class="right desc lighter blend_links">RealStats '.ipsRegistry::$applications['realstats']['app_version'].'<br/>
 &copy; 2010-'.$year['year'].' <a title="Quality IP.Board and IP.Content Modifications" target="_blank" rel="nofollow" href="http://marchertech.com/">Marcher Technologies</a></p></div>';
} 
}
?>
