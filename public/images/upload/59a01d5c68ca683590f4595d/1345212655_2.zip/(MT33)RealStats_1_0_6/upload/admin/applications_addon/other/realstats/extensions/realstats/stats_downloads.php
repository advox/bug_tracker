<?php
/**
* Real Stats Module for DOWNLOADS
*
*/
/**
 * @ Application : 		RealStats
 * @ File : 			stats_downloads.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class stats_downloads implements iRealStats
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	/**
	 * CONSTRUCTOR
	 *
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		if ( ! $this->registry )
		{
			/* Make registry objects */
			$this->registry		=  $registry;
			$this->DB			=  $this->registry->DB();
			$this->settings		=& $this->registry->fetchSettings();
			$this->request		=& $this->registry->fetchRequest();
			$this->lang			=  $this->registry->getClass('class_localization');
			$this->member		=  $this->registry->member();
			$this->memberData	=& $this->registry->member()->fetchMemberData();
			$this->cache		=  $this->registry->cache();
			$this->caches		=& $this->registry->cache()->fetchCaches();
		}
	}
	

	
	/**
	 * Returns the data for the app landing items
	 * Data should be an array of stats to show
	 *
	 * @return	array(stats)
	 */
	public function fetchGeneralStats()
	{
		/* INIT */
		$stats_output = array();
		if( !$this->caches['idm_stats'] )
		{
			$this->caches['idm_stats'] = $this->cache->getCache('idm_stats');
		}
		$stats = $this->caches['idm_stats'];
		

$stats_output['total_files'] = intval( $stats['total_files'] );
$stats_output['total_categories'] = intval( $stats['total_categories'] );
$stats_output['total_downloads'] = intval( $stats['total_downloads'] );
$stats_output['total_authors'] = intval( $stats['total_authors'] );
$stats_output['avg_files'] = round( $stats['total_files']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['avg_downloads'] = round( $stats['total_downloads']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );

$stats_output['last_author']	= intval($stats['latest_mid']);
$stats_output['last_file']	= array('latest_fid', intval($stats['latest_fid']), 'latest_fname_furl' => $stats['latest_fname_furl'], 'latest_fname' => $stats['latest_fname']);


		return $stats_output;
	}
public function formatGeneralStats($data)
	{
foreach($data as $key => $val)
{
switch($key)
{
case 'total_files':
case 'total_categories':
case 'total_downloads':
case 'total_authors':
$data[$key] = $this->lang->formatNumber($val);
break;
case 'avg_files':
case 'avg_downloads':
$data[$key] = $this->lang->formatNumber($val, 2);
break;
case 'most_time':
$data[$key] = $this->lang->getDate($val, 'LONG' );
break;
case 'last_author':
$data[$key] = $this->registry->output->getTemplate( 'global')->userHoverCard(IPSMember::load($val));
break;
case 'last_file':
$data[$key] = "<a href='".$this->registry->output->buildSEOUrl( 'app=downloads&amp;showfile=' .$val['latest_fid'], 'public', $val['latest_fname_furl'], 'idmshowfile' )."' title='{$val['latest_fname']}'>{$val['latest_fname']}</a>";
break;
}
}
return $data;
}
public function fetchDetailedStats($limit)
	{
$this->registry->getAppClass('downloads');
$_topCategoriesbyFiles = array();
$_topCategoriesbyViews = array();
$_topCategoriesbyDownloads = array();
$_topFilesByRating = array();
$_topFilesByView = array();
$_topFilesByDownload = array();
$_topSubmitters = array();
$_categories = $this->registry->categories->cat_lookup;
$categories = array();
if(count($_categories) && is_array($_categories))
{
foreach($_categories as $cat)
{
if ( $this->registry->permissions->check( 'view', $cat ) === true )
{
$categories[] = intval($cat['cid']);
if($cat['cfileinfo']['total_files']>0)
{
$_topCategoriesbyFiles[] = $cat;
}
if($cat['cfileinfo']['total_views']>0)
{
$_topCategoriesbyViews[] = $cat;
}
if($cat['cfileinfo']['total_downloads']>0)
{
$_topCategoriesbyDownloads[] = $cat;
}
}
}
}
if ( is_array( $categories ) AND count( $categories ) )
{

	$this->DB->build( array( 'select' => '*', 'from' => 'downloads_files', 'where' => 'file_open=1 AND file_cat IN (' . implode( ',', $categories ) . ')', 'order' => "file_rating DESC, " . $this->DB->buildLength( "file_votes" ) . " DESC", 'limit' => array( 0, $limit ) ) );
		$qb = $this->DB->execute();
		
		while( $r = $this->DB->fetch($qb) )
		{
$_topFilesByRating[] = $r;
}
$this->DB->freeResult($qb);
	$this->DB->build( array( 'select' => '*', 'from' => 'downloads_files', 'where' => 'file_open=1 AND file_cat IN (' . implode( ',', $categories ) . ')', 'order' => "file_views DESC", 'limit' => array( 0, $limit ) ) );
		$qb = $this->DB->execute();
		
		while( $r = $this->DB->fetch($qb) )
{
$_topFilesByView[] = $r;
}
$this->DB->freeResult($qb);
	$this->DB->build( array( 'select' => '*', 'from' => 'downloads_files', 'where' => 'file_open=1 AND file_cat IN (' . implode( ',', $categories ) . ')', 'order' => "file_downloads DESC", 'limit' => array( 0, $limit ) ) );
		$qb = $this->DB->execute();
		
		while( $r = $this->DB->fetch($qb) )
{
$_topFilesByDownload[] = $r;
}
$this->DB->freeResult($qb);

//-----------------------------------------
		// Now get top authors
		//-----------------------------------------
		
		$_authors	= array();
		$_authorIds	= array();
		
		$this->DB->build( array( 'select' => 'file_submitter, SUM(file_downloads) as totalfiles', 'from' => 'downloads_files', 'where' => 'file_open=1 AND file_cat IN (' . implode( ',', $categories ) . ')', 'order' => 'totalfiles DESC', 'limit' => array( 0, $limit ), 'group' => 'file_submitter' ) );
		$qb = $this->DB->execute();
		
		while( $r = $this->DB->fetch($qb) )
		{
			if( !$r['file_submitter'] )
			{
				continue;
			}
			
			$_authors[]		= $r;
			$_authorIds[]	= intval($r['file_submitter']);
		}
$this->DB->freeResult($qb);
		
		$members	= IPSMember::load( $_authorIds, 'core,extendedProfile,groups' );
		
		foreach( $_authors as $_author )
		{
			$_member				= $members[ intval($_author['file_submitter']) ];
if(!IPSMember::isInactive($_member))
{
$_topSubmitters[]	= array('member_id' => intval($_author['file_submitter']), 'total_files' => intval($_author['totalfiles']));
}
		}
if ( is_array( $_topCategoriesbyFiles ) AND count( $_topCategoriesbyFiles ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topCategoriesbyFiles, array( $this, 'categoryFileSort' ) );
$_topCategoriesbyFiles = array_slice( $_topCategoriesbyFiles, 0, $limit );
foreach($_topCategoriesbyFiles as &$category)
{
$category['files'] = intval($category['cfileinfo']['total_files']);
$category['date'] = intval($category['cfileinfo']['date']);
$category['mid'] = intval($category['cfileinfo']['mid']);
foreach($category as $key => $val)
{
if(!in_array($key, array('files', 'cid', 'cname', 'date', 'mid')))
{
unset($category[$key]);
}
}
}
}
if ( is_array( $_topCategoriesbyViews ) AND count( $_topCategoriesbyViews ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topCategoriesbyViews, array( $this, 'categoryViewSort' ) );
$_topCategoriesbyViews = array_slice( $_topCategoriesbyViews, 0, $limit );
foreach($_topCategoriesbyViews as &$category)
{
$category['views'] = intval($category['cfileinfo']['total_views']);
$category['date'] = intval($category['cfileinfo']['date']);
$category['mid'] = intval($category['cfileinfo']['mid']);
foreach($category as $key => $val)
{
if(!in_array($key, array('views', 'cid', 'cname', 'date', 'mid')))
{
unset($category[$key]);
}
}
}
}
if ( is_array( $_topCategoriesbyDownloads ) AND count( $_topCategoriesbyDownloads ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topCategoriesbyDownloads, array( $this, 'categoryDownloadSort' ) );
$_topCategoriesbyDownloads = array_slice( $_topCategoriesbyDownloads, 0, $limit );
foreach($_topCategoriesbyDownloads as &$category)
{
$category['downloads'] = intval($category['cfileinfo']['total_downloads']);
$category['date'] = intval($category['cfileinfo']['date']);
$category['mid'] = intval($category['cfileinfo']['mid']);
foreach($category as $key => $val)
{
if(!in_array($key, array('downloads', 'cid', 'cname', 'date', 'mid')))
{
unset($category[$key]);
}
}
}
}
if ( is_array( $_topFilesByView ) AND count( $_topFilesByView ) )
		{
foreach($_topFilesByView as &$file)
{
$file['views'] = intval($file['file_views']);
foreach($file as $key => $val)
{
if(!in_array($key, array('views', 'file_id', 'file_name_furl', 'file_name', 'file_updated', 'file_submitter')))
{
unset($file[$key]);
}
}
}
}
if ( is_array( $_topFilesByDownload ) AND count( $_topFilesByDownload ) )
		{
foreach($_topFilesByDownload as &$file)
{
$file['downloads'] = intval($file['file_downloads']);
foreach($file as $key => $val)
{
if(!in_array($key, array('downloads', 'file_id', 'file_name_furl', 'file_name', 'file_updated', 'file_submitter')))
{
unset($file[$key]);
}
}
}
}
if ( is_array( $_topFilesByRating ) AND count( $_topFilesByRating ) )
		{
foreach($_topFilesByRating as &$file)
{
$file['rating'] = intval((intval($file['file_votes'] )>0)?round($file['file_rating']/$file['file_votes']):$file['file_rating']);
foreach($file as $key => $val)
{
if(!in_array($key, array('rating', 'file_id', 'file_name_furl', 'file_name', 'file_updated', 'file_submitter')))
{
unset($file[$key]);
}
}
}
}
}
return array('categoriesbyFiles' => $_topCategoriesbyFiles, 'categoriesbyViews' => $_topCategoriesbyViews, 'categoriesbyDownloads' => $_topCategoriesbyDownloads, 'filesByView' => $_topFilesByView, 'filesByDownload' => $_topFilesByDownload, 'filesByRating' => $_topFilesByRating, 'topSubmitters' => $_topSubmitters);
}
public function returnDetailedStats($data)
{
static $proccessedMembers = array();
if ( is_array(  $data['topSubmitters'] ) AND count(  $data['topSubmitters'] ) )
		{
foreach( $data['topSubmitters'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['filesByView'] ) AND count(  $data['filesByView'] ) )
		{
foreach( $data['filesByView'] as &$mid)
{
if(!isset($proccessedMembers[$mid['file_submitter']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['file_submitter']);
$proccessedMembers[$mid['file_submitter']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['file_submitter']];
}
}
}
if ( is_array(  $data['filesByDownload'] ) AND count(  $data['filesByDownload'] ) )
		{
foreach( $data['filesByDownload'] as &$mid)
{
if(!isset($proccessedMembers[$mid['file_submitter']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['file_submitter']);
$proccessedMembers[$mid['file_submitter']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['file_submitter']];
}
}
}
if ( is_array(  $data['filesByRating'] ) AND count(  $data['filesByRating'] ) )
		{
foreach( $data['filesByRating'] as &$mid)
{
if(!isset($proccessedMembers[$mid['file_submitter']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['file_submitter']);
$proccessedMembers[$mid['file_submitter']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['file_submitter']];
}
}
}
if ( is_array(  $data['categoriesbyFiles'] ) AND count(  $data['categoriesbyFiles'] ) )
		{
foreach( $data['categoriesbyFiles'] as &$mid)
{
if(!isset($proccessedMembers[$mid['mid']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['mid']);
$proccessedMembers[$mid['mid']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['mid']];
}
}
}
if ( is_array(  $data['categoriesbyViews'] ) AND count(  $data['categoriesbyViews'] ) )
		{
foreach( $data['categoriesbyViews'] as &$mid)
{
if(!isset($proccessedMembers[$mid['mid']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['mid']);
$proccessedMembers[$mid['mid']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['mid']];
}
}
}
if ( is_array(  $data['categoriesbyDownloads'] ) AND count(  $data['categoriesbyDownloads'] ) )
		{
foreach( $data['categoriesbyDownloads'] as &$mid)
{
if(!isset($proccessedMembers[$mid['mid']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['mid']);
$proccessedMembers[$mid['mid']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['mid']];
}
}
}
return $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsApp_downloads($data['categoriesbyFiles'], $data['categoriesbyViews'], $data['categoriesbyDownloads'], $data['filesByView'], $data['filesByDownload'], $data['filesByRating'], $data['topSubmitters'], $data['truncate']);
}
private function categoryDownloadSort( $a, $b)
        {
                return( $a['cfileinfo']['total_downloads'] < $b['cfileinfo']['total_downloads'] ) ? 1 : -1;
        }
private function categoryViewSort( $a, $b)
        {
                return( $a['cfileinfo']['total_views'] < $b['cfileinfo']['total_views'] ) ? 1 : -1;
        }
private function categoryFileSort( $a, $b)
        {
                return( $a['cfileinfo']['total_files'] < $b['cfileinfo']['total_files'] ) ? 1 : -1;
        }
}
