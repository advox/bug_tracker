<?php

class version_upgrade
{
        /**
         * Custom HTML to show
         *
         * @var         string
         */
        protected $_output = '';
        
        /**
         * Fetch any custom HTML we want to show during this step to the user.  Generic messages can be set using addMessage() instead.
         *
         * @return      string
         */
        public function fetchOutput()
        {
                return $this->_output;
        }
        
        /**
         * Execute selected method
         *
         * @param       object          Registry object
         * @return      @e bool         True means there is more to do (call this file again), false means we are done
         */
        public function doExecute( ipsRegistry $registry )
        {
                /* Make object */
                $this->registry =  $registry;
                $this->DB          =  $this->registry->DB();
                $this->settings =& $this->registry->fetchSettings();
                $this->request  =& $this->registry->fetchRequest();
                $this->cache    =  $this->registry->cache();
                $this->caches   =& $this->registry->cache()->fetchCaches();
$this->DB->preventAddSlashes(array('conf_evalphp'));
$this->DB->update('core_sys_conf_settings', array( 'conf_description' => "If Enabled, the application stock extensions will place filtered results into a cache store for defined periods for their tabs. It should be noted the result set will be checking permissions to generate the data based on the user to trigger the cache, however the HTML is not cached, use wisely, can be a life-saver with those intensive counts/filters.", 'conf_evalphp' => 'if($save==1){ipsRegistry::cache()->rebuildCache(\'realstats_cache\', \'realstats\');}'), "conf_key='realstats_cache_results'");
return TRUE;
}
}
