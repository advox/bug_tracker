<?php
/**
 * @ Application : 		RealStats
 * @ File : 			realstats.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
/**
 * Real Stats Interfaces
 *
 */

interface iRealStats
{
	/**
	 * CONSTRUCTOR
	 *
	 * @param  object  $registry
	 * @param  string
	 * @return	@e void
	 */
	public function __construct( ipsRegistry $registry, $app='core');
}
class realstats
{
	/**
	* Registry Object Shortcuts
	*/
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	/**
	 * @var	string
	 */
	protected $_app = '';
	
	/**
	 * @var	object
	 */
	protected $_class = '';
	
	/**
	 * CONSTRUCTOR
	 *
	 * @param  object $registry
	 * @return	@e void
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		/* Make registry objects */
		$this->registry		=  $registry;
		$this->DB			=  $this->registry->DB();
		$this->settings		=& $this->registry->fetchSettings();
		$this->request		=& $this->registry->fetchRequest();
		$this->lang			=  $this->registry->getClass('class_localization');
		$this->member		=  $this->registry->member();
		$this->memberData	=& $this->registry->member()->fetchMemberData();
		$this->cache		=  $this->registry->cache();
		$this->caches		=& $this->registry->cache()->fetchCaches();
		

		
		if ( ! is_object( $this->_class ) )
		{ 
			/* Do we have a plug in? */
			$_f = IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_' . $app . '.php';
			
			if ( ! is_file( $_f ) )
			{
				$_f = IPSLib::getAppDir('realstats') . '/extensions/realstats/stats_' . $app . '.php';
			}
			
			if ( is_file( $_f ) )
			{
				$classToLoad  = IPSLib::loadLibrary( $_f, 'stats_' . $app, 'realstats' );
				$this->_class = new $classToLoad( $registry, $app);
			}
		
		}
	}
	
	/**
	 * Trap calls for modules
	 *
	 * @access	public
	 * @param	string
	 * @param	mixed		void, or an array of arguments
	 * @return	mixed		string, or an error
	 */
	public function __call( $funcName, $args )
	{
		if ( is_object( $this->_class ) )
		{
			return $this->_class->$funcName( $args );
		}
	}
}
