<?php
/**
 * @file		generate.php 	Navigation plugin: Realstats
 *~TERABYTE_DOC_READY~
 * $Copyright: (c) 2001 - 2011 Invision Power Services, Inc.$
 * $License: http://www.invisionpower.com/company/standards.php#license$
 * $Author: bfarber $
 * @since		3/8/2011
 * $LastChangedDate: 2011-05-12 22:28:10 -0400 (Thu, 12 May 2011) $
 * @version		v3.3.4
 * $Revision: 8754 $
 */

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded 'admin.php'.";
	exit();
}

/**
 *
 * @class		navigation_realstats
 * @brief		add some pluginmajiggery
 */
class navigation_realstats
{
	/**
	 * Registry Object Shortcuts
	 *
	 * @var		$registry
	 * @var		$DB
	 * @var		$settings
	 * @var		$request
	 * @var		$lang
	 * @var		$member
	 * @var		$memberData
	 * @var		$cache
	 * @var		$caches
	 */
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	/**
	 * Constructor
	 *
	 * @return	@e void
	 */
	public function __construct() 
	{
		$this->registry		=  ipsRegistry::instance();
		$this->DB			=  $this->registry->DB();
		$this->settings		=& $this->registry->fetchSettings();
		$this->request		=& $this->registry->fetchRequest();
		$this->member		=  $this->registry->member();
		$this->memberData	=& $this->registry->member()->fetchMemberData();
		$this->cache		=  $this->registry->cache();
		$this->caches		=& $this->registry->cache()->fetchCaches();
		$this->lang			=  $this->registry->class_localization;
	}
	
	/**
	 * Return the tab title
	 *
	 * @return	@e string
	 */
	public function getTabName()
	{ 
		return IPSLib::getAppTitle('realstats');
	}
	
	/**
	 * Returns navigation data
	 * 
	 * @return	@e array	array( array( 0 => array( 'title' => 'x', 'url' => 'x' ) ) );
	 */
	public function getNavigationData()
	{
		$blocks = array();
		$links  = array();
$this->lang->loadLanguageFile(array('public_lang'), 'realstats');
if($this->settings['realstats_groups_allowed'])
{
$groups = strstr($this->settings['realstats_groups_allowed'], ',')?explode(',', IPSText::cleanPermString($this->settings['realstats_groups_allowed'])):intval($this->settings['realstats_groups_allowed']);
if(!IPSMember::isInGroup($this->memberData, $groups))
{
return array(array('title' => $this->lang->words['err_no_stats_allowed'], 'links' => array()));
}
}
$links[] = array( 'title' => $this->lang->words['realstats_tab_default'], 'url' => $this->registry->output->buildSeoUrl( 'app=realstats', 'public', 'realstats') );
$disabledApps = $this->settings['realstats_apps_allowed']?explode(',', IPSText::cleanPermString($this->settings['realstats_apps_allowed'])):array();
$className = IPSLib::loadLibrary( IPSLib::getAppDir( 'realstats' ) . '/sources/classes/realstats/realstats.php', 'realstats', 'realstats' );/*LibHook*/
		foreach(ipsRegistry::$applications as $app => $data)
{
if( !IPSLib::appIsInstalled( $app ) || in_array($app, $disabledApps))
{
continue;
}
/* Got a realstats extension file for it? */
		
			$file = '';
			
			if ( is_file( IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			elseif ( is_file( IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			
			if ( $file )
			{

				$className = IPSLib::loadLibrary( $file, 'stats_' . $app, $app );
				$class = new $className( ipsRegistry::instance(), $app );
if ( method_exists( $class, 'fetchDetailedStats' ) )
{
		$links[] = array( 'title' => $this->lang->words['realstats_tab_'.$app]?$this->lang->words['realstats_tab_'.$app]:IPSLib::getAppTitle($app), 'url' => $this->registry->output->buildSeoUrl( 'app=realstats&amp;stats_app='.$app, 'public', $app, 'realstats_app') );
	}
}
}
		
		/* Add to blocks */
		$blocks[] = array( 'title' => '', 'links' => $links );
		
		return $blocks;
	}
}
