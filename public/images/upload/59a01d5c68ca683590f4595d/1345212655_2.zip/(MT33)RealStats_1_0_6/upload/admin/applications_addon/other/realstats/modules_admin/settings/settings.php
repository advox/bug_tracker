<?php
/**
 * @ Application : 		RealStats
 * @ File : 			settings.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
if (! defined ( 'IN_ACP' )) {
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit ();
}

class admin_realstats_settings_settings extends ipsCommand {
	public $html;
	
	public function doExecute(ipsRegistry $registry) {
		
		/* Load Languages */
		$this->registry->class_localization->loadLanguageFile ( array ('admin_tools' ), 'core' );

		
			$classToLoad = IPSLib::loadActionOverloader ( IPSLib::getAppDir ( 'core' ) . '/modules_admin/settings/settings.php', 'admin_core_settings_settings' );
			$this->settingsClass = new $classToLoad ();
			$this->settingsClass->makeRegistryShortcuts ( $this->registry );
			$this->settingsClass->html = $this->registry->output->loadTemplate ( 'cp_skin_settings', 'core' );
			$this->settingsClass->form_code = $this->settingsClass->html->form_code = 'module=settings&amp;section=settings';
			$this->settingsClass->form_code_js = $this->settingsClass->html->form_code_js = 'module=settings&section=settings';
			$this->settingsClass->return_after_save = $this->settings ['base_url'] . 'module=settings&section=settings';
		
		
		/* Show settings form */
		$this->request ['conf_title_keyword'] = 'mt_realstats';
		
		
		/* View settings */
		$this->settingsClass->_viewSettings();

		
			/* Output */
$this->registry->output->html_main .= $this->registry->output->global_template->global_frame_wrapper();
$this->registry->output->sendOutput();
	}
}
