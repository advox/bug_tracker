<?php
/**
 * @ Application : 		RealStats
 * @ File : 			coreExtensions.php
 * @ Last Updated : 	Sun, 05 Aug 2012 20:30:13 -0600
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class publicSessions__realstats
{
  /**
         * Return session variables for this application
         *
         * current_appcomponent, current_module and current_section are automatically
         * stored. This function allows you to add specific variables in.
         *
         * @return      array
         */
        public function getSessionVariables()
        {
        $return_array = array();


 if( isset(ipsRegistry::$request['stats_app']) && IPSLib::appIsInstalled(ipsRegistry::$request['stats_app']))
  {
$return_array['location_1_type'] = 'stats_app';
$return_array['location_2_type']   = trim(ipsRegistry::$request['stats_app']);

}
return $return_array;
  }
  /**
         * Parse/format the online list data for the records
         *
         * @param       array                    Online list rows to check against
         * @return      array                    Online list rows parsed
         */
        public function parseOnlineEntries( $rows )
        {
                if( !is_array($rows) OR !count($rows) )
                {
                        return $rows;
                }
                ipsRegistry::getClass('class_localization')->loadLanguageFile( array( 'public_lang' ), 'realstats' );
                //-----------------------------------------
                // Init
                //-----------------------------------------
                
                $records        = array();
                $data           = array();
                $final           = array();

                //-----------------------------------------
                // Extract the data
                //-----------------------------------------
                
                foreach( $rows as $row )
                {
        if( $row['current_appcomponent'] != 'realstats'  )
                        {
                              continue;
                              }
                                 if( $row['location_1_type']=='stats_app' )
                                 {
                                        $records[ $row['location_2_type'] ]    = trim($row['location_2_type']);
                                }
                }
//-----------------------------------------
                // Put humpty dumpty together again
                //-----------------------------------------

                foreach( $rows as $row )
                {
               
                        if( $row['current_appcomponent'] != 'realstats'  )
                        {
                              continue;
                              }
  if(isset($records[ $row['location_2_type'] ]))
                                        {
                                                $row['where_line']              = ipsRegistry::getClass( 'class_localization' )->words['realstats_online'].':';
                                                $row['where_line_more'] = ipsRegistry::getClass( 'class_localization' )->words['realstats_tab_'.$records[ $row['location_2_type'] ]]?ipsRegistry::getClass( 'class_localization' )->words['realstats_tab_'.$records[ $row['location_2_type'] ]]:IPSLib::getAppTitle($records[ $row['location_2_type'] ]);
                                                $row['where_link']              = 'app=realstats&amp;stats_app=' . $records[ $row['location_2_type'] ];
                                                $row['_whereLinkSeo']   = ipsRegistry::getClass('output')->buildSEOUrl( $row['where_link'], 'public', IPSText::makeSeoTitle($records[ $row['location_2_type'] ]), 'realstats_app' );
                                      
                        }
                        else
                        {
                       
                                $row['where_link']              = 'app=realstats';
                                $row['where_line']              = ipsRegistry::getClass( 'class_localization' )->words['realstats_online'];
                                $row['_whereLinkSeo']   = ipsRegistry::getClass('output')->buildSEOUrl( $row['where_link'], 'public', IPSText::makeSeoTitle(IPSLib::getAppTitle('realstats')), 'app=realstats' );
                        
                         }
 
                        $final[ $row['id'] ]    = $row;
}
                        return $final;

}
}
