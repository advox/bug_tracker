<?php
/**
 * @ Application : 		RealStats
 * @ File : 			cache.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class realstats_cache
{
public function rebuild()
{
$usecache = ipsRegistry::$settings['realstats_cache_results']?TRUE:FALSE;
if($usecache)
{
if(!in_array(ipsRegistry::$request['app'], array('install', 'upgrade')) )
{
$className = IPSLib::loadLibrary( IPSLib::getAppDir( 'realstats' ) . '/sources/classes/realstats/realstats.php', 'realstats', 'realstats' );/*LibHook*/
$disabledApps = ipsRegistry::$settings['realstats_apps_allowed']?explode(',', IPSText::cleanPermString(ipsRegistry::$settings['realstats_apps_allowed'])):array();
$disabledApps = array_merge_recursive($disabledApps, ipsRegistry::$settings['realstats_apps_nocache']?explode(',', IPSText::cleanPermString(ipsRegistry::$settings['realstats_apps_nocache'])):array());
$stats = array();
$resultsLimit = (intval(ipsRegistry::$settings['realstats_num_results'])>0 && intval(ipsRegistry::$settings['realstats_num_results'])<=25)?intval(ipsRegistry::$settings['realstats_num_results']):10;
foreach(ipsRegistry::$applications as $app => $data)
{
/* Got a realstats extension file for it? */
		if (!IPSLib::appIsInstalled( $app )  || in_array($app, $disabledApps))
		{ continue; }
			$file = '';
			
			if ( is_file( IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( $app ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			elseif ( is_file( IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php' ) )
			{
				$file = IPSLib::getAppDir( 'realstats' ) . '/extensions/realstats/stats_'. $app .'.php';
			}
			
			if ( !$file )
			{ continue; }

				$className = IPSLib::loadLibrary( $file, 'stats_' . $app, $app );
				$class = new $className( ipsRegistry::instance(), $app );
if(method_exists( $class, 'fetchGeneralStats' ))
{
$stats['default'][$app] = @serialize($class->fetchGeneralStats());
}
if( method_exists( $class, 'fetchDetailedStats' ) )
{
$stats[$app] = @serialize($class->fetchDetailedStats($resultsLimit));
}
}
ipsRegistry::cache()->setCache( 'realstats_cache', $stats, array( 'array' => 1, 'deletefirst' => 1, 'donow' => 1 ) );
}
}
}
}
