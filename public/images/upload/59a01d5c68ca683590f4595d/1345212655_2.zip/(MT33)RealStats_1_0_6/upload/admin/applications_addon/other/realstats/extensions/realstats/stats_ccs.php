<?php
/**
* Real Stats Module for Content
*
*/
/**
 * @ Application : 		RealStats
 * @ File : 			stats_ccs.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class stats_ccs implements iRealStats
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	protected $databases = array();
	
	/**
	 * CONSTRUCTOR
	 *
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		if ( ! $this->registry )
		{
			/* Make registry objects */
			$this->registry		=  $registry;
			$this->DB			=  $this->registry->DB();
			$this->settings		=& $this->registry->fetchSettings();
			$this->request		=& $this->registry->fetchRequest();
			$this->lang			=  $this->registry->getClass('class_localization');
			$this->member		=  $this->registry->member();
			$this->memberData	=& $this->registry->member()->fetchMemberData();
			$this->cache		=  $this->registry->cache();
			$this->caches		=& $this->registry->cache()->fetchCaches();
		}
		
		
		
		
	}
	

	/**
	 * Returns the data for the app landing items
	 * Data should be an array of stats to show
	 *
	 * @return	array(stats)
	 */
	public function fetchGeneralStats()
	{
/* Load content class */

$this->registry->getAppClass('ccs');

if( !$this->caches['ccs_databases'] )
		{
			$this->caches['ccs_databases'] = $this->cache->getCache('ccs_databases');
		}
$this->databases = $this->caches['ccs_databases'];
		/* INIT */

		$stats_output = array();

if(count($this->databases) && is_array($this->databases))
{
foreach($this->databases as $id => $data)
{
$categories = 0;
if ( $this->registry->permissions->check( 'view', $data ) === true )
{
$cats = $this->registry->ccsFunctions->getCategoriesClass($data)->categories;
if(count($cats) && is_array($cats))
{
foreach($cats as $cid => $category)
{
$categories++;
}
}
$stats_output['<a href=\''.$this->registry->ccsFunctions->returnDatabaseUrl($data['database_id']).'\' title=\''.$data['database_name'].'\'>'.$data['database_name'].'</a>'] = array('database_record_count' => intval($data['database_record_count']), 'database_lang_pu' => $data['database_lang_pu'], 'category_count' => intval($categories));
}
}
}

		return $stats_output;
	}
	public function formatGeneralStats($data)
	{
foreach($data as $key => $val)
{
$data[$key] = $this->lang->formatNumber($val['database_record_count']).' '.$val['database_lang_pu'].($val['category_count']?' '.$this->lang->formatNumber($val['category_count']).' '.$this->lang->words['categories_general']:'');
}
return $data;
}
/**
	 * Gets the data for the application tab
	 * Data should be array of stats data variables to pass to the html
	 *
	 * @return	array(stats)
	 */
	public function fetchDetailedStats($limit)
	{
/* Load content class */
		$this->registry->getAppClass('ccs');
if( !$this->caches['ccs_databases'] )
		{
			$this->caches['ccs_databases'] = $this->cache->getCache('ccs_databases');
		}
$this->databases = $this->caches['ccs_databases'];
$_topCategoriesbyRecord = array();
$_topDatabasesbyRecord = array();
$_topRecordsByView = array();
$_topRecordsByRating = array();
$_topRecordsByReply = array();
$_topSubmitters = array();
$topSubmitters = array();
if(count($this->databases) && is_array($this->databases))
{
foreach($this->databases as $id => $data)
{
if ( $this->registry->permissions->check( 'view', $data ) === true )
{
$_topDatabasesbyRecord[] = $data;
$extra = '';
$cats = $this->registry->ccsFunctions->getCategoriesClass($data)->categories;
if(count($cats) && is_array($cats))
{
foreach($cats as $cid => $category)
{
if($category['category_records'])
{
$_topCategoriesbyRecord[] = $category;
}
}
}
$data['database_rate']	= trim( $data['perm_6'], ' ,' ) ? 1 : 0;
$data['database_comments']	= trim( $data['perm_5'], ' ,' ) ? 1 : 0;
$extra .= "r.record_approved='1'";
if( count($cats) )
				{
					$extra .= " AND r.category_id IN(" . implode( ',', array_keys( $cats ) ) . ")";
					$extra .= " AND (cat.category_has_perms=0 OR " . $this->DB->buildRegexp( "p.perm_view", $this->member->perm_id_array ) . ")";
				}


$Query = array();
$Query['select'] = 'r.*';
$Query['from'] = array( $data['database_database'] => 'r' );
if($extra)
{
$Query['where'] = $extra;
}
$Query['add_join'] = array(
													array(
															'from'   => array( 'ccs_database_categories' => 'cat' ),
															'where'  => "r.category_id=cat.category_id",
															'type'   => 'left',
														),
													array(
															'from'   => array( 'permission_index' => 'p' ),
															'where'  => "p.app='ccs' AND p.perm_type='categories' AND p.perm_type_id=cat.category_id",
															'type'   => 'left',
														),
);
$Query['order'] = "record_views DESC";
$Query['limit'] = array(0, $limit);
$this->DB->build($Query);
$q = $this->DB->execute();
while($row = $this->DB->fetch($q))
{
$row['_database'] = $data;
$_topRecordsByView[] = $row;
}
$this->DB->freeResult($q);
if($data['database_rate'])
{
$Query['order'] = "rating_real DESC";
$this->DB->build($Query);
$qu = $this->DB->execute();
while($row = $this->DB->fetch($qu))
{
$row['_database'] = $data;
$_topRecordsByRating[] = $row;
}
$this->DB->freeResult($qu);
}
if($data['database_comments'])
{
$Query['order'] = "record_comments DESC";
$this->DB->build($Query);
$que = $this->DB->execute();
while($row = $this->DB->fetch($que))
{
$row['_database'] = $data;
$_topRecordsByReply[] = $row;
}
$this->DB->freeResult($que);
}
unset($Query['order']);
unset($Query['limit']);
$Query['where'] .= " AND member_id<>'0'";
//here goes nasty... get best submitters.
$this->DB->build($Query);
$quer = $this->DB->execute();
while($rows = $this->DB->fetch($quer))
{
$_topSubmitters[intval($rows['member_id'])]++;
}
$this->DB->freeResult($quer);
}
}
}
if ( is_array( $_topSubmitters ) AND count( $_topSubmitters ) )
		{
 /* Sort High to Low, get just our desired quantity */
uasort( $_topSubmitters, array( $this, 'recordSortAuthors' ) );
foreach($_topSubmitters as $mid => $count)
{
if(!isset($_topSubmitters[$mid]['member_id']))
{
$_topSubmitters[$mid] = IPSMember::load($mid);
if(!IPSMember::isInActive($_topSubmitters[$mid]))
{
$topSubmitters[] = array('member_id' => intval($_topSubmitters[$mid]['member_id']), 'record_count' => intval($count));
}
}
}
$_topSubmitters = array_slice( $_topSubmitters, 0, $limit );
}
if ( is_array( $_topRecordsByReply ) AND count( $_topRecordsByReply ) )
		{

 /* Sort High to Low, get just our desired quantity */
usort( $_topRecordsByReply, array( $this, 'recordSortByReply' ) );
$_topRecordsByReply = array_slice( $_topRecordsByReply, 0, $limit );
foreach($_topRecordsByReply as &$record)
{
$record['record_title'] = $record[$record['_database']['database_field_title']];
$record['record_link'] = $this->registry->ccsFunctions->returnDatabaseUrl($record['_database']['database_id'], 0, $record['primary_id_field']);
foreach($record as $key => $val)
{
if(!in_array($key, array('member_id', 'record_title', 'record_link', 'record_comments', 'record_saved')))
{
unset($record[$key]);
}
}
}
}
if ( is_array( $_topRecordsByView ) AND count( $_topRecordsByView ) )
		{
$topViewRecords = array();
 /* Sort High to Low, get just our desired quantity */
usort( $_topRecordsByView, array( $this, 'recordSortByView' ) );
$_topRecordsByView = array_slice( $_topRecordsByView, 0, $limit );
foreach($_topRecordsByView as &$record)
{
$record['record_title'] = $record[$record['_database']['database_field_title']];
$record['record_link'] = $this->registry->ccsFunctions->returnDatabaseUrl($record['_database']['database_id'], 0, $record['primary_id_field']);
foreach($record as $key => $val)
{
if(!in_array($key, array('member_id', 'record_title', 'record_link', 'record_views', 'record_saved')))
{
unset($record[$key]);
}
}
}
}
if ( is_array( $_topRecordsByRating ) AND count( $_topRecordsByRating ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topRecordsByRating, array( $this, 'recordSortByRate' ) );
$_topRecordsByRating = array_slice( $_topRecordsByRating, 0, $limit );
foreach($_topRecordsByRating as &$record)
{

$record['record_title'] = $record[$record['_database']['database_field_title']];
$record['record_link'] = $this->registry->ccsFunctions->returnDatabaseUrl($record['_database']['database_id'], 0, $record['primary_id_field']);
foreach($record as $key => $val)
{
if(!in_array($key, array('member_id', 'record_title', 'record_link', 'rating_real', 'record_saved')))
{
unset($record[$key]);
}
}
}
}
if ( is_array( $_topCategoriesbyRecord ) AND count( $_topCategoriesbyRecord ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topCategoriesbyRecord, array( $this, 'categoryRecordSort' ) );
$_topCategoriesbyRecord = array_slice( $_topCategoriesbyRecord, 0, $limit );
foreach($_topCategoriesbyRecord as &$category)
{
$category['_lang'] = $this->databases[$category['category_database_id']]['database_lang_pu'];
$category['category_link'] = $this->registry->ccsFunctions->returnDatabaseUrl($category['category_database_id'], $category['category_id']);
foreach($category as $key => $val)
{
if(!in_array($key, array('_lang', 'category_link', 'category_name', 'category_records', 'category_last_record_date', 'category_last_record_member')))
{
unset($category[$key]);
}
}
}
}
if ( is_array( $_topDatabasesbyRecord ) AND count( $_topDatabasesbyRecord ) )
		{
 /* Sort High to Low, get just our desired quantity */
usort( $_topDatabasesbyRecord, array( $this, 'databaseRecordSort' ) );
$_topDatabasesbyRecord = array_slice( $_topDatabasesbyRecord, 0, $limit );
foreach($_topDatabasesbyRecord as &$database)
{
$database['database_link'] = $this->registry->ccsFunctions->returnDatabaseUrl($database['database_id']);
foreach($database as $key => $val)
{
if(!in_array($key, array('database_lang_pu', 'database_link', 'database_name', 'database_record_count')))
{
unset($database[$key]);
}
}
}
}
return array('databasesbyRecord' => $_topDatabasesbyRecord, 'categoriesbyRecord' => $_topCategoriesbyRecord, 'recordsByView' => $_topRecordsByView, 'recordsByReply' => $_topRecordsByReply, 'recordsByRating' => $_topRecordsByRating, 'topSubmitters' => $topSubmitters);
}
public function returnDetailedStats($data)
{
//preproccess members
static $proccessedMembers = array();
if ( is_array(  $data['recordsByView'] ) AND count(  $data['recordsByView'] ) )
		{
foreach( $data['recordsByView'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['recordsByReply'] ) AND count(  $data['recordsByReply'] ) )
		{
foreach( $data['recordsByReply'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['recordsByRating'] ) AND count(  $data['recordsByRating'] ) )
		{
foreach( $data['recordsByRating'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['topSubmitters'] ) AND count(  $data['topSubmitters'] ) )
		{
foreach( $data['topSubmitters'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
if ( is_array(  $data['categoriesbyRecord'] ) AND count(  $data['categoriesbyRecord'] ) )
		{
foreach( $data['categoriesbyRecord'] as &$mid)
{
if(!isset($proccessedMembers[$mid['category_last_record_member']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['category_last_record_member']);
$proccessedMembers[$mid['category_last_record_member']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['category_last_record_member']];
}
}
}
if ( is_array(  $data['topSubmitters'] ) AND count(  $data['topSubmitters'] ) )
		{
foreach( $data['topSubmitters'] as &$mid)
{
if(!isset($proccessedMembers[$mid['member_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['member_id']);
$proccessedMembers[$mid['member_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['member_id']];
}
}
}
return $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsApp_ccs($data['databasesbyRecord'], $data['categoriesbyRecord'], $data['recordsByView'], $data['recordsByReply'], $data['recordsByRating'], $data['topSubmitters'], $data['truncate']);
}
private function recordSortAuthors( $a, $b)
        {
                return( $a < $b ) ? 1 : -1;
        }
private function recordSortByReply( $a, $b)
        {
                return( $a['record_comments'] < $b['record_comments'] ) ? 1 : -1;
        }
private function recordSortByRate( $a, $b)
        {
                return( $a['rating_real'] < $b['rating_real'] ) ? 1 : -1;
        }
private function recordSortByView( $a, $b)
        {
                return( $a['record_views'] < $b['record_views'] ) ? 1 : -1;
        }	
private function categoryRecordSort( $a, $b)
        {
                return( $a['category_records'] < $b['category_records'] ) ? 1 : -1;
        }
private function databaseRecordSort( $a, $b)
        {
                return( $a['database_record_count'] < $b['database_record_count'] ) ? 1 : -1;
        }	
}
