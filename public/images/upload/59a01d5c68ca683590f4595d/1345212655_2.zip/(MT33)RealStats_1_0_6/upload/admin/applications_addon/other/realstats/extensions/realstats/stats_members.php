<?php
/**
* Real Stats Module for MEMBERS
*
*/
/**
 * @ Application : 		RealStats
 * @ File : 			stats_members.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class stats_members implements iRealStats
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	/**
	 * CONSTRUCTOR
	 *
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		if ( ! $this->registry )
		{
			/* Make registry objects */
			$this->registry		=  $registry;
			$this->DB			=  $this->registry->DB();
			$this->settings		=& $this->registry->fetchSettings();
			$this->request		=& $this->registry->fetchRequest();
			$this->lang			=  $this->registry->getClass('class_localization');
			$this->member		=  $this->registry->member();
			$this->memberData	=& $this->registry->member()->fetchMemberData();
			$this->cache		=  $this->registry->cache();
			$this->caches		=& $this->registry->cache()->fetchCaches();
		}
	}
	

	
	/**
	 * Returns the data for the app landing items
	 * Data should be an array of stats to show
	 *
	 * @return	array(stats)
	 */
	public function fetchGeneralStats()
	{
		/* INIT */
		$stats_output = array();
		if( !$this->caches['stats'] )
		{
			$this->caches['stats'] = $this->cache->getCache('stats');
		}
		$stats = $this->caches['stats'];
		$cut_off = $this->settings['au_cutoff'] * 60;
				$time    = time() - $cut_off;
				$total	 = $this->DB->buildAndFetch( array( 'select'	=> 'count(*) as users_online', 'from' => 'sessions', 'where' => "running_time > $time" ) );

				$users_online = $total['users_online'];
//-----------------------------------------
			// Update the most active count if needed
			//-----------------------------------------
			
			if ( $users_online > $stats['most_count'] )
			{
				$stats['most_count'] = $users_online;
				$stats['most_date']  = time();
				
				$this->cache->setCache( 'stats', $stats, array( 'array' => 1 ) );
			}
		$stats_output['most_time']  = intval($stats['most_date']);
$stats_output['most_count'] =  intval($stats['most_count']);
$stats_output['mem_count']   =  intval($stats['mem_count']);
$stats_output['last_member']	= intval($stats['last_mem_id']);
$stats_output['avg_regs'] = round(($stats['mem_count']/(round( (time() - $this->settings['board_start'])/86400 ))), 2 );
		return $stats_output;
	}
	public function formatGeneralStats($data)
	{
foreach($data as $key => $val)
{
switch($key)
{
case 'most_count':
case 'mem_count':
$data[$key] = $this->lang->formatNumber($val);
break;
case 'avg_regs':
$data[$key] = $this->lang->formatNumber($val, 2);
break;
case 'most_time':
$data[$key] = $this->lang->getDate($val, 'LONG' );
break;
case 'last_member':
$data[$key] = $this->registry->output->getTemplate( 'global')->userHoverCard(IPSMember::load($val));
break;
}
}
return $data;
}
}
