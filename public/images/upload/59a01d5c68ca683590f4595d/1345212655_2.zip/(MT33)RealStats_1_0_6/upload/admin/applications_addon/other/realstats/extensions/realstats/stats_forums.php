<?php
/**
* Real Stats Module for FORUMS
*
*/
/**
 * @ Application : 		RealStats
 * @ File : 			stats_forums.php
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
class stats_forums implements iRealStats
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $memberData;
	protected $cache;
	protected $caches;
	
	private $forumIDs = array();
	/**
	 * CONSTRUCTOR
	 *
	 */
	public function __construct( ipsRegistry $registry, $app='core')
	{
		if ( ! $this->registry )
		{
			/* Make registry objects */
			$this->registry		=  $registry;
			$this->DB			=  $this->registry->DB();
			$this->settings		=& $this->registry->fetchSettings();
			$this->request		=& $this->registry->fetchRequest();
			$this->lang			=  $this->registry->getClass('class_localization');
			$this->member		=  $this->registry->member();
			$this->memberData	=& $this->registry->member()->fetchMemberData();
			$this->cache		=  $this->registry->cache();
			$this->caches		=& $this->registry->cache()->fetchCaches();
		}
		
		
		
		
	}
	

	/**
	 * Returns the data for the app landing items
	 * Data should be an array of stats to show
	 *
	 * @return	array(stats)
	 */
	public function fetchGeneralStats()
	{

		/* INIT */
/* Load forums class */
		if ( ! $this->registry->isClassLoaded('class_forums' ) )
		{
			try
			{
				$classToLoad = IPSLib::loadLibrary( IPSLib::getAppDir('forums') . '/sources/classes/forums/class_forums.php', 'class_forums', 'forums' );
				$this->registry->setClass( 'class_forums', new $classToLoad( $this->registry ) );
				$this->registry->getClass('class_forums')->strip_invisible = 1;
				$this->registry->getClass('class_forums')->forumsInit();

			}
			catch( Exception $error )
			{
				IPS_exception_error( $error );
			}
		}
$this->forumIDs = $this->registry->class_forums->forum_by_id;
		$stats_output = array();
if( !$this->caches['stats'] )
		{
			$this->caches['stats'] = $this->cache->getCache('stats');
		}
$stats_output['total_posts'] = intval($this->caches['stats']['total_topics']+$this->caches['stats']['total_replies']);
$stats_output['total_replies'] = intval($this->caches['stats']['total_replies']);
$stats_output['total_topics'] = intval($this->caches['stats']['total_topics']);
$stats_output['avg_posts'] = round($stats_output['total_posts']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['avg_replies'] = round($stats_output['total_replies']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$stats_output['avg_topics'] = round($stats_output['total_topics']/(round( (time() - $this->settings['board_start'])/86400 )), 2 );
$categories = 0;
$forums = 0;
if(count($this->forumIDs) && is_array($this->forumIDs))
{
foreach( $this->forumIDs as $id => $data )
{
if($data['parent_id']=='root' || $data['parent_id']=='-1' )
{
$categories++;
}
if ( $this->registry->permissions->check( 'read', $data ) === true )
{
if(!$data['redirect_on'] && $data['parent_id']!='root' && $data['parent_id']!='-1')
{
$forums++;
}
}
}
}
$stats_output['total_categories'] = intval($categories);
$stats_output['total_forums'] = intval($forums);
		return $stats_output;
	}

	public function formatGeneralStats($data)
	{
foreach($data as $key => $val)
{
switch($key)
{
case 'total_posts':
case 'total_replies':
case 'total_topics':
case 'total_categories':
case 'total_forums':
$data[$key] = $this->lang->formatNumber($val);
break;
case 'avg_posts':
case 'avg_replies':
case 'avg_topics':
$data[$key] = $this->lang->formatNumber($val, 2);
break;
}
}
return $data;
}

	/**
	 * Gets the data for the application tab
	 * Data should be array of stats data variables to pass to the html
	 *
	 * @return	array(stats)
	 */
	public function fetchDetailedStats($limit)
	{
/* Load forums class */
		if ( ! $this->registry->isClassLoaded('class_forums' ) )
		{
			try
			{
				$classToLoad = IPSLib::loadLibrary( IPSLib::getAppDir('forums') . '/sources/classes/forums/class_forums.php', 'class_forums', 'forums' );
				$this->registry->setClass( 'class_forums', new $classToLoad( $this->registry ) );
				$this->registry->getClass('class_forums')->strip_invisible = 1;
				$this->registry->getClass('class_forums')->forumsInit();

			}
			catch( Exception $error )
			{
				IPS_exception_error( $error );
			}
		}
$this->forumIDs = $this->registry->class_forums->forum_by_id;
$classToLoad = IPSLib::loadLibrary( IPSLib::getAppDir( 'forums' ) . '/sources/classes/topics.php', 'app_forums_classes_topics', 'forums' );
$topicsClass = new $classToLoad( $this->registry );
$forums = array();
$topforumsbypost = array();
$topforumsbytopics = array();
$topmembers = array();
$_topmembers = array();
if(count($this->forumIDs) && is_array($this->forumIDs))
{
foreach( $this->forumIDs as $id => $data )
{
if ( $this->registry->permissions->check( 'read', $data ) === true )
{
if(!$data['redirect_on'] && $data['sub_can_post'] )
{
$forums[] = intval($data['id']);
if($data['posts'])
{
$topforumsbypost[intval($data['id'])] = $data;
}
if($data['topics'])
{
$topforumsbytopics[intval($data['id'])] = $data;
}
}
}
}
}
if ( is_array( $forums ) AND count( $forums ) )
		{
$topicsByReply = $topicsClass->getTopics(array('sortField' => 'posts', 'sortOrder' => 'DESC', 'limit' => $limit, 'checkArchived' => true));
$topicsByViews = $topicsClass->getTopics(array('sortField' => 'views', 'sortOrder' => 'DESC', 'limit' => $limit, 'checkArchived' => true));
$topicsByRating = $topicsClass->getTopics(array('sortField' => 'topic_rating_total', 'sortOrder' => 'DESC', 'limit' => $limit, 'checkArchived' => true));
if ( is_array( $topicsByRating ) AND count( $topicsByRating ) )
		{
foreach($topicsByRating as &$topic)
{
$topic['rating'] = intval((intval($topic['topic_rating_hits'] )>0)?round($topic['topic_rating_total']/$topic['topic_rating_hits']):$topic['topic_rating_total']);
foreach($topic as $key => $val)
{
if(!in_array($key, array('tid', 'rating', 'title', 'title_seo', 'start_date', 'starter_id')))
{
unset($topic[$key]);
}
}
}
}
if ( is_array( $topicsByViews ) AND count( $topicsByViews ) )
		{
foreach($topicsByViews as &$topic)
{
foreach($topic as $key => $val)
{
if(!in_array($key, array('tid', 'views', 'title', 'title_seo', 'start_date', 'starter_id')))
{
unset($topic[$key]);
}
}
}
}
if ( is_array( $topicsByReply ) AND count( $topicsByReply ) )
		{
foreach($topicsByReply as &$topic)
{
foreach($topic as $key => $val)
{
if(!in_array($key, array('tid', 'posts', 'title', 'title_seo', 'start_date', 'starter_id')))
{
unset($topic[$key]);
}
}
}
}
if ( is_array( $topforumsbypost ) AND count( $topforumsbypost ) )
		{
 /* Sort High to Low, get just our desired quantity */
uasort( $topforumsbypost, array( $this, 'forumsPostSort' ) );
$topforumsbypost = array_slice( $topforumsbypost, 0, $limit );
foreach($topforumsbypost as &$forum)
{
foreach($forum as $key => $val)
{
if(!in_array($key, array('id', 'posts', 'name', 'name_seo', 'last_post', 'last_poster_id')))
{
unset($forum[$key]);
}
}
}
}
if ( is_array( $topforumsbytopics ) AND count( $topforumsbytopics ) )
		{
 /* Sort High to Low, get just our desired quantity */
uasort( $topforumsbytopics, array( $this, 'forumsTopicSort' ) );
$topforumsbytopics = array_slice( $topforumsbytopics, 0, $limit );
foreach($topforumsbytopics as &$forum)
{
foreach($forum as $key => $val)
{
if(!in_array($key, array('id', 'topics', 'name', 'name_seo', 'last_post', 'last_poster_id')))
{
unset($forum[$key]);
}
}
}
}
$this->DB->build( array( 'select'   => 'member_id',
                                                 'from'  => 'members',
                                                 'order'        => "posts DESC",
                                                 'limit'        => array( 0, $limit ),
                                )          );
		$data = $this->DB->execute();

		while ( $row = $this->DB->fetch($data) )
		{
        		$topmembers[intval($row['member_id'])] = intval($row['member_id']);
		}
$this->DB->freeResult($data);
if ( is_array( $topmembers ) AND count( $topmembers ) )
		{
$topmembers = IPSMember::load($topmembers);
foreach($topmembers as $mid)
{
if(!IPSMember::isInActive($mid))
{
$_topmembers[] = intval($mid['member_id']);
}
}
}
}
return array('forumsByPost' => $topforumsbypost, 'forumsByTopic' => $topforumsbytopics, 'topicsByReply' => $topicsByReply, 'topicsByViews' => $topicsByViews, 'topicsByRating' => $topicsByRating, 'topMembersByPost' => $_topmembers);
	}
public function returnDetailedStats($data)
{
//preproccess members
$posters = array();
static $proccessedMembers = array();
if ( is_array( $data['topMembersByPost'] ) AND count( $data['topMembersByPost'] ) )
		{
usort( $data['topMembersByPost'], array( $this, 'membersPostSort' ) );

foreach( $data['topMembersByPost'] as $k => $mid)
{
if(!isset($proccessedMembers[$mid]))
{
$posters[$k] = IPSMember::buildDisplayData($mid);
$proccessedMembers[$mid] = $posters[$k];
}
else
{
$posters[$k] = $proccessedMembers[$mid];
}
}
}
//preproccess members
if ( is_array(  $data['topicsByViews'] ) AND count(  $data['topicsByViews'] ) )
		{
foreach( $data['topicsByViews'] as &$mid)
{
if(!isset($proccessedMembers[$mid['starter_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['starter_id']);
$proccessedMembers[$mid['starter_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['starter_id']];
}
}
}
if ( is_array(  $data['topicsByRating'] ) AND count(  $data['topicsByRating'] ) )
		{
foreach( $data['topicsByRating'] as &$mid)
{
if(!isset($proccessedMembers[$mid['starter_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['starter_id']);
$proccessedMembers[$mid['starter_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['starter_id']];
}
}
}
if ( is_array(  $data['topicsByReply'] ) AND count(  $data['topicsByReply'] ) )
		{
foreach( $data['topicsByReply'] as &$mid)
{
if(!isset($proccessedMembers[$mid['starter_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['starter_id']);
$proccessedMembers[$mid['starter_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['starter_id']];
}
}
}
if ( is_array(  $data['forumsByPost'] ) AND count(  $data['forumsByPost'] ) )
		{
foreach( $data['forumsByPost'] as &$mid)
{
if(!isset($proccessedMembers[$mid['last_poster_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['last_poster_id']);
$proccessedMembers[$mid['last_poster_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['last_poster_id']];
}
}
}
if ( is_array(  $data['forumsByTopic'] ) AND count(  $data['forumsByTopic'] ) )
		{
foreach( $data['forumsByTopic'] as &$mid)
{
if(!isset($proccessedMembers[$mid['last_poster_id']]))
{
$mid['member'] = IPSMember::buildDisplayData($mid['last_poster_id']);
$proccessedMembers[$mid['last_poster_id']] = $mid['member'];
}
else
{
$mid['member'] = $proccessedMembers[$mid['last_poster_id']];
}
}
}
return $this->registry->getClass('output')->getTemplate('realstats_global')->realStatsApp_forums($data['forumsByPost'], $data['forumsByTopic'], $data['topicsByReply'], $data['topicsByViews'], $data['topicsByRating'], $posters, $data['truncate']);
}
private function membersPostSort( $a, $b)
        {
//I dont like this, but my array must be preserved....
//@link http://community.invisionpower.com/topic/367084-download-realstats/page__st__40#entry2296369
$a = is_array($a)?$a:IPSMember::load($a);
$b = is_array($b)?$b:IPSMember::load($b);
                return( $a['posts'] < $b['posts'] ) ? 1 : -1;
        }
private function forumsTopicSort( $a, $b)
        {
                return( $a['topics'] < $b['topics'] ) ? 1 : -1;
        }
private function forumsPostSort( $a, $b)
        {
                return( $a['posts'] < $b['posts'] ) ? 1 : -1;
        }	
}
