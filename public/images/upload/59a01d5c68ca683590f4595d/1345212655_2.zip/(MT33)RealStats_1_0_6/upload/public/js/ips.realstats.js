/**
 * @ Application : 		RealStats
 * @ File : 			ipsrealstats.js
 * @ Last Updated : 	Tue, 07 Aug 2012 16:24:08 -0600 
 * @ Author :			Robert Marcher
 * @ Copyright :		(c) 2012 Marcher Technologies
 * @ Link	 : http://www.marchertech.com/
 */
var _realstats = window.IPBoard;

_realstats.prototype.realstats = {
	activeTab: '',
	init: function()
	{
		Debug.write("Initializing ips.realstats.js");
		
		document.observe("dom:loaded", function(){
			ipb.realstats.initEvents();
		});
	},
	
	/* ------------------------------ */
	/**
	 * Initialize events for the profile page
	*/
	initEvents: function()
	{
		ipb.delegate.register('.tab_toggle_stats', ipb.realstats.changeTabContent );
	},
	
	changeTabContent: function(e, elem)
	{
		Event.stop(e);
		var id = elem.id.replace('tab_link_', '');

		if( !id || id.blank() ){ return; }
		
		if( !$('pane_' + id) )
		{
var urlExtra = id.replace('default', '');
if(urlExtra)
{
var url = 'app=realstats&section=display&module=display&stats_app=' + id;
}
else
{
var url = 'app=realstats&section=display&module=display';
}
new Ajax.Request( ipb.vars['base_url'] + url + '&ajax=1&md5check=' + ipb.vars['secure_hash'],
							{
								method: 'post',
								onSuccess: function(t)
								{
									if( t.responseText == 'nopermission' )
									{
										alert( ipb.lang['no_permission'] );
										return;
									}
									
									if( t.responseText != 'error' )
									{
										var newdiv = new Element('div', { 'id': 'pane_' + id } ).hide().update( t.responseText );
										$('realstats_content').insert( newdiv );
										$( newdiv ).addClassName('ipsPad_half');
										ipb.realstats.togglePanes( id );
										
										
									}
									else
									{
										alert( ipb.lang['action_failed'] );
										return;
									}
								}
							});
		}
		else
		{
			ipb.realstats.togglePanes( id );
		}
		
	},
	
	togglePanes: function( newid )
	{
		var currentID = $('realstats_tabs').select(".active")[0].id.replace('tab_link_', '');
		var currentPane = $('pane_' + currentID);
		
		var newPane = $('pane_' + newid);
		
		var curHeight = $(currentPane).measure('height');
		var newHeight = $(newPane).measure('height');
		
		// Hide current one
		$('realstats_content').setStyle( { height: curHeight + "px" } );
		$( currentPane ).absolutize();
		new Effect.Fade( $( currentPane ), { duration: 0.2 } );
		
		// Resize container
		new Effect.Morph( $('realstats_content'), { style: 'height: ' + newHeight + 'px', duration: 0.2, afterFinish: function(){
			new Effect.Appear( newPane, { duration: 0.2, afterFinish: function(){
				$('realstats_content').setStyle( { height: 'auto' } );
				$( currentPane ).setStyle( { position: 'static', height: 'auto' } );

			} } );
		} } );
		
		$('realstats').select(".tab_toggle_stats").invoke("removeClassName", "active");
		$('tab_link_' + newid).addClassName('active');

var newLang = ipb.lang['realstats_tab_' + newid];
var newTitle = ipb.lang['realstats_tab_title_' + newid];
var pageTitle = ipb.lang['realstats_title']+ipb.lang["realstats_title_sep"] +newLang + ipb.lang["realstats_title_sep"] + ipb.lang["realstats_board_name"];
if(newTitle!=null)
{
if($('realstatstitle')!==null && $('realstatstitle').innerHTML!=newTitle)
{
$('realstatstitle').update(newTitle);
}
}
else
{
if($('realstatstitle')!==null && $('realstatstitle').innerHTML!=ipb.lang['realstats_title_prefix']+newLang)
{
$('realstatstitle').update(ipb.lang['realstats_title_prefix']+newLang);
}
}
if($$('title')!==null && $$('title')[0].innerHTML!=pageTitle)
{
$$('title')[0].update(pageTitle);
}
$$('.breadcrumb.top li').each(function(e)
{
if(!$(e).down('a'))
{
var oldCrumb = $(e).down('span').next();
if(oldCrumb.innerHTML!=newLang)
{
oldCrumb.update(newLang);
}
}
});
$$('.breadcrumb.bottom li').each(function(e)
{
if(!$(e).down('a'))
{
var oldCrumb = $(e);
if(oldCrumb.innerHTML!=ipb.lang["realstats_nav_sep"] + newLang)
{
oldCrumb.update(ipb.lang["realstats_nav_sep"] + newLang);
}
}
});


	},
};
