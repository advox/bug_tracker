<?php

$SQL[] = "ALTER TABLE gallery_ratings ADD INDEX (img_id)";
