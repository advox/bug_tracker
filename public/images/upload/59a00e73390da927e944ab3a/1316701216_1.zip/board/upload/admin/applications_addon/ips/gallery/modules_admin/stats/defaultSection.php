<?php
/**
 * @file		defaultSection.php 	Define the default section for the 'stats' module
 *~TERABYTE_DOC_READY~
 * $Copyright: (c) 2001 - 2011 Invision Power Services, Inc.$
 * $License: http://www.invisionpower.com/company/standards.php#license$
 * $Author: ips_terabyte $
 * $LastChangedDate: 2011-05-18 09:00:51 -0400 (Wed, 18 May 2011) $
 * @version		v4.1.1
 * $Revision: 8821 $
 */

$DEFAULT_SECTION = 'stats';
