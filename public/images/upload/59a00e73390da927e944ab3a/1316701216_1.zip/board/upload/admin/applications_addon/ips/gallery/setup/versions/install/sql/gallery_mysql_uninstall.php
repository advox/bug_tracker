<?php
$QUERY[] = "DELETE FROM rc_classes WHERE my_class='gallery';";