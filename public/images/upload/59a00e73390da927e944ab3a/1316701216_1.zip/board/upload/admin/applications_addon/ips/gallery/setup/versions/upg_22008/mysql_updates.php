<?php

$SQL[] = "ALTER TABLE gallery_images CHANGE credit_info credit_info text NULL";
