<?php

$SQL[] = "DELETE FROM task_manager WHERE task_application='gallery' AND task_key IN ('imageviews','gallerystats');";

