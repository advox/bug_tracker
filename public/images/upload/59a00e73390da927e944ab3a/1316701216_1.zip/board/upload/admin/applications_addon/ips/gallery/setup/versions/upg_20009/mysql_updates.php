<?php

$SQL[] = "ALTER TABLE gallery_images ADD INDEX ( approved )";
$SQL[] = "ALTER TABLE gallery_bandwidth ADD INDEX ( date )";
