<?php

$SQL[] = "ALTER TABLE gallery_categories ADD mod_images INT( 10 ) DEFAULT '0' NOT NULL";
