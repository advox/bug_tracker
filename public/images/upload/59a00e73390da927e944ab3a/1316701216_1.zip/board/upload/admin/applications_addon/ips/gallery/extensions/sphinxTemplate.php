<?php

/**
 * <pre>
 * Invision Power Services
 * IP.Board v4.1.1
 * Sphinx template file
 * Last Updated: $Date: 2011-06-02 17:57:20 -0400 (Thu, 02 Jun 2011) $
 * </pre>
 *
 * @author 		$Author: bfarber $
 * @copyright	(c) 2001 - 2009 Invision Power Services, Inc.
 * @license		http://www.invisionpower.com/community/board/license.html
 * @package		IP.Gallery
 * @link		http://www.invisionpower.com
 * @version		$Rev: 8953 $
 * @since		3.0.0
 *
 */

/* This is just an empty sphinx template to ensure we overwrite outdated ones on upgrade */
$appSphinxTemplate	= "";