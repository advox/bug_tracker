<?php

$SQL[] = "ALTER TABLE gallery_images ADD rating TINYINT( 2 ) UNSIGNED DEFAULT '0' NOT NULL";
