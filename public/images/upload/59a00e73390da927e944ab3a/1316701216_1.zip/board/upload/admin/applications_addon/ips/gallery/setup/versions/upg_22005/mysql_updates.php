<?php

/* No longer relevant, in IPB 3 conf_settings table was dropped 
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_last5_images';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_random_images';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_stats';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_cat_index_pos';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_stats_index_pos';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_last5_index_pos';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_rand5_index_pos';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_user';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_date';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_filesize';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_comments';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_views';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_show_rate';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_username';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_date';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_size';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_comment';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_view';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_img_order_rating';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_album_create';";
$SQL[] = "DELETE FROM conf_settings WHERE conf_key='gallery_allow_search';";
*/
