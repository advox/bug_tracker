<?php

$SQL[] = "ALTER TABLE gallery_albums CHANGE  name_seo  name_seo VARCHAR( 255 ) NOT NULL;";
$SQL[] = "ALTER TABLE gallery_categories CHANGE  name_seo  name_seo VARCHAR( 255 ) NOT NULL;";
