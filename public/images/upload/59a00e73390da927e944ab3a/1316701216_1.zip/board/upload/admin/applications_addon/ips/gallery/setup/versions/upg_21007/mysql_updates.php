<?php

$SQL = array();

$SQL[]	= "ALTER TABLE gallery_albums ADD INDEX ( category_id );";
