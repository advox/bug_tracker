<?php

/*
+---------------------------------------------------------------------------
|   IP.Board v3.2.2
|   ========================================
|   by Matthew Mecham
|   (c) 2008 Invision Power Services
|   http://www.invisionpower.com
|   ========================================
+---------------------------------------------------------------------------
|   Invision Power Board IS NOT FREE SOFTWARE!
+---------------------------------------------------------------------------
|   http://www.invisionpower.com/
|   > $Id: galleryRebuild4_php.php 8887 2011-05-25 14:30:28Z ips_terabyte $
|   > $Revision: 8887 $
|   > $Date: 2011-05-25 10:30:28 -0400 (Wed, 25 May 2011) $
+---------------------------------------------------------------------------
*/
@set_time_limit( 3600 );
define( 'IMAGES_PER_GO', 25 );
define( 'ALBUMS_PER_GO', 100 );

/**
* Main public executable wrapper.
*
* Set-up and load module to run
*
* @package	IP.Board
* @author   Matt Mecham
* @version	3.0
*/

require_once( './initdata.php' );/*noLibHook*/

require_once( IPS_ROOT_PATH . 'sources/base/ipsRegistry.php' );/*noLibHook*/

$reg = ipsRegistry::instance();
$reg->init();

$moo = new moo( $reg );

class moo
{
	private $processed = 0;
	private $parser;
	private $oldparser;
	private $start     = 0;
	private $end       = 0;
	
	function __construct( ipsRegistry $registry )
	{
		$this->registry   =  $registry;
		$this->DB         =  $this->registry->DB();
		$this->settings   =& $this->registry->fetchSettings();
		$this->request    =& $this->registry->fetchRequest();
		$this->cache      =  $this->registry->cache();
		$this->caches     =& $this->registry->cache()->fetchCaches();
		$this->memberData = array();

		/* Gallery Object */
		require_once( IPSLib::getAppDir('gallery') . '/sources/classes/gallery.php' );/*noLibHook*/
		$this->registry->setClass( 'gallery', new ipsGallery( $this->registry ) );
		$this->images = $this->registry->gallery->helper('image');
		$this->albums = $this->registry->gallery->helper('albums');
		$this->tools  = $this->registry->gallery->helper('tools');
		
		switch( $this->request['do'] )
		{
			case 'images':
				$this->convertImages();
			break;
			case 'albums':
				$this->convertAlbums();
			break;
			case 'resync':
				$this->resyncAlbums();
			break;
			case 'rules':
				$this->convertRules();
			break;
			default:
				$this->splash();
			break;
		}
	}
	
	function show( $content, $url='' )
	{
		if ( $url )
		{
			$firstBit = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
			$refresh = "<meta http-equiv='refresh' content='0; url={$firstBit}?{$url}'>";
		}
		
		if ( is_array( $content ) )
		{
			$content = implode( "<br />", $content );
		}
		
		$html = <<<EOF
		<html>
			<head>
				<title>Gallery Rebuild</title>
				$refresh
			</head>
			<body>
				$content
			</body>
		</html>			
EOF;

		print $html; exit();
	}
	
	/**
	 * SPLASH
	 */
	function splash()
	{
		$html = <<<EOF
		Do you want to:<br />
		<a href="?do=albums">Convert Albums</a><br />
		<a href="?do=resync">Resync Albums</a><br />
		<a href="?do=rules">Restore Album Rules</a><br />
		<a href="?do=images">Rebuild Images</a>
		<br />
		<br />
		You should do albums first if in doubt.
EOF;
	
		$this->show( $html );
	}
	
	/**
	 * Convert images
	 */
	function convertImages()
	{
		$id         = intval( $this->request['id'] );
		$lastId     = 0;
		$done  		= intval( $this->request['done'] );
		$cycleDone  = 0;
		$content    = array();
		
		if ( ! $id )
		{
			/* Fisrt pass */
			$this->registry->gallery->helper('moderate')->resetPermissions(0);
		}
		
		/* skipping? */
		$total = $this->DB->buildAndFetch( array( 'select' => 'count(*) as count',
										          'from'   => 'gallery_images' ) );
		
		/* Fetch batch */
		$this->DB->build( array( 'select' => '*',
								 'from'   => 'gallery_images',
								 'where'  => 'id > ' . $id,
								 'limit'  => array( 0, IMAGES_PER_GO ),
								 'order'  => 'id ASC' )  );
								
		$o = $this->DB->execute();
		
		while( $row = $this->DB->fetch( $o ) )
		{
			$cycleDone++;
			$lastId = $row['id'];
			
			$content[] = "Rebuilding image " . ( $done + $cycleDone ) . " (id: " . $row['id'] . ") of " . $total['count'];
			
			$this->images->resync( $row );
			$this->images->buildSizedCopies( $row );
		}
		
		/* More? */
		if ( $cycleDone )
		{
			/* Reset */
			$done += $cycleDone;
			
			$this->show( $content, "do=images&id=" . $lastId . "&done=" . $done );
		}
		else
		{
			$this->show( "All images rebuilt" );
			return;
		}
	}
	
	/**
	 * Convert images
	 */
	function resyncAlbums()
	{
		$id         = intval( $this->request['id'] );
		$lastId     = 0;
		$done  		= intval( $this->request['done'] );
		$cycleDone  = 0;
		$content    = array();
		
		/* skipping? */
		$total = $this->DB->buildAndFetch( array( 'select' => 'count(*) as count',
										          'from'   => 'gallery_albums_main' ) );
		
		/* Fetch batch */
		$this->DB->build( array( 'select' => '*',
								 'from'   => 'gallery_albums_main',
								 'where'  => 'album_id > ' . $id,
								 'limit'  => array( 0, ALBUMS_PER_GO ),
								 'order'  => 'album_id ASC' )  );
								
		$o = $this->DB->execute();
		
		while( $row = $this->DB->fetch( $o ) )
		{
			$cycleDone++;
			$lastId = $row['album_id'];
			
			$content[] = "Rebuilding album " . ( $done + $cycleDone ) . " (id: " . $row['album_id'] . ") of " . $total['count'];
			
			$this->albums->resync( $row );
		}
		
		/* More? */
		if ( $cycleDone )
		{
			/* Reset */
			$done += $cycleDone;
			
			$this->show( $content, "do=resync&id=" . $lastId . "&done=" . $done );
		}
		else
		{
			$this->show( "All albums resynchronized" );
			return;
		}
	}
	
	/**
	 * Convert rules
	 */
	function convertRules()
	{
		$this->tools->restoreAlbumRules();
		
		$this->show( "All albums rules restored" );
		return;
	}
	
	/**
	 * Convert albums
	 */
	function convertAlbums()
	{
		$PRE = ipsRegistry::dbFunctions()->getPrefix();
			
		/* Start process */
		$this->DB->query( "TRUNCATE TABLE `{$PRE}gallery_albums_main`");
		
		$this->DB->allow_sub_select = 1;
		
		/* First off, convert over albums */
		$this->DB->query("INSERT INTO `{$PRE}gallery_albums_main`
							(album_id, album_parent_id, album_owner_id, album_name, album_name_seo, album_description, album_is_public,
							 album_is_global, album_is_profile, album_count_imgs, album_count_comments, album_count_imgs_hidden,
							 album_count_comments_hidden, album_cover_img_id, album_last_img_id, album_last_img_date, album_sort_options,
							  album_allow_comments, album_cache, album_node_level, album_node_left, album_node_right, album_g_approve_img, album_g_approve_com,
							 album_g_bitwise, album_g_rules, album_g_container_only, album_g_perms_thumbs, album_g_perms_view,
							 album_g_perms_images, album_g_perms_comments, album_g_perms_moderate )
							
							( SELECT a.id, a.parent, a.member_id, a.name, a.name_seo, a.description,( CASE WHEN a.friend_only THEN 2 WHEN a.public_album THEN 1 ELSE 0 END ),
							0, a.profile_album, a.images, a.comments, a.mod_images,
							a.mod_comments, 0, 0, 0, '',
							1, CONCAT( 'cat-', a.category_id ), '', 0, 0, 0, 0,
							0, '', 0, '*', '*',
							'*', '*', '' FROM `{$PRE}gallery_albums` a)" );
		
		print "Converted albums, first pass<br />";
																		
		$this->DB->allow_sub_select = 1;
		
		/* Convert categories */					
		$this->DB->query("INSERT INTO `{$PRE}gallery_albums_main`
							(album_parent_id, album_owner_id, album_name, album_name_seo, album_description, album_is_public,
							 album_is_global, album_is_profile, album_count_imgs, album_count_comments, album_count_imgs_hidden,
							 album_count_comments_hidden, album_cover_img_id, album_last_img_id, album_last_img_date, album_sort_options,
							 album_allow_comments, album_cache, album_node_level, album_node_left, album_node_right, album_g_approve_img, album_g_approve_com,
							 album_g_bitwise, album_g_rules, album_g_container_only, album_g_perms_thumbs, album_g_perms_view,
							 album_g_perms_images, album_g_perms_comments, album_g_perms_moderate )
							
							( SELECT 0, 0, c.name, c.name_seo, c.description, 1,
							1, 0, c.images, c.comments, c.mod_images,
							0, 0, 0, 0, '',
							c.allow_comments, CONCAT( 'catid-', c.id ), 0, 0, 0 , c.mod_images, c.mod_comments,
							0, CONCAT( 'parent-cat-', c.parent ), c.category_only, p.perm_view, p.perm_2,
							p.perm_3, p.perm_4, p.perm_5 FROM `{$PRE}gallery_categories` c, `{$PRE}permission_index` p WHERE p.perm_type='cat' AND p.perm_type_id=c.id AND p.app='gallery' ORDER BY c.id ASC)" );
		
		
		$this->DB->query("UPDATE {$PRE}gallery_albums_main SET
							album_g_perms_thumbs   = TRIM( BOTH ',' FROM  album_g_perms_thumbs ),
							album_g_perms_view     = TRIM( BOTH ',' FROM  album_g_perms_view ),
							album_g_perms_images   = TRIM( BOTH ',' FROM  album_g_perms_images ),
							album_g_perms_comments = TRIM( BOTH ',' FROM  album_g_perms_comments ),
							album_g_perms_moderate = TRIM( BOTH ',' FROM  album_g_perms_moderate );" );
			
			
		print "Converted categories, first pass<br />";
		
		/* Run them through and process old categories */
		$this->DB->build( array( 'select' => '*',
								 'from'   => 'gallery_albums_main',
								 'where'  => 'album_is_global=1 AND album_g_rules LIKE \'parent-cat-%\'' ) );
								 
		$o = $this->DB->execute();
		
		while( $row = $this->DB->fetch( $o ) )
		{
			$oldParent = str_replace( 'parent-cat-', '', $row['album_g_rules'] );
			
			if ( intval( $oldParent ) and $oldParent > 0 )
			{
				$parent = $this->DB->buildAndFetch( array( 'select' => 'album_id',
															'from'   => 'gallery_albums_main',
															'where'  => 'album_cache=\'catid-' . $oldParent . '\'' ) );
															
				/* convert */
				$this->DB->update( 'gallery_albums_main', array( 'album_parent_id' => intval( $parent['album_id'] ) ), 'album_id=' . $row['album_id'] );
				
				$content[] =  "Updated parent category association for " . $row['album_id'] . '<br />';
			}
		}
		
		/* Associate images with new global albums from cats */
		$this->DB->build( array( 'select' => '*',
								 'from'   => 'gallery_albums_main',
								 'where'  => 'album_cache LIKE \'catid-%\'' ) );
								 
		$o = $this->DB->execute();
		
		while( $row = $this->DB->fetch( $o ) )
		{
			$oldParent = str_replace( 'catid-', '', $row['album_cache'] );
			
			$this->DB->update( 'gallery_images', array( 'img_album_id' => intval( $row['album_id'] ) ), 'category_id=' . intval( $oldParent ) );
				
			$content[] = "Updated parent association for " . $row['album_id'] . ". Old parent - {$oldParent} " . '<br />';
		}

		/* Associate albums with new global albums from cats */
		$this->DB->build( array( 'select' => '*',
								 'from'   => 'gallery_albums_main',
								 'where'  => 'album_cache LIKE \'cat-%\'' ) );
								 
		$o = $this->DB->execute();
		
		while( $row = $this->DB->fetch( $o ) )
		{
			$oldParent = str_replace( 'cat-', '', $row['album_cache'] );
			
			if ( $oldParent > 0 )
			{
				$parent = $this->DB->buildAndFetch( array( 'select' => 'album_id',
															'from'   => 'gallery_albums_main',
															'where'  => 'album_cache=\'catid-' . $oldParent . '\'' ) );
															
				/* convert */
				$this->DB->update( 'gallery_albums_main', array( 'album_parent_id' => intval( $parent['album_id'] ) ), 'album_id=' . $row['album_id'] );
				$this->DB->update( 'gallery_images', array( 'img_album_id' => intval( $parent['album_id'] ) ), 'category_id=' . intval( $oldParent ) );
				
				$content[] = "Updated parent association for " . $row['album_id'] . ". Old parent - {$oldParent}, new parent {$parent['album_id']} " . '<br />';
			}
		}
		
		/* Update */
		$this->DB->update( 'gallery_albums_main', array( 'album_node_level' => 0, 'album_node_left' => 0, 'album_node_right' => 0 ) );
		
		$this->albums->rebuildNodeTree();
		
		$this->show( $content );
	}
		
}


?>