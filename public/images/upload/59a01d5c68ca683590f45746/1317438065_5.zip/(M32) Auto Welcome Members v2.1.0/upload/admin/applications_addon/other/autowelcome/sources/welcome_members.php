<?php
/*
+--------------------------------------------------------------------------
|   (M32) Auto Welcome Members 2.1.0
|   =============================================
|   by Michael
|   Copyright 2007-2011 DevFuse
|   http://www.devfuse.com
+--------------------------------------------------------------------------
*/

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

class welcomeMembers
{
	protected $registry;
	protected $DB;
	protected $settings;
	protected $request;
	protected $lang;
	protected $member;
	protected $cache;
	
	public function __construct( ipsRegistry $registry )
	{		
		$this->registry = $registry;
		$this->DB	    = $this->registry->DB();
		$this->settings =& $this->registry->fetchSettings();
		$this->request  =& $this->registry->fetchRequest();
		$this->cache	= $this->registry->cache();
		$this->caches   =& $this->registry->cache()->fetchCaches();
		$this->lang		=  $this->registry->getClass('class_localization');
	}
	
	public function send_welcome( $member )
	{	
		$this->lang->loadLanguageFile( array( 'public_awm' ), 'autowelcome' );
        
        # Temp facebook fix
        /*if( !$member['members_display_name'] )
        {
            return FALSE;
        }
		
		# Validate does it a bit differently
		if( $member['real_group'] )
		{
			$member['member_group_id'] = $member['real_group'];
		}
        
		if( !$member['members_seo_name'] )
		{
			$member['members_seo_name'] = IPSMember::fetchSeoName( $member );
		}*/		
        		
		# Can't go with nothing
		if( !$member['member_id'] OR !$member['member_group_id'] )
		{
			return FALSE;	
		}
		
		$member_link = $this->registry->getClass('output')->formatUrl( $this->registry->getClass('output')->buildUrl( "{$this->settings['board_url']}/index.{$this->settings['php_ext']}?showuser={$member['member_id']}", 'none','' ), "{$member['members_seo_name']}", "showuser" );
		$this->lang->words['view_members_profile'] = str_replace('%MEMBER_NAME%', $member['members_display_name'], $this->lang->words['view_members_profile']);		

		$search  = array( "/%member_name%/", "/%board_name%/", "/%joined_date%/",  "/%profile_link%/" );
		$replace = array( IPSText::UNhtmlspecialchars( $member['members_display_name'] ), IPSText::UNhtmlspecialchars( $this->settings['board_name'] ), $this->registry->getClass('class_localization')->getDate( $member['joined'], 'LONG', 1 ), "[url='{$member_link}']{$this->lang->words['view_members_profile']}[/url]" );

		//--------------------------------------------------
		// Give out points?
		//-------------------------------------------------- 
				
		if($this->settings['aw_enable_points'] AND $this->DB->checkforField($this->settings['aw_points_field'], 'members'))
		{
			$this->settings['aw_points_factor'] = intval($this->settings['aw_points_factor']);
			
		 	$this->DB->update( 'members', "{$this->settings['aw_points_field']}={$this->settings['aw_points_field']}+{$this->settings['aw_points_factor']}", "member_id=".$member['member_id'], false, true );
			
			$search[]  .= "/%points%/";	
			$replace[] .= $this->settings['aw_points_factor'];							
		}	
		
		//--------------------------------------------------
		// Create the welcome topic?
		//-------------------------------------------------- 
 		if ($this->settings['aw_enable_topic'])
		{
    		# Get our forum and posting class
            require_once( IPSLib::getAppDir( 'forums' ) . '/app_class_forums.php' );
            $appClass    = new app_class_forums( ipsRegistry::instance() );
    
            require_once( IPSLib::getAppDir( 'forums' ) . '/sources/classes/post/classPost.php' );
            $this->_postClass = new classPost( ipsRegistry::instance() );
            $this->_postClass->setSettings( array( 'enableSignature' => 1, 'enableEmoticons' => 1, 'post_htmlstatus' => 0, 'enableTracker'   => 0 ) );
        
		    # Format Post
            //$this->settings['aw_topic_message'] = str_replace( "\n", "<br />", $this->settings['aw_topic_message'] );

            $post_contents = IPSText::UNhtmlspecialchars( $this->settings['aw_topic_message'] );
    		$post_contents = ( IPSText::getTextClass( 'editor' )->method == 'rte' ) ? $post_contents : IPSText::br2nl( $post_contents );
    		$post_contents = $this->_postClass->formatPost( preg_replace( $search, $replace, $post_contents ) );                                                                                             
			
			$this->settings['aw_topic_author'] == '0' ? $author_id = $member['member_id'] : $author_id = intval($this->settings['aw_topic_author']);
			
	        $this->_postClass->setIsPreview( false );
	        $this->_postClass->setForumData( $this->registry->getClass('class_forums')->forum_by_id[ intval( $this->settings['aw_topic_forum'] ) ] );
	        $this->_postClass->setForumID( intval( $this->settings['aw_topic_forum'] ) );
	        $this->_postClass->setPostContent( $post_contents );
	        $this->_postClass->setAuthor( $author_id );
	        $this->_postClass->setPublished( true );
	        $this->_postClass->setTopicTitle( preg_replace( $search, $replace, $this->settings['aw_topic_title'] ) );
            
            $this->_postClass->setBypassPermissionCheck( true );
	        
			//-----------------------------------------
			// Post it now. Single Ladies
			//-----------------------------------------
			
	        try
	        {
	            if( $this->_postClass->addTopic() )
	            {
	            	$topic_data = $this->_postClass->getTopicData();  			            	
					
					if( $this->settings['aw_pin_topics'] == '1' )
					{
						$this->pinTopic( $topic_data['tid'] );
					}
					if( $this->settings['aw_close_topics'] == '1' )
					{
						$this->closeTopic( $topic_data['tid'] );
					}	            	

					$search[]  .= "/%topic_link%/";	
					$replace[] .= "[url='".$this->registry->getClass('output')->formatUrl( $this->registry->getClass('output')->buildUrl( "{$this->settings['board_url']}/index.{$this->settings['php_ext']}?showtopic={$topic_data['tid']}", 'none','' ), "{$topic_data['title_seo']}", "showtopic" )."']{$this->lang->words['view_welcome_topic']}[/url]";								
		         
                 }
                 
	        }
	        catch( Exception $error )
	        {
				$search[]  .= "/%topic_link%/";	
				$replace[] .= "";								
	        }
		}
		else
		{
			$search[]  .= "/%topic_link%/";	
			$replace[] .= "";
		}
			
		//--------------------------------------------------
		// Send the welcome pm?
		//-------------------------------------------------- 		
  		if ($this->settings['aw_enable_pm'] AND $this->settings['aw_pm_from'] AND $this->settings['aw_pm_subject'])
		{	
    		# Get our forum and posting class
            require_once( IPSLib::getAppDir( 'forums' ) . '/app_class_forums.php' );
            $appClass    = new app_class_forums( ipsRegistry::instance() );
    
            require_once( IPSLib::getAppDir( 'forums' ) . '/sources/classes/post/classPost.php' );
            $this->_postClass = new classPost( ipsRegistry::instance() );
            $this->_postClass->setSettings( array( 'enableSignature' => 1, 'enableEmoticons' => 1, 'post_htmlstatus' => 0, 'enableTracker'   => 0 ) );			 

            $pm_message = IPSText::UNhtmlspecialchars( $this->settings['aw_pm_message'] );
    		$pm_message = ( IPSText::getTextClass( 'editor' )->method == 'rte' ) ? $pm_message : IPSText::br2nl( $pm_message );
    		$pm_message = preg_replace( $search, $replace, $pm_message );  
			
			try
			{
				require_once( IPSLib::getAppDir( 'members' ) . '/sources/classes/messaging/messengerFunctions.php' );
				$this->messenger = new messengerFunctions( $this->registry );
		
			 	$this->messenger->sendNewPersonalTopic( $member['member_id'], intval( $this->settings['aw_pm_from'] ), array(), preg_replace( $search, $replace, $this->settings['aw_pm_subject'] ), $pm_message, 
												array( 'origMsgID'			=> 0,
														'fromMsgID'			=> 0,
														'postKey'			=> md5(microtime()),
														'trackMsg'			=> 0,
														'addToSentFolder'	=> 0,
														'hideCCUser'		=> 0,
														'forcePm'			=> 1,
														'isSystem'          => TRUE
													)
												);
			}
			catch( Exception $error )
			{
				/// future idea						
				// Possibly add pm notice to admin to let them know of error.
			}	
		}
		
		//--------------------------------------------------
		// Send the welcome email?
		//-------------------------------------------------- 
		if ( $this->settings['aw_enable_email'] )
		{
			if( $this->settings['aw_email_from'] == "%board_email%" )
			{
				$this->settings['aw_email_from'] = $this->settings['email_out'];
			}
			
			if( IPSText::checkEmailAddress( $this->settings['aw_email_from'] ) )
			{
				//$this->settings['aw_email_message'] = str_replace("\n", "<br />", $this->settings['aw_email_message'] );
				
				IPSText::getTextClass('email')->message = stripslashes( IPSText::getTextClass('email')->cleanMessage( preg_replace( $search, $replace, $this->settings['aw_email_message'] ) ) );										
				IPSText::getTextClass('email')->subject = preg_replace( $search, $replace, $this->settings['aw_email_subject'] )." - ".$this->settings['board_name'];
				IPSText::getTextClass('email')->from    = $this->settings['aw_email_from']; 			
				IPSText::getTextClass('email')->to      = $member['email'];
				IPSText::getTextClass('email')->sendMail();
			}
		}			
		
		//--------------------------------------------------
		// Add the profile comment?
		//-------------------------------------------------- 
        
 		if( $this->settings['aw_profile_comments'] )
		{
    		if ( ! $this->registry->isClassLoaded( 'memberStatus' ) )
    		{
    			$classToLoad = IPSLib::loadLibrary( IPS_ROOT_PATH . 'sources/classes/member/status.php', 'memberStatus' );
    			$this->registry->setClass( 'memberStatus', new $classToLoad( ipsRegistry::instance() ) );
    		}		  

            //$this->registry->getClass('memberStatus')->setOwner( intval( $this->settings['aw_comment_author'] ) );
            $this->registry->getClass('memberStatus')->setAuthor( $member['member_id'] );

            $this->registry->getClass('memberStatus')->setContent( preg_replace( $search, $replace, $this->settings['aw_comment_message'] ) );
            $this->registry->getClass('memberStatus')->create();          
          
			//$this->DB->insert( 'member_status_updates', array('status_member_id' => $member['member_id'], 'status_author_id' => intval( $this->settings['aw_comment_author'] ), 'status_date' => time(), 'status_author_ip' => $member['ip_address'], 'status_content' => preg_replace( $search, $replace, $this->settings['aw_comment_message'] ), 'status_approved' => '1' ) );
		}
		
		//--------------------------------------------------
		// Add the shoutbox?
		//-------------------------------------------------- 
 		if ($this->settings['aw_shoutbox'])
		{
			$member_name = IPSMember::makeNameFormatted( $member['members_display_name'], $member['member_group_id'] );
			$this->insert_shout($member['member_id'], $member['members_display_name'], $member['member_group_id'], preg_replace( $search, $replace, $this->settings['aw_shoutbox_message'] ));
		}	
	}
	
	/*-------------------------------------------------------------------------*/
	// Insert Shout Function
	/*-------------------------------------------------------------------------*/
	public function insert_shout($member_id, $member_name, $member_group, $shoutbox_message="")
	{
		//--------------------------------------------------
		// Member Name
		//-------------------------------------------------- 	
		$bot_member_id = $member_id;	
		
		if($this->settings['aw_shoutbox_author'] != '-1')
		{
			$bot_member_id  = intval( $this->settings['aw_shoutbox_author'] );				
		}	
	
		//--------------------------------------------------
		// IP.Shoutbox - some code taken from shoutbox files.
		//-------------------------------------------------- 
		if( $this->settings['aw_shoutbox'] && $this->DB->checkForTable('shoutbox_shouts') )
		{		
			require_once( IPSLib::getAppDir( 'shoutbox' ) . '/sources/classes/library.php' );
			$this->registry->setClass( 'lib_shoutbox', new shoutboxLibrary( $this->registry ) );
			$this->registry->lib_shoutbox->_startup();
			if ( $this->registry->lib_shoutbox->shout_max_length && strlen($shoutbox_message) > $this->registry->lib_shoutbox->shout_max_length )
			{
				return false;
			}
			
			/* Parse the shout!! */
			$shout = $shoutbox_message;
			
			if( $this->settings['shoutbox_stop_shouting'] )
			{
				if( function_exists('mb_convert_case') )
				{
					if( in_array( strtolower( $this->settings['gb_char_set'] ), array_map( 'strtolower', mb_list_encodings() ) ) )
					{
						$shout = mb_convert_case( $shout, MB_CASE_LOWER, $this->settings['gb_char_set'] );
					}
					else
					{
						$shout = strtolower( $shout );
					}
				}
				else
				{
					$shout = strtolower( $shout );
				}
			}
						
			//$shout = $this->registry->lib_shoutbox->han_editor->processRawPost( $shout );
			$shout = $this->registry->lib_shoutbox->parser->preDbParse( $shout );
			
			if ( $this->registry->lib_shoutbox->parser->error != "" )
			{
				return false;
			}
			
			# Save Shout and ReCache
			$this->DB->force_data_type = array( 's_mid' => 'int', 's_message' => 'string' );			
			$this->DB->insert( 'shoutbox_shouts', array('s_mid' => $bot_member_id, 's_date' => time(), 's_message' => $shout, 's_ip' => $this->member->ip_address ) );
			
			$this->registry->lib_shoutbox->recacheShouts( 'recount', false );
		}
	}
	
	private function closeTopic( $topic_id )
	{
		$topic_id = intval( $topic_id );		
		$this->DB->update( 'topics', array( 'state' => 'closed', 'topic_open_time' => 0, 'topic_close_time' => 0 ), "tid=".$topic_id );
	}
	
	private function pinTopic( $topic_id )
	{
		$topic_id = intval( $topic_id );		
		$this->DB->update( 'topics', array( 'pinned' => 1 ), "tid=".$topic_id );
	}	
}