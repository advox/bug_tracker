<?php
/*
+--------------------------------------------------------------------------
|   (M32) Auto Welcome Members 2.1.0
|   =============================================
|   by Michael
|   Copyright 2007-2011 DevFuse
|   http://www.devfuse.com
+--------------------------------------------------------------------------
*/

class autowelcomeMemberSync
{
	public $registry;

	public function __construct()
	{
		$this->registry = ipsRegistry::instance();
        $this->settings = $this->registry->settings();	
	}

	public function onCompleteAccount( $member )
	{
		require_once( IPSLib::getAppDir( 'autowelcome' ) . '/sources/welcome_members.php' );
		$this->registry->setClass( 'autowelcome', new welcomeMembers( $this->registry ) );
		$this->registry->autowelcome->send_welcome( $member );
	}
    
	public function onCreateAccount( $member )
	{
        if( IN_ACP )
        {	   
            require_once( IPSLib::getAppDir( 'autowelcome' ) . '/sources/welcome_members.php' );
            $this->registry->setClass( 'autowelcome', new welcomeMembers( $this->registry ) );
            $this->registry->autowelcome->send_welcome( $member );
        }
	}
}