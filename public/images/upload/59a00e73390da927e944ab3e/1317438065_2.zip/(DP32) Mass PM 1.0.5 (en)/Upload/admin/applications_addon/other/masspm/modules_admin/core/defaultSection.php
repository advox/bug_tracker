<?php

$DEFAULT_SECTION = 'main';

?>