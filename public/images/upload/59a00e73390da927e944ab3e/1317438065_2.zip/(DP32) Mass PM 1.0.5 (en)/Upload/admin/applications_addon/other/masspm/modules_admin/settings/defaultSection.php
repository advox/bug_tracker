<?php

$DEFAULT_SECTION = 'settings';

?>