<?php

//-----------------------------------------------
// (DP32) Mass PM
//-----------------------------------------------
//-----------------------------------------------
// Loader
//-----------------------------------------------
// Author: DawPi
// Site: http://www.ipslink.pl
// Written on: 26 / 05 / 2011
//-----------------------------------------------
// Copyright (C) 2009-2011 DawPi
// All Rights Reserved
//-----------------------------------------------   

class app_class_masspm
{
	public function __construct( ipsRegistry $registry )
	{
		/* Load the library */
		
		require_once( IPSLib::getAppDir( 'masspm' ) . '/sources/classes/library.php' );
		$registry->setClass( 'masspmLibrary', new masspmLibrary( $registry ) );
			
		if ( IN_ACP )
		{
			$registry->getClass('class_localization')->loadLanguageFile( array( 'admin_masspm' ), 'masspm' );
		}
	}
} // End of class
